#!/usr/bin/env bash
# Installs Argo CD and registers the SmartAttend applications (GitOps preview, CO-3).
set -euo pipefail
ARGOCD_VERSION="v3.5.6"
kubectl create namespace argocd --dry-run=client -o yaml | kubectl apply -f -
kubectl apply -n argocd --server-side -f "https://raw.githubusercontent.com/argoproj/argo-cd/${ARGOCD_VERSION}/manifests/install.yaml"
kubectl -n argocd rollout status deploy/argocd-server --timeout=5m
DIR="$(cd "$(dirname "$0")" && pwd)"
"$DIR/../../scripts/create-secrets.sh" smartattend-dev
kubectl apply -f "$DIR/project.yaml" -f "$DIR/smartattend-dev.yaml"
echo "Argo CD admin password:"
kubectl -n argocd get secret argocd-initial-admin-secret -o jsonpath='{.data.password}' | base64 -d; echo
echo "UI: kubectl -n argocd port-forward svc/argocd-server 8443:443  ->  https://localhost:8443"
