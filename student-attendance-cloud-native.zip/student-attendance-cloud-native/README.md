# Cloud-Native Student Attendance Management System

A microservice-based attendance system: **faculty start a class session and show a 6-character check-in code**, students check in from their phone, and everyone sees **live attendance percentages, the 75% rule and shortage alerts**. Admins manage courses and faculty. It is built and shipped the cloud-native way: containers, **Helm**, Kubernetes **deployment strategies**, a **CI/CD pipeline with security scanning**, **GitOps**, and an **API gateway with TLS**.

> Course: Cloud Native Application Development - covers CO-1 (Helm), CO-2 (deployment strategies), CO-3 (CI/CD pipelines) and CO-4 (ingress, TLS and API gateway). See the [CO mapping](#course-outcome-co-mapping).

![stack](https://img.shields.io/badge/Node.js-24-339933) ![helm](https://img.shields.io/badge/Helm-3%20%7C%204-0F1689) ![k8s](https://img.shields.io/badge/Kubernetes-1.27%2B-326CE5) ![db](https://img.shields.io/badge/PostgreSQL-16-4169E1)

---

## Architecture

```mermaid
flowchart LR
    U[Browser] -->|HTTPS| GW["Ingress / API Gateway<br/>NGINX or Traefik<br/>TLS (cert-manager) - rate limits - JWT check"]
    GW -->|/| FE[frontend<br/>NGINX static SPA]
    GW -->|/api/auth| AUTH[auth-service]
    GW -->|/api/courses| CAT[course-service]
    GW -->|/api/attendance<br/>JWT validated via auth-url| RES[attendance-service]
    GW -. auth-url .-> AUTH
    RES -->|internal API + token<br/>K8s DNS discovery| CAT
    AUTH --> DB[(PostgreSQL)]
    CAT --> DB
    RES --> DB
    CJ[CronJob<br/>session-closer] --> RES
```

| Component | Responsibility | Port |
|---|---|---|
| `frontend` | Single-page UI: student check-in + my attendance, faculty live session (code, roster marking), reports with CSV export, admin course/faculty management, live "which pod served me" bar | 8080 |
| `auth-service` | Students (with roll numbers), faculty and admins; login, JWT (HS256) issuing, `/api/auth/verify` token introspection used by the gateway | 8080 (4001 dev) |
| `course-service` | Courses, faculty assignment, student enrollment (quota per student), roster (internal API) | 8080 (4002 dev) |
| `attendance-service` | Class sessions with expiring check-in codes, PRESENT / LATE / ABSENT / EXCUSED marking, attendance %, defaulter reports | 8080 (4003 dev) |
| PostgreSQL 16 | Persistence (in-cluster StatefulSet for dev/staging, managed DB in prod) | 5432 |

Every service exposes `/healthz` (liveness), `/readyz` (readiness, checks the DB), `/metrics` (Prometheus) and `/_info` (version, deployment track, pod name).

## Course outcome (CO) mapping

| CO | Topic | Where to find it |
|---|---|---|
| **CO-1** | Charts, templates, `values.yaml`, `Chart.yaml`, directory structure | [`helm/`](helm) - umbrella chart `helm/smartattend`, reusable chart `helm/microservice`, `helm/postgresql` |
| | Variable injection, `global` values, `tpl` | `helm/smartattend/values.yaml` (`global.*`), attendance `COURSE_URL` uses `{{ .Release.Name }}` |
| | Conditional templates, `.Capabilities` | `canary.enabled`, `blueGreen.enabled`, `certificate.yaml` only when cert-manager CRDs exist |
| | Chart dependencies, aliases, conditions | `helm/smartattend/Chart.yaml` - one chart reused 4x via `alias` |
| | Helm repos & chart versioning | `.github/workflows/release-chart.yml` (OCI repo on GHCR), SemVer `version` vs `appVersion` |
| | dev / stage / prod overlays | `values-local.yaml`, `values-dev.yaml`, `values-staging.yaml`, `values-prod.yaml` |
| | Secret & config templating | `templates/secret.yaml` (lookup + random, kept across upgrades), ConfigMap + `checksum/config` |
| | Linting, schema, dry-run | `scripts/helm-lint.sh`, `helm/microservice/values.schema.json` |
| | Upgrade / rollback | `scripts/deploy.sh` (`--atomic`), `scripts/rollback.sh` |
| **CO-2** | Rolling update, `maxSurge` / `maxUnavailable` | `helm/microservice/values.yaml` `strategy` |
| | Canary (weight + header) | `scripts/canary.sh`, canary Ingress in `helm/microservice/templates/ingress.yaml` |
| | Blue-green with preview Service | `scripts/blue-green.sh`, `templates/service.yaml` |
| | Advanced probes (startup / liveness / readiness), graceful shutdown | `templates/_helpers.tpl`, `packages/kit/lifecycle.js` |
| | Traffic splitting: NGINX Ingress, Gateway API, Istio | `ingress.yaml`, `templates/httproute.yaml`, `templates/istio.yaml` |
| | Automated rollback (`helm --atomic`, `kubectl rollout undo`) | `scripts/demo-auto-rollback.sh`, CI job `e2e-kind` |
| | Pre-promotion health testing | `helm test` pod, `canary.sh analyze`, `blue-green.sh test` |
| | PodDisruptionBudgets | `templates/pdb.yaml`, enabled in staging/prod |
| **CO-3** | Pipeline build -> test -> scan -> push -> deploy | `.github/workflows/ci.yml`, `cd.yml`, `deploy-env.yml` |
| | Trivy image + IaC scanning | `ci.yml` (`image`, `config-scan` jobs, SARIF to GitHub Security) |
| | Environment promotion dev -> staging -> prod | `cd.yml` with GitHub Environments (manual approval) |
| | Secrets in pipelines, Vault | `deploy-env.yml` (Vault JWT/OIDC), `infra/vault/` |
| | GitOps preview | `gitops/argocd/`, `gitops/flux/`, `.github/workflows/gitops-promote.yml` |
| | Jenkins / GitLab CI | `ci/jenkins/Jenkinsfile`, `ci/gitlab/.gitlab-ci.yml` |
| **CO-4** | Ingress controllers (NGINX, Traefik) | `global.ingress.className`, `infra/ingress-nginx/`, `infra/traefik/` |
| | TLS termination, cert-manager | `templates/certificate.yaml`, `infra/cert-manager/` |
| | API gateway: rate limiting, quotas, JWT validation | ingress annotations, Traefik middlewares, quota `MAX_ACTIVE_ATTENDANCES` |
| | External DNS | `infra/external-dns/values.yaml`, annotation on the primary Ingress |
| | Service discovery, mTLS | K8s DNS (`COURSE_URL`), headless Service for PostgreSQL, Istio `PeerAuthentication` |
| | HA gateway, L4 vs L7 cost/performance | `infra/ingress-nginx/values-ha.yaml`, [docs/CO4](docs/CO4-ingress-gateway.md) |

Detailed explanations, demo commands and viva questions: [CO-1](docs/CO1-helm.md) · [CO-2](docs/CO2-deployment-strategies.md) · [CO-3](docs/CO3-cicd.md) · [CO-4](docs/CO4-ingress-gateway.md) · [Architecture & API](docs/ARCHITECTURE.md) · [GitHub setup](docs/GITHUB-SETUP.md)

## Project structure

```
student-attendance-cloud-native/
├── services/
│   ├── auth-service/          # Node.js, JWT, scrypt passwords
│   ├── course-service/        # courses, faculty, enrollments
│   └── attendance-service/    # sessions, check-in codes, marking, reports
│       ├── src/  (app.js, service.js, repository/{memory,postgres}.js, kit/ ...)
│       ├── test/              # node:test unit + PostgreSQL integration tests
│       └── Dockerfile         # multi-stage, non-root, read-only FS ready
├── frontend/                  # SPA (HTML/CSS/JS) + nginx.conf + Dockerfile
├── packages/kit/              # shared toolkit (router, JWT, metrics, health) - vendored into services
├── helm/
│   ├── smartattend/              # umbrella chart + values-{local,dev,staging,prod}.yaml
│   ├── microservice/          # reusable chart: Deployment/Service/Ingress/HPA/PDB/canary/blue-green
│   └── postgresql/            # StatefulSet + headless Service
├── .github/workflows/         # ci.yml, cd.yml, deploy-env.yml, release-chart.yml, gitops-promote.yml
├── ci/                        # Jenkinsfile, .gitlab-ci.yml (alternatives)
├── gitops/                    # Argo CD Applications, Flux HelmRelease, per-env desired state
├── infra/                     # kind, ingress-nginx (HA), traefik, cert-manager, external-dns, gateway-api, vault
├── scripts/                   # kind-up, build-images, deploy, rollback, canary, blue-green, demos
├── deploy/compose/            # local API gateway config for docker compose
├── tools/                     # dev runner, dev gateway, kit sync
├── docs/                      # CO-wise documentation
└── docker-compose.yml
```

## Quick start

Prerequisites: **Node.js 22+** and **Git**. Optional: Docker Desktop, kind, kubectl, Helm 3.14+ (or Helm 4).
On Windows run the `.sh` scripts from **Git Bash** or **WSL** (VS Code terminal -> Git Bash).

### Option 1 - run everything locally in VS Code (no Docker)

```bash
npm run dev            # starts auth, course, attendance + gateway (in-memory storage)
# open http://localhost:3000
npm test               # runs all unit tests
```

Or use **Run and Debug -> "SmartAttend: all services + UI"** in VS Code to debug with breakpoints.

### Option 2 - Docker Compose (production-like: PostgreSQL + NGINX gateway)

```bash
docker compose up --build
# open http://localhost:8080
```

### Option 3 - Kubernetes with Helm (kind)

```bash
./scripts/kind-up.sh                         # kind cluster + NGINX Ingress + cert-manager + metrics-server
./scripts/build-images.sh --kind smartattend    # build images and load them into kind
./scripts/deploy.sh local                    # helm upgrade --install --atomic + helm test
# open http://smartattend.localtest.me          (*.localtest.me resolves to 127.0.0.1)
./scripts/smoke-test.sh
```

Demo accounts (seeded in local/dev):

| Role | Email | Password |
|---|---|---|
| Student (roll 22CS001) | student@smartattend.local | Student@123 |
| Faculty (CS501, CS502) | faculty@smartattend.local | Faculty@123 |
| Admin | admin@smartattend.local | Admin@12345 |

More students: priya@ / rahul@ / sneha@ / karthik@smartattend.local (Student@123). Demo history: 10 past classes in CS501 and CS502 (one student below 75 %).

**Try it:** sign in as faculty -> *Start session* -> a code appears. In another browser (or incognito) sign in as the student -> type the code -> the faculty roster updates within 5 seconds.

## Demo cheat-sheet (for the viva)

```bash
# CO-1  Helm
./scripts/helm-lint.sh                                   # lint + render every environment
helm history smartattend -n smartattend-local
./scripts/rollback.sh local                              # helm rollback

# CO-2  Deployment strategies
./scripts/canary.sh local course start dev 30           # 30% of /api/courses traffic -> canary
./scripts/canary.sh local course analyze                # pre-promotion health check
./scripts/canary.sh local course promote                # or: abort
./scripts/blue-green.sh local course init dev
./scripts/blue-green.sh local course deploy dev && ./scripts/blue-green.sh local course test
./scripts/blue-green.sh local course switch             # instant cut-over (run again = instant rollback)
./scripts/demo-auto-rollback.sh local                    # helm --atomic + kubectl rollout undo
kubectl drain <node> --ignore-daemonsets                 # PDB keeps minAvailable pods running

# CO-4  Gateway
./scripts/rate-limit-demo.sh                             # see HTTP 429 from the gateway
curl -i http://smartattend.localtest.me/api/attendance/me # 401: JWT checked at the gateway
```

The footer of the web UI shows, for each API, **which version, deployment track (stable / canary / blue / green) and pod** answered. Refresh it during a canary or blue-green switch to see traffic move.

## Push to GitHub

```bash
git init
git add .
git commit -m "Cloud-Native Student Attendance: services, Helm, CI/CD"
git branch -M main
git remote add origin https://github.com/<your-username>/student-attendance-cloud-native.git
git push -u origin main
```

Then replace `change-me` / `CHANGE-ME` with your GitHub username (lowercase) in `helm/smartattend/values.yaml`, `gitops/` and `helm/smartattend/Chart.yaml`. Pushing to `main` runs the CI pipeline, which tests, scans and publishes images to `ghcr.io/<you>/smartattend-*` and deploys to a throw-away kind cluster. See [docs/GITHUB-SETUP.md](docs/GITHUB-SETUP.md) for environments, approvals, Vault and Argo CD.

## Tech choices

- **Node.js 24 with zero runtime frameworks** (only the `pg` driver): small images, fast start-up, almost nothing for Trivy to flag. The shared toolkit lives in `packages/kit` and is vendored into each service (`npm run sync:kit`), so each service builds on its own.
- **PostgreSQL**: starting a session (with its roster snapshot) and every check-in are single atomic SQL statements, so many replicas stay consistent; a code is accepted only while the session is open and only once per student.
- **Security**: non-root containers, read-only root filesystem, dropped capabilities, seccomp, NetworkPolicies, strict CSP, JWT checked at both the gateway and the service, internal API never exposed, SHA-pinned CI actions.

## License

MIT
