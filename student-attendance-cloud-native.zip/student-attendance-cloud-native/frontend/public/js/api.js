// API client. All calls are same-origin (/api/...): the Ingress / API gateway routes them
// to the right microservice, so the browser never needs to know internal service names.

const TOKEN_KEY = 'smartattend.token';
const USER_KEY = 'smartattend.user';

const store = {
  get(key) {
    try {
      return localStorage.getItem(key);
    } catch {
      return null;
    }
  },
  set(key, value) {
    try {
      localStorage.setItem(key, value);
    } catch {
      /* storage unavailable (private mode) - session lives in memory only */
    }
  },
  remove(key) {
    try {
      localStorage.removeItem(key);
    } catch {
      /* ignore */
    }
  },
};

let memoryToken = store.get(TOKEN_KEY);
let memoryUser = (() => {
  try {
    return JSON.parse(store.get(USER_KEY) || 'null');
  } catch {
    return null;
  }
})();

export const session = {
  get token() {
    return memoryToken;
  },
  get user() {
    return memoryUser;
  },
  save(token, user) {
    memoryToken = token;
    memoryUser = user;
    store.set(TOKEN_KEY, token);
    store.set(USER_KEY, JSON.stringify(user));
  },
  clear() {
    memoryToken = null;
    memoryUser = null;
    store.remove(TOKEN_KEY);
    store.remove(USER_KEY);
  },
};

export class ApiError extends Error {
  constructor(status, message, code, details) {
    super(message);
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

let onUnauthorized = () => {};
export const setUnauthorizedHandler = (fn) => {
  onUnauthorized = fn;
};

export async function request(path, { method = 'GET', body, auth = true } = {}) {
  const headers = { Accept: 'application/json' };
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (auth && session.token) headers.Authorization = `Bearer ${session.token}`;

  let res;
  try {
    res = await fetch(path, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
  } catch {
    throw new ApiError(0, 'Network error - is the gateway running?', 'NETWORK');
  }

  const text = await res.text();
  let data = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = null;
  }

  if (!res.ok) {
    if (res.status === 401 && auth && session.token) {
      session.clear();
      onUnauthorized();
    }
    const err = data && data.error ? data.error : {};
    const fallback = res.status === 429 ? 'Too many requests - slow down a little' : `Request failed (HTTP ${res.status})`;
    throw new ApiError(res.status, err.message || fallback, err.code, err.details);
  }
  return data;
}

const qs = (params) => {
  const s = new URLSearchParams(Object.entries(params).filter(([, v]) => v !== undefined && v !== null && v !== '' && v !== false));
  const str = s.toString();
  return str ? `?${str}` : '';
};

export const Auth = {
  login: (email, password) => request('/api/auth/login', { method: 'POST', body: { email, password }, auth: false }),
  register: (data) => request('/api/auth/register', { method: 'POST', body: data, auth: false }),
  users: (role) => request(`/api/auth/users${qs({ role })}`),
  createUser: (data) => request('/api/auth/users', { method: 'POST', body: data }),
};

export const Courses = {
  list: (params = {}) => request(`/api/courses${qs(params)}`, { auth: false }),
  mine: () => request('/api/courses/mine'),
  stats: () => request('/api/courses/stats', { auth: false }),
  roster: (id) => request(`/api/courses/${id}/roster`),
  create: (course) => request('/api/courses', { method: 'POST', body: course }),
  remove: (id) => request(`/api/courses/${id}`, { method: 'DELETE' }),
  enroll: (id) => request(`/api/courses/${id}/enroll`, { method: 'POST' }),
  drop: (id) => request(`/api/courses/${id}/enroll`, { method: 'DELETE' }),
};

export const Attendance = {
  policy: () => request('/api/attendance/policy'),
  checkIn: (code) => request('/api/attendance/check-in', { method: 'POST', body: { code } }),
  me: () => request('/api/attendance/me'),
  stats: () => request('/api/attendance/stats'),
  sessions: (params = {}) => request(`/api/attendance/sessions${qs(params)}`),
  start: (courseId, topic) => request('/api/attendance/sessions', { method: 'POST', body: { courseId, topic } }),
  session: (id) => request(`/api/attendance/sessions/${id}`),
  close: (id) => request(`/api/attendance/sessions/${id}/close`, { method: 'POST' }),
  mark: (recordId, status) => request(`/api/attendance/records/${recordId}`, { method: 'PUT', body: { status } }),
  report: (courseId) => request(`/api/attendance/courses/${courseId}/report`),
};

/** Which pod / version / deployment track served each API (shows canary & blue-green live). */
export async function serviceInfo() {
  const targets = [
    ['auth', '/api/auth/_info'],
    ['course', '/api/courses/_info'],
    ['attendance', '/api/attendance/_info'],
  ];
  const results = await Promise.allSettled(targets.map(([, path]) => request(path)));
  return targets.map(([name], i) => ({ name, ok: results[i].status === 'fulfilled', ...(results[i].value || {}) }));
}
