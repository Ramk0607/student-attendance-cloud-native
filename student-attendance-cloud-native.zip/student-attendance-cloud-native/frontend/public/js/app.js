import { session, setUnauthorizedHandler, Auth, Courses, Attendance, serviceInfo } from './api.js';

/* ------------------------------------------------------------------ helpers */
const $ = (sel, root = document) => root.querySelector(sel);
const app = $('#app');
const esc = (v) =>
  String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

const dateFmt = new Intl.DateTimeFormat('en-IN', { weekday: 'short', day: 'numeric', month: 'short' });
const timeFmt = new Intl.DateTimeFormat('en-IN', { hour: '2-digit', minute: '2-digit' });
const fmtDate = (iso) => (iso ? `${dateFmt.format(new Date(iso))}, ${timeFmt.format(new Date(iso))}` : '—');
const pctText = (p) => (p === null || p === undefined ? '—' : `${p}%`);

function toast(message, kind = 'info') {
  const el = document.createElement('div');
  el.className = `toast toast--${kind}`;
  el.textContent = message;
  const box = $('#toasts');
  box.append(el);
  while (box.children.length > 3) box.firstElementChild.remove();
  setTimeout(() => el.remove(), 4200);
}

const STANDING = {
  OK: ['Good standing', 'ok'],
  WARNING: ['Below 75%', 'warn'],
  SHORTAGE: ['Shortage', 'danger'],
  NO_CLASSES: ['No classes yet', 'neutral'],
};
const standingBadge = (s) => {
  const [label, kind] = STANDING[s] || [s, 'neutral'];
  return `<span class="badge badge--${kind}">${label}</span>`;
};
const STATUS_KIND = { PRESENT: 'ok', LATE: 'warn', ABSENT: 'danger', EXCUSED: 'info' };
const statusBadge = (s) => `<span class="badge badge--${STATUS_KIND[s] || 'neutral'}">${esc(s.charAt(0) + s.slice(1).toLowerCase())}</span>`;

/** Progress bar using CSS width classes (no inline styles -> strict CSP works). */
function bar(percent, { min = 75, critical = 65 } = {}) {
  const p = percent === null || percent === undefined ? 0 : Math.max(0, Math.min(100, Math.round(percent)));
  const kind = percent === null ? '' : percent >= min ? '' : percent >= critical ? 'warn' : 'danger';
  return `<div class="bar ${kind}"><span class="w-${p}"></span><i class="mark ml-${min}"></i></div>`;
}

const state = { policy: { minAttendancePercent: 75, criticalAttendancePercent: 65 }, liveSessionId: null, reportCourse: '' };
let liveTimer = null;
const stopLive = () => {
  clearInterval(liveTimer);
  liveTimer = null;
};

/* ------------------------------------------------------------------ chrome */
function updateChrome() {
  const user = session.user;
  $('#topbar').hidden = !user;
  $('#cluster').hidden = !user;
  if (!user) return;
  $('#user-name').textContent = user.name;
  $('#user-role').textContent = user.rollNo ? `${user.role} · ${user.rollNo}` : user.role;
  $('#user-avatar').textContent = user.name
    .replace(/^(Dr\.|Prof\.)\s*/, '')
    .split(' ')
    .map((p) => p[0])
    .slice(0, 2)
    .join('')
    .toUpperCase();
  document.querySelectorAll('[data-roles]').forEach((el) => {
    el.hidden = !el.dataset.roles.split(' ').includes(user.role);
  });
  const route = currentRoute();
  document.querySelectorAll('#nav a').forEach((a) => a.classList.toggle('active', a.dataset.route === route));
}

async function refreshCluster() {
  const services = await serviceInfo();
  $('#cluster-services').innerHTML = services
    .map((s) => {
      if (!s.ok) return `<span class="svc"><b>${esc(s.name)}</b><span class="track track--down">down</span></span>`;
      const pod = String(s.pod || '');
      return `<span class="svc" title="pod ${esc(pod)} · node ${esc(s.node)} · ns ${esc(s.namespace)}">
        <b>${esc(s.name)}</b> <span class="mono">v${esc(s.version)}</span>
        <span class="track track--${esc(s.track)}">${esc(s.track)}</span>
        <span class="mono">${esc(pod.length > 22 ? `…${pod.slice(-20)}` : pod)}</span></span>`;
    })
    .join('');
}

/* ------------------------------------------------------------------ login */
function viewLogin(mode = 'login') {
  app.innerHTML = `
  <section class="auth">
    <div class="auth__hero">
      <h1>Cloud-Native <span>Student Attendance</span></h1>
      <p class="lead">Faculty start a class session, students check in with the 6-character code on the board, and everyone sees live attendance percentages and shortage alerts.</p>
      <ul class="feature-list">
        <li><span class="ico">✓</span><span><strong>One-tap check-in</strong><small>Time-limited class codes, automatic late marking.</small></span></li>
        <li><span class="ico">%</span><span><strong>Live attendance tracking</strong><small>Per-course percentage, 75% rule, classes needed to recover.</small></span></li>
        <li><span class="ico">☸</span><span><strong>Runs on Kubernetes</strong><small>Microservices on Helm with canary and blue-green releases.</small></span></li>
      </ul>
    </div>
    <div class="card auth__card">
      <div class="tabs" role="tablist">
        <button type="button" data-action="auth-tab" data-mode="login" class="${mode === 'login' ? 'active' : ''}">Sign in</button>
        <button type="button" data-action="auth-tab" data-mode="register" class="${mode === 'register' ? 'active' : ''}">Student sign-up</button>
      </div>
      <form id="auth-form" novalidate>
        ${mode === 'register' ? `
        <div class="field"><label for="name">Full name</label><input class="input" id="name" name="name" autocomplete="name" required /></div>
        <div class="field"><label for="rollNo">Roll number</label><input class="input" id="rollNo" name="rollNo" placeholder="e.g. 23CS042" required /></div>` : ''}
        <div class="field"><label for="email">Email</label><input class="input" id="email" name="email" type="email" autocomplete="email" required /></div>
        <div class="field"><label for="password">Password</label><input class="input" id="password" name="password" type="password" autocomplete="${mode === 'login' ? 'current-password' : 'new-password'}" required />
          ${mode === 'register' ? '<small class="muted">At least 8 characters with letters and numbers.</small>' : ''}</div>
        <p class="field__error" id="auth-error"></p>
        <button class="btn btn--block" type="submit">${mode === 'login' ? 'Sign in' : 'Create student account'}</button>
      </form>
      <div class="demo-hint">
        Demo accounts (dev environment):<br />
        <button type="button" data-action="demo" data-email="student@smartattend.local" data-password="Student@123">Student · student@smartattend.local</button><br />
        <button type="button" data-action="demo" data-email="faculty@smartattend.local" data-password="Faculty@123">Faculty · faculty@smartattend.local</button><br />
        <button type="button" data-action="demo" data-email="admin@smartattend.local" data-password="Admin@12345">Admin · admin@smartattend.local</button>
      </div>
    </div>
  </section>`;

  $('#auth-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = Object.fromEntries(new FormData(e.target).entries());
    const btn = e.target.querySelector('button[type=submit]');
    btn.disabled = true;
    $('#auth-error').textContent = '';
    try {
      const res = mode === 'login' ? await Auth.login(form.email, form.password) : await Auth.register(form);
      session.save(res.token, res.user);
      toast(`Welcome, ${res.user.name.replace(/^(Dr\.|Prof\.)\s*/, '').split(' ')[0]}!`, 'ok');
      location.hash = '#/dashboard';
    } catch (err) {
      $('#auth-error').textContent = err.details ? Object.values(err.details).join(' · ') : err.message;
    } finally {
      btn.disabled = false;
    }
  });
}

/* ------------------------------------------------------------------ student */
async function viewStudentDashboard() {
  app.innerHTML = `
  <div class="page-head"><div><h1>My attendance</h1><p id="policy-line">Check in with the code your faculty shows in class.</p></div>
    <a class="btn btn--ghost" href="#/courses">Enroll in courses</a></div>
  <div class="grid-2">
    <section class="card checkin">
      <h2>Check in to a class</h2>
      <p>Type the 6-character code from the board before it expires.</p>
      <form id="checkin-form" novalidate>
        <input class="input" id="code" name="code" maxlength="6" autocomplete="off" placeholder="ABC123" aria-label="Check-in code" />
        <button class="btn" type="submit">Check in</button>
      </form>
    </section>
    <section class="card overall" id="overall"><div class="skeleton skeleton--xs"></div></section>
  </div>
  <section class="section"><h2>Courses</h2><div class="course-cards" id="course-cards"><div class="skeleton skeleton--sm"></div></div></section>
  <section class="section card"><div class="panel-head"><h2>Recent classes</h2></div><ul class="recent" id="recent"></ul></section>`;

  $('#checkin-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const input = $('#code');
    try {
      const { record } = await Attendance.checkIn(input.value);
      toast(`${record.courseCode}: marked ${record.status.toLowerCase()} ✓`, 'ok');
      input.value = '';
      loadStudentSummary();
    } catch (err) {
      toast(err.message, 'error');
    }
  });
  await loadStudentSummary();
}

async function loadStudentSummary() {
  try {
    const [summary, policy] = await Promise.all([Attendance.me(), Attendance.policy().catch(() => null)]);
    if (policy) {
      state.policy = policy;
      $('#policy-line').textContent = `Minimum ${policy.minAttendancePercent}% per course · codes valid ${policy.codeValidityMinutes} min · late after ${policy.lateAfterMinutes} min`;
    }
    const o = summary.overall;
    $('#overall').innerHTML = `
      <span class="muted">Overall attendance</span>
      <div class="big-percent">${pctText(o.percent)}</div>
      ${bar(o.percent, { min: state.policy.minAttendancePercent, critical: state.policy.criticalAttendancePercent })}
      <div class="counts"><span><b>${o.attended}</b> attended</span><span><b>${o.late}</b> late</span><span><b>${o.absent}</b> absent</span><span><b>${o.excused}</b> excused</span></div>
      <div>${standingBadge(o.standing)}</div>`;
    $('#course-cards').innerHTML = summary.courses.length
      ? summary.courses
          .map(
            (c) => `<article class="card course-card">
          <div class="course-card__head"><div><span class="course-code">${esc(c.courseCode)}</span><h3>${esc(c.courseName)}</h3></div>
            <div class="pct">${pctText(c.percent)}</div></div>
          ${bar(c.percent, { min: state.policy.minAttendancePercent, critical: state.policy.criticalAttendancePercent })}
          <div class="counts"><span><b>${c.attended}</b>/${c.total - c.excused} classes</span><span><b>${c.late}</b> late</span><span><b>${c.absent}</b> absent</span></div>
          <div>${standingBadge(c.standing)} ${c.classesNeeded ? `<small class="muted">Attend the next <b>${c.classesNeeded}</b> classes to reach ${state.policy.minAttendancePercent}%</small>` : ''}</div>
        </article>`,
          )
          .join('')
      : '<div class="card empty" data-span="all"><strong>No attendance yet</strong>Enroll in courses and check in to your first class.</div>';
    $('#recent').innerHTML = summary.recent.length
      ? summary.recent
          .map((r) => `<li><span><b>${esc(r.courseCode)}</b> · ${esc(r.topic)}<br><small class="muted">${fmtDate(r.startsAt)}</small></span>${statusBadge(r.status)}</li>`)
          .join('')
      : '<li class="muted">No classes recorded yet.</li>';
  } catch (err) {
    $('#course-cards').innerHTML = `<div class="card empty" data-span="all"><strong>Could not load attendance</strong>${esc(err.message)}</div>`;
  }
}

async function viewCourses() {
  app.innerHTML = `
  <div class="page-head"><div><h1>Course catalogue</h1><p>Enroll in the courses you attend this semester.</p></div></div>
  <div class="course-cards" id="catalogue"><div class="skeleton skeleton--sm"></div></div>`;
  const [{ courses }, mine] = await Promise.all([Courses.list(), Courses.mine()]);
  const enrolled = new Set(mine.courses.map((c) => c.id));
  $('#catalogue').innerHTML = courses
    .map(
      (c) => `<article class="card course-card">
      <div class="course-card__head"><div><span class="course-code">${esc(c.code)}</span><h3>${esc(c.name)}</h3></div>
        ${enrolled.has(c.id) ? '<span class="badge badge--ok">Enrolled</span>' : ''}</div>
      <div class="counts"><span>${esc(c.facultyName)}</span><span>${esc(c.schedule)}</span><span>${esc(c.room)}</span></div>
      <div class="counts"><span>${esc(c.department)}</span><span>Sem ${c.semester}</span><span>${c.credits} credits</span><span><b>${c.enrolledCount}</b> students</span></div>
      <div>${enrolled.has(c.id)
        ? `<button class="btn btn--danger btn--sm" data-action="drop" data-id="${c.id}">Drop course</button>`
        : `<button class="btn btn--sm" data-action="enroll" data-id="${c.id}">Enroll</button>`}</div>
    </article>`,
    )
    .join('');
}

/* ------------------------------------------------------------------ faculty / admin */
async function viewStaffDashboard() {
  const isAdmin = session.user.role === 'admin';
  app.innerHTML = `
  <div class="page-head"><div><h1>${isAdmin ? 'Admin dashboard' : 'Faculty dashboard'}</h1><p>Start a class session and let students check in with the code.</p></div></div>
  <div class="stats" id="stats">${'<div class="card stat skeleton skeleton--xs"></div>'.repeat(5)}</div>
  <section class="section card">
    <div class="panel-head"><h2>Start a class session</h2></div>
    <form class="panel-body inline-form" id="start-form" novalidate>
      <div class="field"><label>Course</label><select class="input" name="courseId" id="start-course"></select></div>
      <div class="field"><label>Topic</label><input class="input" name="topic" placeholder="e.g. Helm charts" /></div>
      <button class="btn" type="submit">Start session &amp; show code</button>
    </form>
  </section>
  <section class="section"><h2>${isAdmin ? 'All courses' : 'My courses'}</h2><div class="course-cards" id="my-courses"></div></section>`;

  $('#start-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = Object.fromEntries(new FormData(e.target).entries());
    try {
      const { session: s } = await Attendance.start(Number(form.courseId), form.topic);
      toast(`Session started for ${s.courseCode} - code ${s.code}`, 'ok');
      location.hash = `#/sessions/${s.id}`;
    } catch (err) {
      toast(err.message, 'error');
    }
  });

  const [{ courses }, stats] = await Promise.all([Courses.mine(), Attendance.stats()]);
  $('#start-course').innerHTML = courses.map((c) => `<option value="${c.id}">${esc(c.code)} · ${esc(c.name)}</option>`).join('');
  const tiles = [
    ['Courses', courses.length],
    ['Sessions', stats.sessions],
    ['Open now', stats.openSessions],
    ['Today', stats.sessionsToday],
    ['Avg attendance', pctText(stats.percent), stats.percent !== null && stats.percent < 75],
  ];
  $('#stats').innerHTML = tiles
    .map(([k, v, alert]) => `<div class="card stat ${alert ? 'alert' : ''}"><span>${esc(k)}</span><strong>${esc(v)}</strong></div>`)
    .join('');
  $('#my-courses').innerHTML = courses.length
    ? courses
        .map(
          (c) => `<article class="card course-card">
        <div class="course-card__head"><div><span class="course-code">${esc(c.code)}</span><h3>${esc(c.name)}</h3></div></div>
        <div class="counts"><span><b>${c.enrolledCount}</b> students</span><span>${esc(c.schedule)}</span><span>${esc(c.room)}</span>${isAdmin ? `<span>${esc(c.facultyName)}</span>` : ''}</div>
        <div><a class="btn btn--ghost btn--sm" href="#/reports/${c.id}">Attendance report</a> <a class="btn btn--ghost btn--sm" href="#/sessions?course=${c.id}">Sessions</a></div>
      </article>`,
        )
        .join('')
    : '<div class="card empty" data-span="all"><strong>No courses assigned</strong>Ask the admin to assign you a course.</div>';
}

async function viewSessions(id) {
  stopLive();
  if (id) return viewSessionDetail(id);
  const courseFilter = new URLSearchParams(location.hash.split('?')[1] || '').get('course') || '';
  app.innerHTML = `
  <div class="page-head"><div><h1>Class sessions</h1><p>Open a session to see the live code and mark attendance.</p></div>
    <select class="input input--auto" id="session-course"></select></div>
  <section class="card"><div class="table-wrap" id="sessions-table"><div class="skeleton skeleton--sm"></div></div></section>`;
  const { courses } = await Courses.mine();
  $('#session-course').innerHTML = `<option value="">All courses</option>${courses
    .map((c) => `<option value="${c.id}" ${String(c.id) === courseFilter ? 'selected' : ''}>${esc(c.code)} · ${esc(c.name)}</option>`)
    .join('')}`;
  $('#session-course').addEventListener('change', (e) => {
    location.hash = e.target.value ? `#/sessions?course=${e.target.value}` : '#/sessions';
  });
  const { sessions } = await Attendance.sessions({ courseId: courseFilter });
  $('#sessions-table').innerHTML = sessions.length
    ? `<table><thead><tr><th>Date</th><th>Course</th><th>Topic</th><th>Status</th><th>Present</th><th>Attendance</th><th></th></tr></thead><tbody>${sessions
        .map((s) => {
          const pct = s.total - s.excused > 0 ? Math.round(((s.present + s.late) / (s.total - s.excused)) * 100) : null;
          return `<tr><td>${fmtDate(s.startsAt)}</td><td><span class="course-code">${esc(s.courseCode)}</span></td><td>${esc(s.topic)}</td>
          <td>${s.status === 'OPEN' ? '<span class="badge badge--ok">Open</span>' : '<span class="badge badge--neutral">Closed</span>'}</td>
          <td>${s.present + s.late}/${s.total}</td><td><span class="mini-bar">${bar(pct)}</span><span class="pct">${pctText(pct)}</span></td>
          <td class="actions-cell"><a class="btn btn--ghost btn--sm" href="#/sessions/${s.id}">Open</a></td></tr>`;
        })
        .join('')}</tbody></table>`
    : '<div class="empty"><strong>No sessions yet</strong>Start one from the dashboard.</div>';
  return null;
}

async function viewSessionDetail(id) {
  app.innerHTML = '<div class="skeleton skeleton--sm"></div>';
  const render = async () => {
    if (currentRoute() !== 'sessions') return stopLive();
    const { session: s } = await Attendance.session(id);
    const open = s.status === 'OPEN';
    const leftMs = Date.parse(s.codeExpiresAt) - Date.now();
    const left = leftMs > 0 ? `${Math.floor(leftMs / 60000)}:${String(Math.floor((leftMs % 60000) / 1000)).padStart(2, '0')}` : 'expired';
    const attended = s.present + s.late;
    app.innerHTML = `
    <div class="page-head"><div><h1><span class="course-code">${esc(s.courseCode)}</span> ${esc(s.topic)}</h1>
      <p>${esc(s.courseName)} · ${fmtDate(s.startsAt)}</p></div>
      <a class="btn btn--ghost" href="#/sessions">All sessions</a></div>
    <section class="card session-live">
      <div class="code-box">
        ${open ? `<div class="code" id="live-code">${esc(s.code)}</div>
          <div class="countdown">Code expires in<strong>${left}</strong></div>` : '<span class="badge badge--neutral">Session closed</span>'}
        <div class="countdown">Checked in<strong>${attended} / ${s.total}</strong></div>
        <div class="countdown">Late<strong>${s.late}</strong></div>
        ${open ? `<button class="btn btn--danger" data-action="close-session" data-id="${s.id}">Close session</button>` : ''}
      </div>
      ${open ? '<p class="muted">Students open SmartAttend → Dashboard → type this code. The list refreshes every 5 seconds.</p>' : ''}
    </section>
    <section class="section card"><div class="panel-head"><h2>Roster</h2><small class="muted">Click to correct a mark</small></div>
      <div class="table-wrap"><table><thead><tr><th>Roll no</th><th>Student</th><th>Status</th><th>Marked</th><th class="actions-cell">Set</th></tr></thead><tbody>
      ${s.records
        .map(
          (r) => `<tr><td class="mono">${esc(r.rollNo || '—')}</td><td>${esc(r.studentName)}<br><small class="muted">${esc(r.studentEmail)}</small></td>
          <td>${statusBadge(r.status)}</td><td><small class="muted">${r.markedAt ? `${timeFmt.format(new Date(r.markedAt))} · ${esc(r.method.toLowerCase())}` : '—'}</small></td>
          <td class="actions-cell"><span class="seg">${['PRESENT', 'LATE', 'ABSENT', 'EXCUSED']
            .map((st) => `<button type="button" class="${r.status === st ? `on-${st}` : ''}" data-action="mark" data-id="${r.id}" data-status="${st}" title="${st}">${st[0]}</button>`)
            .join('')}</span></td></tr>`,
        )
        .join('')}</tbody></table></div></section>`;
    if (!open) stopLive();
    return null;
  };
  await render();
  stopLive();
  liveTimer = setInterval(() => render().catch(() => stopLive()), 5000);
}

async function viewReports(courseId) {
  stopLive();
  const { courses } = await Courses.mine();
  const selected = courseId || state.reportCourse || (courses[0] && String(courses[0].id)) || '';
  state.reportCourse = selected;
  app.innerHTML = `
  <div class="page-head"><div><h1>Attendance report</h1><p>Students below ${state.policy.minAttendancePercent}% are highlighted as defaulters.</p></div>
    <div class="inline-form"><select class="input input--auto" id="report-course">${courses
      .map((c) => `<option value="${c.id}" ${String(c.id) === String(selected) ? 'selected' : ''}>${esc(c.code)} · ${esc(c.name)}</option>`)
      .join('')}</select><button class="btn btn--ghost" data-action="export-csv">Export CSV</button></div></div>
  <div class="stats" id="report-stats"></div>
  <section class="section card"><div class="table-wrap" id="report-table"><div class="skeleton skeleton--sm"></div></div></section>`;
  $('#report-course').addEventListener('change', (e) => {
    location.hash = `#/reports/${e.target.value}`;
  });
  if (!selected) {
    $('#report-table').innerHTML = '<div class="empty"><strong>No courses</strong></div>';
    return;
  }
  const rep = await Attendance.report(selected);
  state.lastReport = rep;
  $('#report-stats').innerHTML = [
    ['Students', rep.students.length],
    ['Sessions held', rep.sessions],
    ['Class average', pctText(rep.averagePercent)],
    ['Defaulters', rep.defaulters, rep.defaulters > 0],
  ]
    .map(([k, v, alert]) => `<div class="card stat ${alert ? 'alert' : ''}"><span>${esc(k)}</span><strong>${esc(v)}</strong></div>`)
    .join('');
  $('#report-table').innerHTML = rep.students.length
    ? `<table><thead><tr><th>Roll no</th><th>Student</th><th>Attended</th><th>Late</th><th>Absent</th><th>Excused</th><th>Attendance</th><th>Standing</th></tr></thead><tbody>${rep.students
        .map(
          (s) => `<tr class="${s.standing === 'WARNING' || s.standing === 'SHORTAGE' ? 'row-defaulter' : ''}">
          <td class="mono">${esc(s.rollNo || '—')}</td><td>${esc(s.studentName)}</td><td>${s.attended}/${s.total - s.excused}</td>
          <td>${s.late}</td><td>${s.absent}</td><td>${s.excused}</td>
          <td><span class="mini-bar">${bar(s.percent)}</span><span class="pct">${pctText(s.percent)}</span></td>
          <td>${standingBadge(s.standing)}${s.classesNeeded ? `<br><small class="muted">needs ${s.classesNeeded} more</small>` : ''}</td></tr>`,
        )
        .join('')}</tbody></table>`
    : '<div class="empty"><strong>No attendance recorded yet</strong>Start a session for this course.</div>';
}

function exportCsv() {
  const rep = state.lastReport;
  if (!rep) return;
  const rows = [['Roll no', 'Name', 'Email', 'Attended', 'Late', 'Absent', 'Excused', 'Total', 'Percent', 'Standing']];
  rep.students.forEach((s) => rows.push([s.rollNo, s.studentName, s.studentEmail, s.attended, s.late, s.absent, s.excused, s.total, s.percent, s.standing]));
  const csv = rows.map((r) => r.map((v) => `"${String(v ?? '').replace(/"/g, '""')}"`).join(',')).join('\n');
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
  a.download = `${rep.course.code}-attendance.csv`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

/* ------------------------------------------------------------------ admin */
async function viewManage() {
  if (session.user.role !== 'admin') {
    location.hash = '#/dashboard';
    return;
  }
  app.innerHTML = `
  <div class="page-head"><div><h1>Manage</h1><p>Create courses, assign faculty and add faculty accounts.</p></div></div>
  <section class="card"><div class="panel-head"><h2>Add a course</h2></div>
    <form class="panel-body" id="course-form" novalidate><div class="form-grid">
      <div class="field"><label>Code *</label><input class="input" name="code" placeholder="CS505" /></div>
      <div class="field"><label>Name *</label><input class="input" name="name" /></div>
      <div class="field"><label>Department *</label><input class="input" name="department" value="Computer Science" /></div>
      <div class="field"><label>Semester *</label><input class="input" name="semester" type="number" min="1" max="12" value="5" /></div>
      <div class="field"><label>Credits *</label><input class="input" name="credits" type="number" min="0" max="10" value="3" /></div>
      <div class="field"><label>Schedule</label><input class="input" name="schedule" placeholder="Mon/Wed 10:00" /></div>
      <div class="field"><label>Room</label><input class="input" name="room" placeholder="LH-101" /></div>
      <div class="field"><label>Faculty *</label><select class="input" name="faculty" id="faculty-select"></select></div>
    </div><p class="field__error" id="course-error"></p><button class="btn" type="submit">Create course</button></form></section>
  <section class="section card"><div class="panel-head"><h2>Courses</h2></div><div class="table-wrap" id="course-table"></div></section>
  <section class="section card"><div class="panel-head"><h2>Add a faculty member</h2></div>
    <form class="panel-body inline-form" id="faculty-form" novalidate>
      <div class="field"><label>Name</label><input class="input" name="name" placeholder="Dr. ..." /></div>
      <div class="field"><label>Email</label><input class="input" name="email" type="email" /></div>
      <div class="field"><label>Temporary password</label><input class="input" name="password" type="text" value="Welcome@123" /></div>
      <button class="btn" type="submit">Create faculty account</button>
    </form></section>`;

  const loadAll = async () => {
    const [{ courses }, { users }] = await Promise.all([Courses.list(), Auth.users('faculty')]);
    $('#faculty-select').innerHTML = users.map((u) => `<option value="${esc(u.email)}|${esc(u.name)}">${esc(u.name)} (${esc(u.email)})</option>`).join('');
    $('#course-table').innerHTML = `<table><thead><tr><th>Code</th><th>Name</th><th>Faculty</th><th>Students</th><th></th></tr></thead><tbody>${courses
      .map((c) => `<tr><td><span class="course-code">${esc(c.code)}</span></td><td>${esc(c.name)}<br><small class="muted">${esc(c.department)} · Sem ${c.semester}</small></td>
        <td>${esc(c.facultyName)}</td><td>${c.enrolledCount}</td>
        <td class="actions-cell"><button class="btn btn--danger btn--sm" data-action="delete-course" data-id="${c.id}">Delete</button></td></tr>`)
      .join('')}</tbody></table>`;
  };
  $('#course-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const f = Object.fromEntries(new FormData(e.target).entries());
    const [facultyEmail, facultyName] = String(f.faculty || '|').split('|');
    try {
      const { course } = await Courses.create({ ...f, semester: Number(f.semester), credits: Number(f.credits), facultyEmail, facultyName });
      toast(`Course ${course.code} created`, 'ok');
      e.target.reset();
      $('#course-error').textContent = '';
      loadAll();
    } catch (err) {
      $('#course-error').textContent = err.details ? Object.values(err.details).join(' · ') : err.message;
    }
  });
  $('#faculty-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const f = Object.fromEntries(new FormData(e.target).entries());
    try {
      const { user } = await Auth.createUser({ ...f, role: 'faculty' });
      toast(`Faculty account created for ${user.name}`, 'ok');
      e.target.reset();
      loadAll();
    } catch (err) {
      toast(err.details ? Object.values(err.details).join(' · ') : err.message, 'error');
    }
  });
  await loadAll();
}

/* ------------------------------------------------------------------ router */
const currentRoute = () => (location.hash.replace(/^#\/?/, '').split(/[/?]/)[0] || 'dashboard');
const routeArg = () => location.hash.replace(/^#\/?/, '').split('?')[0].split('/')[1];

async function render() {
  stopLive();
  let route = currentRoute();
  if (!session.user && route !== 'login') {
    location.hash = '#/login';
    return;
  }
  if (session.user && route === 'login') route = 'dashboard';
  updateChrome();
  window.scrollTo(0, 0);
  const role = session.user?.role;
  try {
    if (route === 'login') viewLogin();
    else if (route === 'courses' && role === 'student') await viewCourses();
    else if (route === 'sessions' && role !== 'student') await viewSessions(routeArg());
    else if (route === 'reports' && role !== 'student') await viewReports(routeArg());
    else if (route === 'manage') await viewManage();
    else if (role === 'student') await viewStudentDashboard();
    else await viewStaffDashboard();
  } catch (err) {
    app.innerHTML = `<div class="card empty"><strong>Something went wrong</strong>${esc(err.message)}</div>`;
  }
  if (session.user) refreshCluster().catch(() => {});
}

/* ------------------------------------------------------------------ events */
document.addEventListener('click', async (e) => {
  const el = e.target.closest('[data-action]');
  if (!el) return;
  const { action, id } = el.dataset;
  try {
    switch (action) {
      case 'auth-tab':
        viewLogin(el.dataset.mode);
        break;
      case 'demo':
        $('#email').value = el.dataset.email;
        $('#password').value = el.dataset.password;
        break;
      case 'enroll':
        await Courses.enroll(id);
        toast('Enrolled ✓', 'ok');
        viewCourses();
        break;
      case 'drop':
        await Courses.drop(id);
        toast('Course dropped');
        viewCourses();
        break;
      case 'mark':
        el.parentElement.querySelectorAll('button').forEach((b) => b.removeAttribute('class'));
        el.className = `on-${el.dataset.status}`;
        await Attendance.mark(id, el.dataset.status);
        break;
      case 'close-session':
        await Attendance.close(id);
        toast('Session closed', 'ok');
        viewSessionDetail(id);
        break;
      case 'export-csv':
        exportCsv();
        break;
      case 'delete-course':
        await Courses.remove(id);
        toast('Course deleted');
        viewManage();
        break;
      default:
    }
  } catch (err) {
    toast(err.message, 'error');
  }
});

$('#logout-btn').addEventListener('click', () => {
  session.clear();
  stopLive();
  toast('Signed out');
  location.hash = '#/login';
});
$('#cluster-refresh').addEventListener('click', () => refreshCluster().catch(() => {}));

setUnauthorizedHandler(() => {
  toast('Your session expired - please sign in again', 'error');
  location.hash = '#/login';
});

window.addEventListener('hashchange', render);
setInterval(() => {
  if (session.user && document.visibilityState === 'visible') refreshCluster().catch(() => {});
}, 15000);

render();
