#!/usr/bin/env node
'use strict';
/**
 * Local development gateway (zero dependencies) - plays the role of the Kubernetes Ingress:
 *   /                      -> static frontend (frontend/public)
 *   /api/auth/*            -> auth-service        (http://localhost:4001)
 *   /api/courses/*         -> course-service      (http://localhost:4002)
 *   /api/attendance/*      -> attendance-service  (http://localhost:4003)  [JWT checked at the gateway]
 * It also applies a simple per-IP rate limit, like the NGINX ingress annotations do.
 */
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');

const PORT = Number(process.env.GATEWAY_PORT || 3000);
const ROOT = path.resolve(__dirname, '..', 'frontend', 'public');
const ROUTES = [
  { prefix: '/api/auth', target: process.env.AUTH_URL || 'http://localhost:4001' },
  { prefix: '/api/courses', target: process.env.COURSE_URL || 'http://localhost:4002' },
  { prefix: '/api/attendance', target: process.env.ATTENDANCE_URL || 'http://localhost:4003', jwt: true },
];
const RATE_LIMIT_RPS = Number(process.env.RATE_LIMIT_RPS || 50);
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.json': 'application/json',
  '.ico': 'image/x-icon',
  '.png': 'image/png',
};

// --- token bucket per client IP (rate limiting concept from CO-4) ---
const buckets = new Map();
function allow(ip) {
  const now = Date.now();
  const b = buckets.get(ip) || { tokens: RATE_LIMIT_RPS, at: now };
  b.tokens = Math.min(RATE_LIMIT_RPS * 2, b.tokens + ((now - b.at) / 1000) * RATE_LIMIT_RPS);
  b.at = now;
  if (b.tokens < 1) {
    buckets.set(ip, b);
    return false;
  }
  b.tokens -= 1;
  buckets.set(ip, b);
  return true;
}

function proxy(req, res, target, extraHeaders = {}) {
  const url = new URL(req.url, target);
  const upstream = http.request(
    url,
    { method: req.method, headers: { ...req.headers, host: url.host, 'x-forwarded-for': req.socket.remoteAddress, ...extraHeaders } },
    (up) => {
      res.writeHead(up.statusCode, up.headers);
      up.pipe(res);
    },
  );
  upstream.on('error', () => {
    if (!res.headersSent) res.writeHead(502, { 'content-type': 'application/json' });
    res.end(JSON.stringify({ error: { code: 'BAD_GATEWAY', message: `Upstream ${target} is not reachable` } }));
  });
  req.pipe(upstream);
}

/** External auth, exactly like the NGINX `auth-url` annotation: ask auth-service /verify first. */
function verifyJwt(req) {
  return new Promise((resolve) => {
    const r = http.request(
      new URL('/api/auth/verify', ROUTES[0].target),
      { method: 'GET', headers: { authorization: req.headers.authorization || '' } },
      (up) => {
        up.resume();
        resolve(up.statusCode === 200 ? { 'x-user-id': up.headers['x-user-id'], 'x-user-role': up.headers['x-user-role'] } : null);
      },
    );
    r.on('error', () => resolve(null));
    r.end();
  });
}

function serveStatic(req, res) {
  const clean = decodeURIComponent(new URL(req.url, 'http://x').pathname);
  let file = path.join(ROOT, clean);
  if (!file.startsWith(ROOT)) {
    res.writeHead(403).end();
    return;
  }
  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) file = path.join(ROOT, 'index.html');
  res.writeHead(200, {
    'content-type': MIME[path.extname(file)] || 'application/octet-stream',
    'cache-control': 'no-cache',
    // same strict CSP as the production NGINX config (frontend/nginx.conf)
    'content-security-policy': "default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'",
  });
  fs.createReadStream(file).pipe(res);
}

http
  .createServer(async (req, res) => {
    // internal service-to-service APIs and metrics are never exposed through the gateway
    if (req.url.startsWith('/internal/') || req.url === '/metrics') {
      res.writeHead(404, { 'content-type': 'application/json' });
      return res.end(JSON.stringify({ error: { code: 'NOT_FOUND', message: 'Not found' } }));
    }
    const route = ROUTES.find((r) => req.url === r.prefix || req.url.startsWith(`${r.prefix}/`) || req.url.startsWith(`${r.prefix}?`));
    if (!route) return serveStatic(req, res);
    if (!allow(req.socket.remoteAddress)) {
      res.writeHead(429, { 'content-type': 'application/json', 'retry-after': '1' });
      return res.end(JSON.stringify({ error: { code: 'TOO_MANY_REQUESTS', message: 'Rate limit exceeded (gateway)' } }));
    }
    if (route.jwt) {
      const identity = await verifyJwt(req);
      if (!identity) {
        res.writeHead(401, { 'content-type': 'application/json' });
        return res.end(JSON.stringify({ error: { code: 'UNAUTHORIZED', message: 'Gateway: missing or invalid token' } }));
      }
      return proxy(req, res, route.target, identity);
    }
    return proxy(req, res, route.target);
  })
  .listen(PORT, () => {
    console.log(`[gateway] SmartAttend running at http://localhost:${PORT}`);
  });
