#!/usr/bin/env node
'use strict';
/**
 * Runs an npm script in every service:  node tools/run-all.js <install|test|lint>
 * (cross-platform replacement for a bash for-loop).
 */
const { spawnSync } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');

const task = process.argv[2] || 'test';
const root = path.resolve(__dirname, '..');
const services = fs.readdirSync(path.join(root, 'services')).filter((d) => fs.existsSync(path.join(root, 'services', d, 'package.json')));
const npm = process.platform === 'win32' ? 'npm.cmd' : 'npm';

let failed = 0;
for (const svc of services) {
  console.log(`\n=== ${svc}: npm ${task} ===`);
  const args = task === 'install' ? ['install', '--no-audit', '--no-fund'] : ['run', task];
  const r = spawnSync(npm, args, { cwd: path.join(root, 'services', svc), stdio: 'inherit', shell: process.platform === 'win32' });
  if (r.status !== 0) failed += 1;
}
if (failed) {
  console.error(`\n${failed} service(s) failed "${task}"`);
  process.exit(1);
}
console.log(`\nAll ${services.length} services passed "${task}"`);
