#!/usr/bin/env node
'use strict';
/**
 * `npm run dev` - starts the whole system locally WITHOUT Docker or Kubernetes:
 * 3 microservices (in-memory storage) + the dev gateway serving the UI on http://localhost:3000.
 * Works on Windows, macOS and Linux (plain Node.js, no extra packages).
 *
 * Set DB_DRIVER=postgres and DATABASE_URL=... to use a real PostgreSQL instead.
 */
const { spawn } = require('node:child_process');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const colors = { auth: 35, course: 36, attendance: 33, gateway: 32 };
const procs = [
  { name: 'auth', cwd: 'services/auth-service', args: ['src/server.js'], env: { PORT: '4001' } },
  { name: 'course', cwd: 'services/course-service', args: ['src/server.js'], env: { PORT: '4002' } },
  {
    name: 'attendance',
    cwd: 'services/attendance-service',
    args: ['src/server.js'],
    env: { PORT: '4003', COURSE_URL: 'http://localhost:4002' },
  },
  { name: 'gateway', cwd: '.', args: ['tools/dev-gateway.js'], env: {} },
];

const children = procs.map((p) => {
  const child = spawn(process.execPath, p.args, {
    cwd: path.join(root, p.cwd),
    env: { LOG_FORMAT: 'pretty', SHUTDOWN_DELAY_MS: '0', ...process.env, ...p.env },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  const prefix = `\x1b[${colors[p.name]}m[${p.name.padEnd(10)}]\x1b[0m `;
  const pipe = (stream, out) =>
    stream.on('data', (d) =>
      String(d)
        .split('\n')
        .filter(Boolean)
        .forEach((line) => out.write(`${prefix}${line}\n`)),
    );
  pipe(child.stdout, process.stdout);
  pipe(child.stderr, process.stderr);
  child.on('exit', (code) => console.log(`${prefix}exited with code ${code}`));
  return child;
});

const stop = () => {
  children.forEach((c) => c.kill('SIGTERM'));
  setTimeout(() => process.exit(0), 500);
};
process.on('SIGINT', stop);
process.on('SIGTERM', stop);
