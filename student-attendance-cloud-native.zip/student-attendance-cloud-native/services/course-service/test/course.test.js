'use strict';
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { createApp } = require('../src/app');
const { MemoryCourseRepository } = require('../src/repository/memory');
const { PostgresCourseRepository } = require('../src/repository/postgres');
const { createLogger } = require('../src/kit/logger');
const jwt = require('../src/kit/jwt');
const { COURSES } = require('../src/seed');

process.env.LOG_SILENT = 'true';

const config = {
  port: 0,
  jwtSecret: 'test-secret',
  jwtIssuer: 'smartattend-auth',
  internalToken: 'internal-test-token',
  maxCoursesPerStudent: 3,
  chaosErrorRate: 0,
  chaosLatencyMs: 0,
  simulateReadinessFailure: false,
  shutdownDelayMs: 0,
  info: { service: 'course-service', version: 'test', track: 'stable', pod: 'test-pod' },
};
const sign = (claims) => jwt.sign(claims, config.jwtSecret, { issuer: config.jwtIssuer });
const admin = sign({ sub: '1', email: 'admin@test', name: 'Admin', role: 'admin' });
const meera = sign({ sub: '2', email: 'faculty@smartattend.local', name: 'Dr. Meera Iyer', role: 'faculty' });
const arjun = sign({ sub: '3', email: 'faculty2@smartattend.local', name: 'Prof. Arjun Rao', role: 'faculty' });
const aarav = sign({ sub: '4', email: 'student@smartattend.local', name: 'Aarav Sharma', role: 'student', rollNo: '22CS001' });
const newbie = sign({ sub: '9', email: 'new@test', name: 'New Student', role: 'student', rollNo: '23CS099' });

let server;
let base;
let repo;

async function makeRepo() {
  if (process.env.TEST_DB_DRIVER !== 'postgres') return new MemoryCourseRepository();
  const { createPool } = require('../src/kit/db');
  const pool = createPool({ logger: createLogger('test') });
  await pool.query('DROP TABLE IF EXISTS enrollments, courses CASCADE');
  return new PostgresCourseRepository(pool);
}

const api = async (method, path, body, token, headers = {}) => {
  const res = await fetch(`${base}${path}`, {
    method,
    headers: { 'content-type': 'application/json', ...(token ? { authorization: `Bearer ${token}` } : {}), ...headers },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  return { status: res.status, headers: res.headers, body: text ? JSON.parse(text) : null };
};

before(async () => {
  const logger = createLogger('test');
  repo = await makeRepo();
  await repo.init();
  assert.equal(await repo.seed(COURSES), COURSES.length);
  assert.equal(await repo.seed(COURSES), 0, 'seeding twice is a no-op');
  const app = createApp({ config, repo, logger });
  server = app.server;
  app.lifecycle.markStarted();
  await new Promise((r) => server.listen(0, r));
  base = `http://127.0.0.1:${server.address().port}`;
});

after(async () => {
  server.close();
  await repo.close();
});

test('public course list, search and department filter', async () => {
  const all = await api('GET', '/api/courses');
  assert.equal(all.status, 200);
  assert.equal(all.body.total, COURSES.length);
  assert.deepEqual(all.body.departments, ['Computer Science', 'Humanities']);
  const cs501 = all.body.courses.find((c) => c.code === 'CS501');
  assert.equal(cs501.enrolledCount, 5);
  const search = await api('GET', '/api/courses?q=cloud');
  assert.equal(search.body.total, 1);
  const hum = await api('GET', '/api/courses?department=Humanities');
  assert.equal(hum.body.courses[0].code, 'HS501');
});

test('"mine" depends on the role', async () => {
  assert.equal((await api('GET', '/api/courses/mine')).status, 401);
  const student = await api('GET', '/api/courses/mine', null, aarav);
  assert.deepEqual(student.body.courses.map((c) => c.code), ['CS501', 'CS502', 'CS503', 'CS504']);
  const faculty = await api('GET', '/api/courses/mine', null, meera);
  assert.deepEqual(faculty.body.courses.map((c) => c.code), ['CS501', 'CS502']);
  const adm = await api('GET', '/api/courses/mine', null, admin);
  assert.equal(adm.body.total, COURSES.length);
});

test('roster is only visible to the course faculty and admins', async () => {
  const id = (await api('GET', '/api/courses?q=CS501')).body.courses[0].id;
  const ok = await api('GET', `/api/courses/${id}/roster`, null, meera);
  assert.equal(ok.status, 200);
  assert.equal(ok.body.students.length, 5);
  assert.equal(ok.body.students[0].rollNo, '22CS001');
  assert.equal((await api('GET', `/api/courses/${id}/roster`, null, arjun)).status, 403);
  assert.equal((await api('GET', `/api/courses/${id}/roster`, null, aarav)).status, 403);
  assert.equal((await api('GET', `/api/courses/${id}/roster`, null, admin)).status, 200);
});

test('admin creates and deletes courses with validation', async () => {
  const course = { code: 'cs599', name: 'Kubernetes Lab', department: 'Computer Science', semester: 5, credits: 2, facultyEmail: 'faculty@smartattend.local', facultyName: 'Dr. Meera Iyer' };
  assert.equal((await api('POST', '/api/courses', course, meera)).status, 403);
  const created = await api('POST', '/api/courses', course, admin);
  assert.equal(created.status, 201);
  assert.equal(created.body.course.code, 'CS599');
  assert.equal((await api('POST', '/api/courses', course, admin)).status, 409);
  const bad = await api('POST', '/api/courses', { code: '1', semester: 99 }, admin);
  assert.equal(bad.status, 422);
  assert.ok(bad.body.error.details.code && bad.body.error.details.semester && bad.body.error.details.facultyEmail);
  assert.equal((await api('DELETE', `/api/courses/${created.body.course.id}`, null, admin)).status, 200);
  assert.equal((await api('GET', `/api/courses/${created.body.course.id}`)).status, 404);
});

test('students enroll and drop; duplicates and quota are rejected', async () => {
  const list = (await api('GET', '/api/courses')).body.courses;
  const [c1, c2, c3, c4] = list;
  const e1 = await api('POST', `/api/courses/${c1.id}/enroll`, null, newbie);
  assert.equal(e1.status, 201);
  assert.equal(e1.body.enrollment.rollNo, '23CS099');
  assert.equal((await api('POST', `/api/courses/${c1.id}/enroll`, null, newbie)).status, 409);
  assert.equal((await api('POST', `/api/courses/${c1.id}/enroll`, null, meera)).status, 403, 'faculty cannot enroll');
  await api('POST', `/api/courses/${c2.id}/enroll`, null, newbie);
  await api('POST', `/api/courses/${c3.id}/enroll`, null, newbie);
  const quota = await api('POST', `/api/courses/${c4.id}/enroll`, null, newbie);
  assert.equal(quota.status, 429);
  assert.equal(quota.body.error.code, 'QUOTA_EXCEEDED');
  assert.equal((await api('DELETE', `/api/courses/${c3.id}/enroll`, null, newbie)).status, 200);
  assert.equal((await api('DELETE', `/api/courses/${c3.id}/enroll`, null, newbie)).status, 404);
});

test('internal roster API needs the internal token', async () => {
  assert.equal((await api('GET', '/internal/courses/1/roster')).status, 403);
  const r = await api('GET', '/internal/courses/1/roster', null, null, { 'x-internal-token': config.internalToken });
  assert.equal(r.status, 200);
  assert.equal(r.body.course.code, 'CS501');
  assert.ok(r.body.students.length >= 5);
  assert.equal((await api('GET', '/internal/courses/999/roster', null, null, { 'x-internal-token': config.internalToken })).status, 404);
});

test('stats, info and health', async () => {
  const stats = await api('GET', '/api/courses/stats');
  assert.equal(stats.body.faculty, 2);
  assert.ok(stats.body.enrollments >= 17);
  const info = await api('GET', '/api/courses/_info');
  assert.equal(info.headers.get('x-deploy-track'), 'stable');
  assert.equal((await api('GET', '/readyz')).status, 200);
});
