'use strict';
const { createLogger } = require('./kit/logger');
const { createPool, waitForDatabase } = require('./kit/db');
const { loadConfig } = require('./config');
const { createApp } = require('./app');
const { MemoryCourseRepository } = require('./repository/memory');
const { PostgresCourseRepository } = require('./repository/postgres');
const { COURSES } = require('./seed');

async function main() {
  const logger = createLogger('course-service');
  const config = loadConfig();

  let repo;
  if (config.dbDriver === 'postgres') {
    const pool = createPool({ logger });
    await waitForDatabase(pool, logger);
    repo = new PostgresCourseRepository(pool);
  } else {
    logger.warn('using in-memory storage (DB_DRIVER=memory) - data is lost on restart');
    repo = new MemoryCourseRepository();
  }
  await repo.init();
  if (config.seedCourses) logger.info('course seed checked', { inserted: await repo.seed(COURSES) });

  const { server, lifecycle } = createApp({ config, repo, logger });
  server.listen(config.port, () => {
    lifecycle.markStarted();
    logger.info('course-service listening', { port: config.port, db: config.dbDriver, ...config.info });
  });
  lifecycle.handleSignals(server, () => repo.close());
}

main().catch((err) => {
  // eslint-disable-next-line no-console
  console.error(JSON.stringify({ level: 'fatal', service: 'course-service', msg: err.message, stack: err.stack }));
  process.exit(1);
});
