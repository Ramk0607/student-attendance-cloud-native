'use strict';
/** Demo courses + enrollments (matching the demo users seeded by auth-service). */
const STUDENTS = [
  { email: 'student@smartattend.local', name: 'Aarav Sharma', rollNo: '22CS001' },
  { email: 'priya@smartattend.local', name: 'Priya Nair', rollNo: '22CS002' },
  { email: 'rahul@smartattend.local', name: 'Rahul Verma', rollNo: '22CS003' },
  { email: 'sneha@smartattend.local', name: 'Sneha Reddy', rollNo: '22CS004' },
  { email: 'karthik@smartattend.local', name: 'Karthik Rao', rollNo: '22CS005' },
];
const MEERA = { facultyEmail: 'faculty@smartattend.local', facultyName: 'Dr. Meera Iyer' };
const ARJUN = { facultyEmail: 'faculty2@smartattend.local', facultyName: 'Prof. Arjun Rao' };

const COURSES = [
  { code: 'CS501', name: 'Cloud Native Application Development', department: 'Computer Science', semester: 5, credits: 4, schedule: 'Mon/Wed 09:00', room: 'LH-201', ...MEERA, students: STUDENTS },
  { code: 'CS502', name: 'Machine Learning', department: 'Computer Science', semester: 5, credits: 4, schedule: 'Tue/Thu 11:00', room: 'LH-105', ...MEERA, students: STUDENTS },
  { code: 'CS503', name: 'Compiler Design', department: 'Computer Science', semester: 5, credits: 3, schedule: 'Mon/Fri 14:00', room: 'LH-204', ...ARJUN, students: STUDENTS.slice(0, 4) },
  { code: 'CS504', name: 'Computer Networks', department: 'Computer Science', semester: 5, credits: 3, schedule: 'Wed/Fri 10:00', room: 'LAB-3', ...ARJUN, students: STUDENTS.slice(0, 3) },
  { code: 'HS501', name: 'Professional Ethics', department: 'Humanities', semester: 5, credits: 2, schedule: 'Thu 15:00', room: 'SH-01', ...ARJUN, students: [] },
];

module.exports = { COURSES, STUDENTS };
