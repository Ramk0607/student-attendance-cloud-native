'use strict';
/** PostgreSQL course + enrollment store (schema created idempotently under an advisory lock). */
const { toIso } = require('../kit/db');

const SCHEMA = `
DO $$
BEGIN
  PERFORM pg_advisory_xact_lock(5202);
  CREATE TABLE IF NOT EXISTS courses (
    id            SERIAL PRIMARY KEY,
    code          VARCHAR(20)  NOT NULL UNIQUE,
    name          VARCHAR(200) NOT NULL,
    department    VARCHAR(100) NOT NULL,
    semester      INT          NOT NULL CHECK (semester BETWEEN 1 AND 12),
    credits       INT          NOT NULL CHECK (credits BETWEEN 0 AND 10),
    schedule      VARCHAR(100) NOT NULL DEFAULT '',
    room          VARCHAR(50)  NOT NULL DEFAULT '',
    faculty_email VARCHAR(255) NOT NULL,
    faculty_name  VARCHAR(120) NOT NULL,
    created_at    TIMESTAMPTZ  NOT NULL DEFAULT now()
  );
  CREATE INDEX IF NOT EXISTS idx_courses_faculty ON courses (faculty_email);
  CREATE TABLE IF NOT EXISTS enrollments (
    id            SERIAL PRIMARY KEY,
    course_id     INT          NOT NULL REFERENCES courses (id) ON DELETE CASCADE,
    student_email VARCHAR(255) NOT NULL,
    student_name  VARCHAR(120) NOT NULL,
    roll_no       VARCHAR(20),
    enrolled_at   TIMESTAMPTZ  NOT NULL DEFAULT now(),
    UNIQUE (course_id, student_email)
  );
  CREATE INDEX IF NOT EXISTS idx_enrollments_student ON enrollments (student_email);
END
$$;`;

const mapCourse = (r) =>
  r && {
    id: Number(r.id),
    code: r.code,
    name: r.name,
    department: r.department,
    semester: Number(r.semester),
    credits: Number(r.credits),
    schedule: r.schedule,
    room: r.room,
    facultyEmail: r.faculty_email,
    facultyName: r.faculty_name,
    createdAt: toIso(r.created_at),
    enrolledCount: Number(r.enrolled_count || 0),
  };

const isUnique = (err) => err.code === '23505' || /duplicate key/i.test(err.message);
const SELECT = `SELECT c.*, (SELECT count(*) FROM enrollments e WHERE e.course_id = c.id)::int AS enrolled_count FROM courses c`;

class PostgresCourseRepository {
  constructor(pool) {
    this.pool = pool;
  }

  async init() {
    await this.pool.query(SCHEMA);
  }

  async ping() {
    await this.pool.query('SELECT 1');
    return true;
  }

  /** Seeds demo data only into an empty database. */
  async seed(courses) {
    const { rows } = await this.pool.query('SELECT count(*)::int AS n FROM courses');
    if (Number(rows[0].n) > 0) return 0;
    let inserted = 0;
    for (const { students, ...c } of courses) {
      let course;
      try {
        course = await this.create(c);
      } catch (err) {
        if (err.code === 'DUPLICATE') continue; // another replica seeded it concurrently
        throw err;
      }
      inserted += 1;
      for (const s of students) await this.enroll(course.id, s).catch(() => {});
    }
    return inserted;
  }

  async list({ q, department, facultyEmail, studentEmail } = {}) {
    const { rows } = await this.pool.query(
      `${SELECT}
       WHERE ($1::text IS NULL OR c.code ILIKE $1 OR c.name ILIKE $1 OR c.faculty_name ILIKE $1 OR c.department ILIKE $1)
         AND ($2::text IS NULL OR c.department = $2)
         AND ($3::text IS NULL OR c.faculty_email = $3)
         AND ($4::text IS NULL OR EXISTS (SELECT 1 FROM enrollments e WHERE e.course_id = c.id AND e.student_email = $4))
       ORDER BY c.code`,
      [q ? `%${q}%` : null, department || null, facultyEmail || null, studentEmail || null],
    );
    return rows.map(mapCourse);
  }

  async departments() {
    const { rows } = await this.pool.query('SELECT DISTINCT department FROM courses ORDER BY department');
    return rows.map((r) => r.department);
  }

  async get(id) {
    const { rows } = await this.pool.query(`${SELECT} WHERE c.id = $1::int`, [Number(id)]);
    return mapCourse(rows[0]) || null;
  }

  async create(d) {
    try {
      const { rows } = await this.pool.query(
        `INSERT INTO courses (code, name, department, semester, credits, schedule, room, faculty_email, faculty_name)
         VALUES ($1, $2, $3, $4::int, $5::int, $6, $7, $8, $9) RETURNING *, 0 AS enrolled_count`,
        [d.code, d.name, d.department, d.semester, d.credits, d.schedule || '', d.room || '', d.facultyEmail, d.facultyName],
      );
      return mapCourse(rows[0]);
    } catch (err) {
      if (isUnique(err)) throw Object.assign(new Error('duplicate code'), { code: 'DUPLICATE' });
      throw err;
    }
  }

  async remove(id) {
    const { rows } = await this.pool.query('DELETE FROM courses WHERE id = $1::int RETURNING id', [Number(id)]);
    return rows.length > 0;
  }

  async roster(courseId) {
    const { rows } = await this.pool.query(
      'SELECT student_email, student_name, roll_no, enrolled_at FROM enrollments WHERE course_id = $1::int ORDER BY roll_no NULLS LAST, student_name',
      [Number(courseId)],
    );
    return rows.map((r) => ({ email: r.student_email, name: r.student_name, rollNo: r.roll_no, enrolledAt: toIso(r.enrolled_at) }));
  }

  async enroll(courseId, { email, name, rollNo }) {
    try {
      const { rows } = await this.pool.query(
        `INSERT INTO enrollments (course_id, student_email, student_name, roll_no) VALUES ($1::int, $2, $3, $4)
         RETURNING course_id, student_email, student_name, roll_no, enrolled_at`,
        [Number(courseId), email, name, rollNo || null],
      );
      const r = rows[0];
      return { courseId: Number(r.course_id), email: r.student_email, name: r.student_name, rollNo: r.roll_no, enrolledAt: toIso(r.enrolled_at) };
    } catch (err) {
      if (isUnique(err)) throw Object.assign(new Error('already enrolled'), { code: 'DUPLICATE' });
      throw err;
    }
  }

  async unenroll(courseId, email) {
    const { rows } = await this.pool.query(
      'DELETE FROM enrollments WHERE course_id = $1::int AND student_email = $2 RETURNING id',
      [Number(courseId), email],
    );
    return rows.length > 0;
  }

  async countForStudent(email) {
    const { rows } = await this.pool.query('SELECT count(*)::int AS n FROM enrollments WHERE student_email = $1', [email]);
    return Number(rows[0].n);
  }

  async stats() {
    const { rows } = await this.pool.query(
      `SELECT (SELECT count(*) FROM courses)::int AS courses,
              (SELECT count(*) FROM enrollments)::int AS enrollments,
              (SELECT count(DISTINCT faculty_email) FROM courses)::int AS faculty,
              (SELECT count(DISTINCT student_email) FROM enrollments)::int AS students`,
    );
    const r = rows[0];
    return { courses: Number(r.courses), enrollments: Number(r.enrollments), faculty: Number(r.faculty), students: Number(r.students) };
  }

  async close() {
    await this.pool.end();
  }
}

module.exports = { PostgresCourseRepository };
