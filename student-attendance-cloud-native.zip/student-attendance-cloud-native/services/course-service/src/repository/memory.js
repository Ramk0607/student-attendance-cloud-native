'use strict';
/** In-memory course store - used for local development and unit tests. */
const dup = (msg) => Object.assign(new Error(msg), { code: 'DUPLICATE' });

class MemoryCourseRepository {
  constructor() {
    this.courses = new Map();
    this.enrollments = []; // { courseId, email, name, rollNo, enrolledAt }
    this.nextId = 1;
  }

  async init() {}

  async ping() {
    return true;
  }

  withCount(c) {
    return { ...c, enrolledCount: this.enrollments.filter((e) => e.courseId === c.id).length };
  }

  async seed(courses) {
    if (this.courses.size > 0) return 0;
    for (const { students, ...c } of courses) {
      const created = await this.create(c);
      for (const s of students) await this.enroll(created.id, s);
    }
    return courses.length;
  }

  async list({ q, department, facultyEmail, studentEmail } = {}) {
    const term = q ? q.toLowerCase() : null;
    return [...this.courses.values()]
      .filter((c) => !term || [c.code, c.name, c.facultyName, c.department].some((f) => f.toLowerCase().includes(term)))
      .filter((c) => !department || c.department === department)
      .filter((c) => !facultyEmail || c.facultyEmail === facultyEmail)
      .filter((c) => !studentEmail || this.enrollments.some((e) => e.courseId === c.id && e.email === studentEmail))
      .sort((a, b) => a.code.localeCompare(b.code))
      .map((c) => this.withCount(c));
  }

  async departments() {
    return [...new Set([...this.courses.values()].map((c) => c.department))].sort();
  }

  async get(id) {
    const c = this.courses.get(Number(id));
    return c ? this.withCount(c) : null;
  }

  async create(data) {
    if ([...this.courses.values()].some((c) => c.code === data.code)) throw dup('duplicate code');
    const c = {
      id: this.nextId++,
      code: data.code,
      name: data.name,
      department: data.department,
      semester: data.semester,
      credits: data.credits,
      schedule: data.schedule || '',
      room: data.room || '',
      facultyEmail: data.facultyEmail,
      facultyName: data.facultyName,
      createdAt: new Date().toISOString(),
    };
    this.courses.set(c.id, c);
    return this.withCount(c);
  }

  async remove(id) {
    const existed = this.courses.delete(Number(id));
    this.enrollments = this.enrollments.filter((e) => e.courseId !== Number(id));
    return existed;
  }

  async roster(courseId) {
    return this.enrollments
      .filter((e) => e.courseId === Number(courseId))
      .sort((a, b) => String(a.rollNo).localeCompare(String(b.rollNo)))
      .map(({ email, name, rollNo, enrolledAt }) => ({ email, name, rollNo, enrolledAt }));
  }

  async enroll(courseId, { email, name, rollNo }) {
    if (this.enrollments.some((e) => e.courseId === Number(courseId) && e.email === email)) throw dup('already enrolled');
    const e = { courseId: Number(courseId), email, name, rollNo: rollNo || null, enrolledAt: new Date().toISOString() };
    this.enrollments.push(e);
    return { ...e };
  }

  async unenroll(courseId, email) {
    const before = this.enrollments.length;
    this.enrollments = this.enrollments.filter((e) => !(e.courseId === Number(courseId) && e.email === email));
    return this.enrollments.length < before;
  }

  async countForStudent(email) {
    return this.enrollments.filter((e) => e.email === email).length;
  }

  async stats() {
    return {
      courses: this.courses.size,
      enrollments: this.enrollments.length,
      faculty: new Set([...this.courses.values()].map((c) => c.facultyEmail)).size,
      students: new Set(this.enrollments.map((e) => e.email)).size,
    };
  }

  async close() {}
}

module.exports = { MemoryCourseRepository };
