'use strict';
const { Router, HttpError, createServer } = require('./kit/http');
const { createMetrics } = require('./kit/metrics');
const { createLifecycle } = require('./kit/lifecycle');
const { authenticate, requireRole, requireInternalToken } = require('./kit/auth');

const CODE_RE = /^[A-Z]{2,4}\d{3,4}[A-Z]?$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

function validateCourse(body) {
  const errors = {};
  const c = {
    code: String(body.code || '').trim().toUpperCase(),
    name: String(body.name || '').trim(),
    department: String(body.department || '').trim(),
    semester: Number(body.semester),
    credits: Number(body.credits),
    schedule: String(body.schedule || '').trim(),
    room: String(body.room || '').trim(),
    facultyEmail: String(body.facultyEmail || '').trim().toLowerCase(),
    facultyName: String(body.facultyName || '').trim(),
  };
  if (!CODE_RE.test(c.code)) errors.code = 'Course code like CS501';
  if (c.name.length < 3 || c.name.length > 200) errors.name = 'Course name is required (3-200 characters)';
  if (!c.department) errors.department = 'Department is required';
  if (!Number.isInteger(c.semester) || c.semester < 1 || c.semester > 12) errors.semester = 'Semester must be 1-12';
  if (!Number.isInteger(c.credits) || c.credits < 0 || c.credits > 10) errors.credits = 'Credits must be 0-10';
  if (!EMAIL_RE.test(c.facultyEmail)) errors.facultyEmail = 'Faculty email is required';
  if (c.facultyName.length < 2) errors.facultyName = 'Faculty name is required';
  if (Object.keys(errors).length) throw new HttpError(422, 'Validation failed', 'VALIDATION_FAILED', errors);
  return c;
}

const parseId = (raw) => {
  const id = Number(raw);
  if (!Number.isInteger(id) || id <= 0) throw new HttpError(400, 'Course id must be a positive integer');
  return id;
};

function createApp({ config, repo, logger }) {
  const router = new Router();
  const metrics = createMetrics('course-service', { track: config.info.track });
  const lifecycle = createLifecycle({
    logger,
    checks: { database: () => repo.ping() },
    simulateFailure: config.simulateReadinessFailure,
    shutdownDelayMs: config.shutdownDelayMs,
  });
  const requireAuth = authenticate({ secret: config.jwtSecret, issuer: config.jwtIssuer });
  const adminOnly = requireRole('admin');
  const studentOnly = requireRole('student');
  const internalOnly = requireInternalToken(config.internalToken);

  const loadCourse = async (id) => {
    const course = await repo.get(parseId(id));
    if (!course) throw new HttpError(404, 'Course not found');
    return course;
  };
  const canManage = (user, course) => user.role === 'admin' || (user.role === 'faculty' && course.facultyEmail === user.email);

  metrics.gauge('smartattend_enrollments_total', 'Number of course enrollments', async () => (await repo.stats()).enrollments);
  lifecycle.register(router);
  router.get('/metrics', async (req, res) => res.text(await metrics.render(), 200, 'text/plain; version=0.0.4'));

  // ---- Public API (routed by the Ingress at /api/courses) ----
  router.get('/api/courses/_info', (req, res) => res.json(config.info));
  router.get('/api/courses/stats', async (req, res) => res.json(await repo.stats()));

  router.get('/api/courses', async (req, res) => {
    const q = req.query.q ? String(req.query.q).trim().slice(0, 100) : null;
    const courses = await repo.list({ q, department: req.query.department || null });
    res.json({ courses, total: courses.length, departments: await repo.departments() });
  });

  /** Student: enrolled courses. Faculty: courses they teach. Admin: everything. */
  router.get('/api/courses/mine', requireAuth, async (req, res) => {
    const { role, email } = req.user;
    const filter = role === 'student' ? { studentEmail: email } : role === 'faculty' ? { facultyEmail: email } : {};
    const courses = await repo.list(filter);
    res.json({ courses, total: courses.length });
  });

  router.get('/api/courses/:id', async (req, res) => res.json({ course: await loadCourse(req.params.id) }));

  router.get('/api/courses/:id/roster', requireAuth, async (req, res) => {
    const course = await loadCourse(req.params.id);
    if (!canManage(req.user, course)) throw new HttpError(403, 'Only the course faculty or an admin can view the roster');
    res.json({ course, students: await repo.roster(course.id) });
  });

  router.post('/api/courses', requireAuth, adminOnly, async (req, res) => {
    const data = validateCourse(req.body);
    try {
      const course = await repo.create(data);
      logger.info('course created', { courseId: course.id, code: course.code, by: req.user.email });
      res.json({ course }, 201);
    } catch (err) {
      if (err.code === 'DUPLICATE') throw new HttpError(409, `Course ${data.code} already exists`, 'CODE_TAKEN');
      throw err;
    }
  });

  router.delete('/api/courses/:id', requireAuth, adminOnly, async (req, res) => {
    const id = parseId(req.params.id);
    if (!(await repo.remove(id))) throw new HttpError(404, 'Course not found');
    res.json({ deleted: true, id });
  });

  router.post('/api/courses/:id/enroll', requireAuth, studentOnly, async (req, res) => {
    const course = await loadCourse(req.params.id);
    if ((await repo.countForStudent(req.user.email)) >= config.maxCoursesPerStudent) {
      throw new HttpError(429, `Quota reached: at most ${config.maxCoursesPerStudent} courses per student`, 'QUOTA_EXCEEDED');
    }
    try {
      const enrollment = await repo.enroll(course.id, { email: req.user.email, name: req.user.name, rollNo: req.user.rollNo });
      res.json({ enrollment, course: await repo.get(course.id) }, 201);
    } catch (err) {
      if (err.code === 'DUPLICATE') throw new HttpError(409, 'You are already enrolled in this course', 'ALREADY_ENROLLED');
      throw err;
    }
  });

  router.delete('/api/courses/:id/enroll', requireAuth, studentOnly, async (req, res) => {
    const course = await loadCourse(req.params.id);
    if (!(await repo.unenroll(course.id, req.user.email))) throw new HttpError(404, 'You are not enrolled in this course');
    res.json({ dropped: true, courseId: course.id });
  });

  // ---- Internal API (NOT exposed by the Ingress; called by attendance-service) ----
  router.get('/internal/courses/:id/roster', internalOnly, async (req, res) => {
    const course = await loadCourse(req.params.id);
    res.json({ course, students: await repo.roster(course.id) });
  });

  const server = createServer({
    router,
    logger,
    metrics,
    info: config.info,
    chaosErrorRate: config.chaosErrorRate,
    chaosLatencyMs: config.chaosLatencyMs,
  });
  return { server, lifecycle, router };
}

module.exports = { createApp, validateCourse };
