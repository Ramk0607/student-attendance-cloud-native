'use strict';
const { str, int, num, bool, secret, runtimeInfo } = require('./kit/config');
const pkg = require('../package.json');

function loadConfig() {
  return {
    port: int('PORT', 4002),
    dbDriver: str('DB_DRIVER', 'memory'), // memory | postgres
    jwtSecret: secret('JWT_SECRET', 'dev-only-insecure-jwt-secret-change-me'),
    jwtIssuer: str('JWT_ISSUER', 'smartattend-auth'),
    internalToken: secret('INTERNAL_TOKEN', 'dev-only-internal-token'),
    seedCourses: bool('SEED_COURSES', true),
    maxCoursesPerStudent: int('MAX_COURSES_PER_STUDENT', 8),
    chaosErrorRate: num('CHAOS_ERROR_RATE', 0),
    chaosLatencyMs: int('CHAOS_LATENCY_MS', 0),
    simulateReadinessFailure: bool('SIMULATE_READINESS_FAILURE', false),
    shutdownDelayMs: int('SHUTDOWN_DELAY_MS', 5000),
    info: runtimeInfo('course-service', pkg.version),
  };
}

module.exports = { loadConfig };
