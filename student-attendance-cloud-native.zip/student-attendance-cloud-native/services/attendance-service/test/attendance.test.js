'use strict';
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const { createApp } = require('../src/app');
const { AttendanceService } = require('../src/service');
const { createCourseClient } = require('../src/course-client');
const { MemoryAttendanceRepository } = require('../src/repository/memory');
const { PostgresAttendanceRepository } = require('../src/repository/postgres');
const { createLogger } = require('../src/kit/logger');
const jwt = require('../src/kit/jwt');

process.env.LOG_SILENT = 'true';

const config = {
  port: 0,
  jwtSecret: 'test-secret',
  jwtIssuer: 'smartattend-auth',
  internalToken: 'internal-test-token',
  minAttendancePercent: 75,
  criticalAttendancePercent: 65,
  codeValidityMinutes: 15,
  lateAfterMinutes: 10,
  chaosErrorRate: 0,
  chaosLatencyMs: 0,
  simulateReadinessFailure: false,
  shutdownDelayMs: 0,
  info: { service: 'attendance-service', version: 'test', track: 'stable', pod: 'test-pod' },
};
const sign = (c) => jwt.sign(c, config.jwtSecret, { issuer: config.jwtIssuer });
const meera = sign({ sub: '2', email: 'faculty@smartattend.local', name: 'Dr. Meera Iyer', role: 'faculty' });
const arjun = sign({ sub: '3', email: 'faculty2@smartattend.local', name: 'Prof. Arjun Rao', role: 'faculty' });
const admin = sign({ sub: '1', email: 'admin@test', name: 'Admin', role: 'admin' });
const aarav = sign({ sub: '4', email: 'aarav@test', name: 'Aarav Sharma', role: 'student', rollNo: '22CS001' });
const priya = sign({ sub: '5', email: 'priya@test', name: 'Priya Nair', role: 'student', rollNo: '22CS002' });
const rahul = sign({ sub: '6', email: 'rahul@test', name: 'Rahul Verma', role: 'student', rollNo: '22CS003' });
const outsider = sign({ sub: '7', email: 'out@test', name: 'Outsider', role: 'student', rollNo: '22ME001' });

// ---- Fake course-service (real HTTP, so the real course client is exercised) ----
const ROSTERS = {
  1: {
    course: { id: 1, code: 'CS501', name: 'Cloud Native Application Development', facultyEmail: 'faculty@smartattend.local' },
    students: [
      { email: 'aarav@test', name: 'Aarav Sharma', rollNo: '22CS001' },
      { email: 'priya@test', name: 'Priya Nair', rollNo: '22CS002' },
      { email: 'rahul@test', name: 'Rahul Verma', rollNo: '22CS003' },
    ],
  },
  2: { course: { id: 2, code: 'HS501', name: 'Professional Ethics', facultyEmail: 'faculty2@smartattend.local' }, students: [] },
};
const courseServer = http.createServer((req, res) => {
  const m = /^\/internal\/courses\/(\d+)\/roster$/.exec(req.url);
  const send = (status, body) => {
    res.writeHead(status, { 'content-type': 'application/json' });
    res.end(JSON.stringify(body));
  };
  if (req.headers['x-internal-token'] !== config.internalToken) return send(403, {});
  if (!m || !ROSTERS[m[1]]) return send(404, {});
  return send(200, ROSTERS[m[1]]);
});

let server;
let base;
let repo;
let courses;

async function makeRepo() {
  if (process.env.TEST_DB_DRIVER !== 'postgres') return new MemoryAttendanceRepository();
  const { createPool } = require('../src/kit/db');
  const pool = createPool({ logger: createLogger('test') });
  await pool.query('DROP TABLE IF EXISTS attendance_records, class_sessions, app_meta CASCADE');
  return new PostgresAttendanceRepository(pool);
}

const api = async (method, path, body, token, headers = {}) => {
  const res = await fetch(`${base}${path}`, {
    method,
    headers: { 'content-type': 'application/json', ...(token ? { authorization: `Bearer ${token}` } : {}), ...headers },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  return { status: res.status, body: text ? JSON.parse(text) : null };
};
const start = (topic = 'Helm charts', token = meera, courseId = 1) => api('POST', '/api/attendance/sessions', { courseId, topic }, token);

before(async () => {
  await new Promise((r) => courseServer.listen(0, r));
  const logger = createLogger('test');
  repo = await makeRepo();
  await repo.init();
  courses = createCourseClient({ baseUrl: `http://127.0.0.1:${courseServer.address().port}`, internalToken: config.internalToken, logger });
  const service = new AttendanceService({ repo, courses, config, logger });
  const app = createApp({ config, repo, service, logger });
  server = app.server;
  app.lifecycle.markStarted();
  await new Promise((r) => server.listen(0, r));
  base = `http://127.0.0.1:${server.address().port}`;
});

after(async () => {
  server.close();
  courseServer.close();
  await repo.close();
});

test('authentication and roles are enforced', async () => {
  assert.equal((await api('GET', '/api/attendance/sessions')).status, 401);
  assert.equal((await start('x', aarav)).status, 403, 'students cannot start sessions');
  assert.equal((await start('x', arjun)).status, 403, 'only the course faculty can start a session');
  assert.equal((await api('GET', '/api/attendance/me', null, meera)).status, 403);
});

test('faculty starts a session -> roster snapshot, everyone ABSENT, 6-char code', async () => {
  const res = await start();
  assert.equal(res.status, 201);
  const s = res.body.session;
  assert.match(s.code, /^[A-Z2-9]{6}$/);
  assert.equal(s.status, 'OPEN');
  assert.equal(s.total, 3);
  assert.equal(s.absent, 3);
  assert.ok(Date.parse(s.codeExpiresAt) > Date.now() + 14 * 60 * 1000);
});

test('student check-in with the code (present, duplicate, wrong code, not enrolled)', async () => {
  const { session } = (await start('Probes')).body;
  const ok = await api('POST', '/api/attendance/check-in', { code: session.code.toLowerCase() }, aarav);
  assert.equal(ok.status, 200);
  assert.equal(ok.body.record.status, 'PRESENT');
  assert.equal(ok.body.record.method, 'CODE');

  const again = await api('POST', '/api/attendance/check-in', { code: session.code }, aarav);
  assert.equal(again.status, 409);
  assert.equal(again.body.error.code, 'ALREADY_MARKED');
  const wrong = await api('POST', '/api/attendance/check-in', { code: 'ZZZZZZ' }, priya);
  assert.equal(wrong.status, 404);
  assert.equal(wrong.body.error.code, 'INVALID_CODE');
  const notMine = await api('POST', '/api/attendance/check-in', { code: session.code }, outsider);
  assert.equal(notMine.status, 403);
  assert.equal(notMine.body.error.code, 'NOT_ENROLLED');
  assert.equal((await api('POST', '/api/attendance/check-in', { code: '12' }, priya)).status, 422);

  const detail = await api('GET', `/api/attendance/sessions/${session.id}`, null, meera);
  assert.equal(detail.body.session.present, 1);
  assert.deepEqual(detail.body.session.records.map((r) => r.rollNo), ['22CS001', '22CS002', '22CS003']);
  assert.equal((await api('GET', `/api/attendance/sessions/${session.id}`, null, arjun)).status, 403);
});

test('checking in after LATE_AFTER_MINUTES marks the student LATE', async () => {
  const original = config.lateAfterMinutes;
  config.lateAfterMinutes = 0;
  const { session } = (await start('Late test')).body;
  await new Promise((r) => setTimeout(r, 30));
  const res = await api('POST', '/api/attendance/check-in', { code: session.code }, priya);
  config.lateAfterMinutes = original;
  assert.equal(res.body.record.status, 'LATE');
});

test('faculty corrects records manually; closing a session stops check-ins', async () => {
  const { session } = (await start('Manual marking')).body;
  const detail = await api('GET', `/api/attendance/sessions/${session.id}`, null, meera);
  const rahulRec = detail.body.session.records.find((r) => r.rollNo === '22CS003');
  const marked = await api('PUT', `/api/attendance/records/${rahulRec.id}`, { status: 'excused' }, meera);
  assert.equal(marked.status, 200);
  assert.equal(marked.body.record.status, 'EXCUSED');
  assert.equal(marked.body.record.method, 'MANUAL');
  assert.equal((await api('PUT', `/api/attendance/records/${rahulRec.id}`, { status: 'MAYBE' }, meera)).status, 422);
  assert.equal((await api('PUT', `/api/attendance/records/${rahulRec.id}`, { status: 'PRESENT' }, arjun)).status, 403);
  assert.equal((await api('PUT', '/api/attendance/records/99999', { status: 'PRESENT' }, meera)).status, 404);

  const closed = await api('POST', `/api/attendance/sessions/${session.id}/close`, null, meera);
  assert.equal(closed.body.session.status, 'CLOSED');
  assert.equal((await api('POST', `/api/attendance/sessions/${session.id}/close`, null, meera)).status, 409);
  const late = await api('POST', '/api/attendance/check-in', { code: session.code }, aarav);
  assert.equal(late.status, 410);
  assert.equal(late.body.error.code, 'CODE_EXPIRED');
});

test('expired codes are closed by the internal sweep (CronJob endpoint)', async () => {
  const original = config.codeValidityMinutes;
  config.codeValidityMinutes = 0;
  const { session } = (await start('Expiry')).body;
  config.codeValidityMinutes = original;
  await new Promise((r) => setTimeout(r, 20));
  assert.equal((await api('POST', '/api/attendance/check-in', { code: session.code }, aarav)).status, 410);
  assert.equal((await api('POST', '/internal/attendance/close-expired')).status, 403);
  const sweep = await api('POST', '/internal/attendance/close-expired', null, null, { 'x-internal-token': config.internalToken });
  assert.ok(sweep.body.closed >= 1);
  assert.equal((await api('GET', `/api/attendance/sessions/${session.id}`, null, admin)).body.session.status, 'CLOSED');
});

test('empty roster and unknown course', async () => {
  const empty = await start('x', arjun, 2);
  assert.equal(empty.status, 409);
  assert.equal(empty.body.error.code, 'EMPTY_ROSTER');
  assert.equal((await start('x', admin, 77)).status, 404);
});

test('student summary: percentage, standing and classes needed', async () => {
  const me = await api('GET', '/api/attendance/me', null, rahul);
  assert.equal(me.status, 200);
  const c = me.body.courses[0];
  assert.equal(c.courseCode, 'CS501');
  // Rahul: never checked in, 1 excused -> 0 % -> SHORTAGE
  assert.equal(c.excused, 1);
  assert.equal(c.percent, 0);
  assert.equal(c.standing, 'SHORTAGE');
  assert.ok(c.classesNeeded > 0);
  assert.ok(me.body.recent.length > 0 && me.body.recent[0].topic);
  const a = (await api('GET', '/api/attendance/me', null, aarav)).body.courses[0];
  assert.equal(a.present, 1);
});

test('course report lists defaulters; stats for faculty', async () => {
  const rep = await api('GET', '/api/attendance/courses/1/report', null, meera);
  assert.equal(rep.status, 200);
  assert.equal(rep.body.course.code, 'CS501');
  assert.equal(rep.body.students.length, 3);
  assert.ok(rep.body.defaulters >= 2);
  assert.ok(rep.body.sessions >= 5);
  assert.equal((await api('GET', '/api/attendance/courses/1/report', null, arjun)).status, 403);
  const stats = await api('GET', '/api/attendance/stats', null, meera);
  assert.ok(stats.body.sessions >= 5);
  assert.ok(stats.body.openSessions >= 1);
  assert.equal(typeof stats.body.percent, 'number');
  const policy = await api('GET', '/api/attendance/policy');
  assert.equal(policy.body.minAttendancePercent, 75);
});

test('grade(): attendance maths', () => {
  const svc = new AttendanceService({ repo, courses, config, logger: createLogger('t') });
  const g = svc.grade({ total: 10, present: 6, late: 0, absent: 3, excused: 1 });
  assert.equal(g.percent, 66.7);
  assert.equal(g.standing, 'WARNING');
  assert.equal(g.classesNeeded, 3); // (6+3)/(9+3) = 75 %
  assert.equal(svc.grade({ total: 0, present: 0, late: 0, absent: 0, excused: 0 }).standing, 'NO_CLASSES');
  assert.equal(svc.grade({ total: 4, present: 3, late: 1, absent: 0, excused: 0 }).standing, 'OK');
});

test('demo history seeding runs only once', async () => {
  const memRepo = new MemoryAttendanceRepository();
  const svc = new AttendanceService({ repo: memRepo, courses, config, logger: createLogger('t') });
  assert.equal(await svc.seedDemoHistory({ courseIds: [1], sessionsPerCourse: 6 }), 6);
  assert.equal(await svc.seedDemoHistory({ courseIds: [1], sessionsPerCourse: 6 }), 0);
  const report = (await memRepo.courseStudentTallies(1)).map((s) => svc.grade(s));
  assert.equal(report.length, 3);
  assert.ok(report.every((s) => s.total === 6));
});

test('course-service outage returns 503', async () => {
  const broken = new AttendanceService({
    repo,
    courses: createCourseClient({ baseUrl: 'http://127.0.0.1:1', internalToken: 'x', timeoutMs: 300, logger: createLogger('t') }),
    config,
    logger: createLogger('t'),
  });
  await assert.rejects(() => broken.startSession({ role: 'admin', email: 'a@t' }, { courseId: 1 }), (e) => e.status === 503);
});
