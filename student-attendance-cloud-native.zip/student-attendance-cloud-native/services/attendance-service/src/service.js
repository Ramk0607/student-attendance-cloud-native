'use strict';
/**
 * Attendance workflow (the "tracking" part of the system):
 *
 *   faculty starts a class session  ->  roster snapshot, everyone ABSENT, 6-char check-in code shown in class
 *   student enters the code         ->  PRESENT (or LATE after LATE_AFTER_MINUTES)
 *   faculty can correct any record  ->  PRESENT | LATE | ABSENT | EXCUSED (manual)
 *   code expires / faculty closes   ->  session CLOSED (CronJob closes expired sessions)
 *
 * Attendance % = (PRESENT + LATE) / (sessions - EXCUSED).  Below MIN_ATTENDANCE_PERCENT the student
 * is flagged (WARNING), below CRITICAL_ATTENDANCE_PERCENT the student has a SHORTAGE.
 */
const crypto = require('node:crypto');
const { HttpError } = require('./kit/http');

const STATUSES = ['PRESENT', 'LATE', 'ABSENT', 'EXCUSED'];
const CODE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // no 0/O/1/I confusion

function generateCode(length = 6) {
  let out = '';
  for (let i = 0; i < length; i += 1) out += CODE_ALPHABET[crypto.randomInt(CODE_ALPHABET.length)];
  return out;
}

class AttendanceService {
  constructor({ repo, courses, config, logger }) {
    this.repo = repo;
    this.courses = courses;
    this.config = config;
    this.logger = logger;
  }

  /** Adds percentage + standing to a tally. */
  grade(t) {
    const counted = t.total - t.excused;
    const attended = t.present + t.late;
    const percent = counted > 0 ? Math.round((attended / counted) * 1000) / 10 : null;
    let standing = 'NO_CLASSES';
    if (percent !== null) {
      standing = percent >= this.config.minAttendancePercent ? 'OK' : percent >= this.config.criticalAttendancePercent ? 'WARNING' : 'SHORTAGE';
    }
    // classes the student must attend in a row to get back to the minimum
    let classesNeeded = 0;
    if (percent !== null && percent < this.config.minAttendancePercent) {
      const m = this.config.minAttendancePercent / 100;
      classesNeeded = Math.max(0, Math.ceil((m * counted - attended) / (1 - m)));
    }
    return { ...t, attended, percent, standing, classesNeeded };
  }

  assertCanManage(user, facultyEmail) {
    if (user.role === 'admin') return;
    if (user.role === 'faculty' && facultyEmail === user.email) return;
    throw new HttpError(403, 'Only the course faculty or an admin can do this', 'FORBIDDEN');
  }

  async startSession(user, { courseId, topic }, requestId) {
    const id = Number(courseId);
    if (!Number.isInteger(id) || id <= 0) throw new HttpError(422, 'courseId must be a positive integer', 'VALIDATION_FAILED');
    const cleanTopic = String(topic || '').trim().slice(0, 200) || 'Lecture';
    const { course, students } = await this.courses.getRoster(id, requestId);
    this.assertCanManage(user, course.facultyEmail);
    if (!students.length) throw new HttpError(409, 'No students are enrolled in this course yet', 'EMPTY_ROSTER');

    for (let attempt = 1; attempt <= 5; attempt += 1) {
      try {
        const session = await this.repo.createSession({
          course,
          topic: cleanTopic,
          code: generateCode(),
          validityMinutes: this.config.codeValidityMinutes,
          createdBy: user.email,
          students,
        });
        this.logger.info('session started', { sessionId: session.id, course: course.code, students: students.length });
        return session;
      } catch (err) {
        if (err.code !== 'DUPLICATE' || attempt === 5) throw err;
      }
    }
    return null;
  }

  async listSessions(user, { courseId } = {}) {
    if (user.role === 'student') throw new HttpError(403, 'Students cannot list sessions');
    return this.repo.listSessions({ courseId: courseId || null, facultyEmail: user.role === 'faculty' ? user.email : null });
  }

  async getSession(user, id) {
    const session = await this.repo.getSession(Number(id));
    if (!session) throw new HttpError(404, 'Session not found');
    this.assertCanManage(user, session.facultyEmail);
    return { ...session, records: await this.repo.sessionRecords(session.id) };
  }

  async closeSession(user, id) {
    const session = await this.repo.getSession(Number(id));
    if (!session) throw new HttpError(404, 'Session not found');
    this.assertCanManage(user, session.facultyEmail);
    const closed = await this.repo.closeSession(session.id);
    if (!closed) throw new HttpError(409, 'Session is already closed', 'ALREADY_CLOSED');
    return closed;
  }

  async markRecord(user, recordId, status) {
    const s = String(status || '').toUpperCase();
    if (!STATUSES.includes(s)) throw new HttpError(422, `status must be one of ${STATUSES.join(', ')}`, 'VALIDATION_FAILED');
    const record = await this.repo.getRecord(Number(recordId));
    if (!record) throw new HttpError(404, 'Attendance record not found');
    const session = await this.repo.getSession(record.sessionId);
    this.assertCanManage(user, session.facultyEmail);
    return this.repo.markRecord(record.id, { status: s, by: user.email });
  }

  async checkIn(user, rawCode) {
    if (user.role !== 'student') throw new HttpError(403, 'Only students check in');
    const code = String(rawCode || '').trim().toUpperCase();
    if (!/^[A-Z0-9]{6}$/.test(code)) throw new HttpError(422, 'Enter the 6-character code shown in class', 'VALIDATION_FAILED');
    const record = await this.repo.checkIn({ code, email: user.email, lateAfterMinutes: this.config.lateAfterMinutes });
    if (record) {
      this.logger.info('student checked in', { sessionId: record.sessionId, status: record.status });
      return record;
    }
    const reason = await this.repo.diagnoseCheckIn({ code, email: user.email });
    const errors = {
      INVALID_CODE: [404, 'That code does not match any class session'],
      CODE_EXPIRED: [410, 'This code has expired - ask your faculty to mark you manually'],
      NOT_ENROLLED: [403, 'You are not enrolled in this course'],
      ALREADY_MARKED: [409, 'Your attendance is already recorded for this session'],
    };
    const [status, message] = errors[reason];
    throw new HttpError(status, message, reason);
  }

  async mySummary(user) {
    const courses = (await this.repo.studentCourseTallies(user.email)).map((c) => this.grade(c));
    const overall = this.grade(
      courses.reduce(
        (a, c) => ({ total: a.total + c.total, present: a.present + c.present, late: a.late + c.late, absent: a.absent + c.absent, excused: a.excused + c.excused }),
        { total: 0, present: 0, late: 0, absent: 0, excused: 0 },
      ),
    );
    return { overall, courses, recent: await this.repo.studentRecent(user.email, 10) };
  }

  async courseReport(user, courseId, requestId) {
    const { course } = await this.courses.getRoster(Number(courseId), requestId);
    this.assertCanManage(user, course.facultyEmail);
    const students = (await this.repo.courseStudentTallies(course.id)).map((s) => this.grade(s));
    const sessions = await this.repo.listSessions({ courseId: course.id });
    return {
      course,
      sessions: sessions.length,
      students,
      defaulters: students.filter((s) => s.standing === 'WARNING' || s.standing === 'SHORTAGE').length,
      averagePercent: students.length
        ? Math.round((students.reduce((a, s) => a + (s.percent ?? 0), 0) / students.length) * 10) / 10
        : null,
    };
  }

  async stats(user) {
    if (user.role === 'student') throw new HttpError(403, 'Not allowed');
    const t = await this.repo.totals({ facultyEmail: user.role === 'faculty' ? user.email : null });
    return { ...this.grade(t), sessions: t.sessions, openSessions: t.openSessions, sessionsToday: t.sessionsToday };
  }

  async closeExpired() {
    const n = await this.repo.closeExpired();
    if (n) this.logger.info('expired sessions closed', { closed: n });
    return n;
  }

  /**
   * Demo history so dashboards are not empty (SEED_DEMO_DATA=true, dev only).
   * Students get different attendance patterns, including some below 75 %.
   */
  async seedDemoHistory({ courseIds = [1, 2], sessionsPerCourse = 10 } = {}) {
    // Fetch rosters first: if course-service is not up yet this throws and the caller retries
    // (claiming the seed marker first would make a failed attempt permanent).
    const rosters = [];
    for (const courseId of courseIds) rosters.push(await this.courses.getRoster(courseId));
    if (!(await this.repo.claimSeed())) return 0;
    const absentChance = { '22CS001': 10, '22CS002': 5, '22CS003': 42, '22CS004': 24, '22CS005': 30 };
    const topics = ['Introduction', 'Containers & images', 'Kubernetes basics', 'Helm charts', 'Deployment strategies',
      'Probes & PDBs', 'CI/CD pipelines', 'Trivy & supply chain', 'Ingress & TLS', 'API gateways', 'Service mesh', 'GitOps'];
    let created = 0;
    for (const { course, students } of rosters) {
      const courseId = course.id;
      for (let j = 0; j < sessionsPerCourse; j += 1) {
        const startsAt = new Date(Date.now() - (sessionsPerCourse - j) * 2 * 24 * 3600 * 1000);
        startsAt.setUTCHours(3 + (courseId % 3), 30, 0, 0);
        const session = await this.repo.createSession({
          course,
          topic: course.code === 'CS501' ? topics[j % topics.length] : `Unit ${Math.floor(j / 2) + 1} - lecture ${(j % 2) + 1}`,
          startsAt: startsAt.toISOString(),
          code: generateCode(),
          validityMinutes: this.config.codeValidityMinutes,
          createdBy: course.facultyEmail,
          students,
          status: 'CLOSED',
        });
        const records = await this.repo.sessionRecords(session.id);
        for (const [i, r] of records.entries()) {
          const roll = (j * 37 + i * 11 + courseId * 7) % 100;
          const status = roll < (absentChance[r.rollNo] ?? 15) ? 'ABSENT' : (j * 13 + i * 7) % 100 < 12 ? 'LATE' : 'PRESENT';
          if (status === 'ABSENT' && (j + i) % 17 === 0) await this.repo.markRecord(r.id, { status: 'EXCUSED', by: course.facultyEmail });
          else if (status !== 'ABSENT') await this.repo.markRecord(r.id, { status, by: r.studentEmail, method: 'CODE' });
        }
        created += 1;
      }
    }
    this.logger.info('demo attendance history seeded', { sessions: created });
    return created;
  }
}

module.exports = { AttendanceService, generateCode, STATUSES };
