'use strict';
const { createLogger } = require('./kit/logger');
const { createPool, waitForDatabase } = require('./kit/db');
const { loadConfig } = require('./config');
const { createApp } = require('./app');
const { AttendanceService } = require('./service');
const { createCourseClient } = require('./course-client');
const { MemoryAttendanceRepository } = require('./repository/memory');
const { PostgresAttendanceRepository } = require('./repository/postgres');

async function main() {
  const logger = createLogger('attendance-service');
  const config = loadConfig();

  let repo;
  if (config.dbDriver === 'postgres') {
    const pool = createPool({ logger });
    await waitForDatabase(pool, logger);
    repo = new PostgresAttendanceRepository(pool);
  } else {
    logger.warn('using in-memory storage (DB_DRIVER=memory) - data is lost on restart');
    repo = new MemoryAttendanceRepository();
  }
  await repo.init();

  const courses = createCourseClient({
    baseUrl: config.courseUrl,
    internalToken: config.internalToken,
    timeoutMs: config.courseTimeoutMs,
    logger,
  });
  const service = new AttendanceService({ repo, courses, config, logger });
  const { server, lifecycle } = createApp({ config, repo, service, logger });

  let sweeper;
  if (config.sessionSweepIntervalSec > 0) {
    sweeper = setInterval(() => {
      service.closeExpired().catch((err) => logger.error('session sweep failed', { error: err.message }));
    }, config.sessionSweepIntervalSec * 1000);
    sweeper.unref();
  }

  // Demo history needs course-service; retry in the background without blocking start-up.
  if (config.seedDemoData) {
    (async () => {
      for (let attempt = 1; attempt <= 30; attempt += 1) {
        try {
          await service.seedDemoHistory();
          return;
        } catch (err) {
          logger.warn('demo seed waiting for course-service', { attempt, error: err.message });
          await new Promise((r) => setTimeout(r, 3000));
        }
      }
    })();
  }

  server.listen(config.port, () => {
    lifecycle.markStarted();
    logger.info('attendance-service listening', { port: config.port, db: config.dbDriver, courseUrl: config.courseUrl, ...config.info });
  });
  lifecycle.handleSignals(server, async () => {
    if (sweeper) clearInterval(sweeper);
    await repo.close();
  });
}

main().catch((err) => {
  // eslint-disable-next-line no-console
  console.error(JSON.stringify({ level: 'fatal', service: 'attendance-service', msg: err.message, stack: err.stack }));
  process.exit(1);
});
