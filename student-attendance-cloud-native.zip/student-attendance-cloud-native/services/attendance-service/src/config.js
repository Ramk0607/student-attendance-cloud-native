'use strict';
const { str, int, num, bool, secret, runtimeInfo } = require('./kit/config');
const pkg = require('../package.json');

function loadConfig() {
  return {
    port: int('PORT', 4003),
    dbDriver: str('DB_DRIVER', 'memory'), // memory | postgres
    jwtSecret: secret('JWT_SECRET', 'dev-only-insecure-jwt-secret-change-me'),
    jwtIssuer: str('JWT_ISSUER', 'smartattend-auth'),
    internalToken: secret('INTERNAL_TOKEN', 'dev-only-internal-token'),
    // Service discovery: Kubernetes Service DNS name injected by Helm
    courseUrl: str('COURSE_URL', 'http://localhost:4002'),
    courseTimeoutMs: int('COURSE_TIMEOUT_MS', 3000),
    // Attendance rules (configurable per environment through the Helm ConfigMap)
    minAttendancePercent: num('MIN_ATTENDANCE_PERCENT', 75),
    criticalAttendancePercent: num('CRITICAL_ATTENDANCE_PERCENT', 65),
    codeValidityMinutes: int('CODE_VALIDITY_MINUTES', 15),
    lateAfterMinutes: int('LATE_AFTER_MINUTES', 10),
    // In Kubernetes a CronJob closes expired sessions instead (SESSION_SWEEP_INTERVAL_SEC=0)
    sessionSweepIntervalSec: int('SESSION_SWEEP_INTERVAL_SEC', 60),
    seedDemoData: bool('SEED_DEMO_DATA', true),
    chaosErrorRate: num('CHAOS_ERROR_RATE', 0),
    chaosLatencyMs: int('CHAOS_LATENCY_MS', 0),
    simulateReadinessFailure: bool('SIMULATE_READINESS_FAILURE', false),
    shutdownDelayMs: int('SHUTDOWN_DELAY_MS', 5000),
    info: runtimeInfo('attendance-service', pkg.version),
  };
}

module.exports = { loadConfig };
