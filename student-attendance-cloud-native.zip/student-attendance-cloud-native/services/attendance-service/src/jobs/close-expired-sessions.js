'use strict';
/**
 * Entry point of the Kubernetes CronJob "session-closer":
 * closes class sessions whose check-in code has expired (via the internal API of attendance-service).
 */
const url = `${process.env.ATTENDANCE_URL || 'http://localhost:4003'}/internal/attendance/close-expired`;

(async () => {
  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'x-internal-token': process.env.INTERNAL_TOKEN || 'dev-only-internal-token' },
      signal: AbortSignal.timeout(30000),
    });
    console.log(JSON.stringify({ job: 'session-closer', status: res.status, body: await res.text() }));
    process.exit(res.ok ? 0 : 1);
  } catch (err) {
    console.error(JSON.stringify({ job: 'session-closer', error: err.message }));
    process.exit(1);
  }
})();
