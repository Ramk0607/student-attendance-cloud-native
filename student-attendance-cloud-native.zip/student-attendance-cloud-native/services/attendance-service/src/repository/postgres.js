'use strict';
/**
 * PostgreSQL attendance store.
 * - a session and its roster snapshot are written by ONE statement (data-modifying CTE)
 * - student check-in is one conditional UPDATE (valid code + open session + not yet marked)
 * so concurrent requests from many replicas stay consistent without explicit transactions.
 */
const { toIso } = require('../kit/db');

const SCHEMA = `
DO $$
BEGIN
  PERFORM pg_advisory_xact_lock(5203);
  CREATE TABLE IF NOT EXISTS class_sessions (
    id              SERIAL PRIMARY KEY,
    course_id       INT          NOT NULL,
    course_code     VARCHAR(20)  NOT NULL,
    course_name     VARCHAR(200) NOT NULL,
    faculty_email   VARCHAR(255) NOT NULL,
    topic           VARCHAR(200) NOT NULL,
    starts_at       TIMESTAMPTZ  NOT NULL DEFAULT now(),
    code            VARCHAR(12)  NOT NULL,
    code_expires_at TIMESTAMPTZ  NOT NULL,
    status          VARCHAR(10)  NOT NULL DEFAULT 'OPEN' CHECK (status IN ('OPEN', 'CLOSED')),
    created_by      VARCHAR(255) NOT NULL,
    created_at      TIMESTAMPTZ  NOT NULL DEFAULT now()
  );
  CREATE UNIQUE INDEX IF NOT EXISTS uq_open_session_code ON class_sessions (code) WHERE status = 'OPEN';
  CREATE INDEX IF NOT EXISTS idx_sessions_course ON class_sessions (course_id, starts_at DESC);
  CREATE TABLE IF NOT EXISTS attendance_records (
    id            SERIAL PRIMARY KEY,
    session_id    INT          NOT NULL REFERENCES class_sessions (id) ON DELETE CASCADE,
    course_id     INT          NOT NULL,
    course_code   VARCHAR(20)  NOT NULL,
    course_name   VARCHAR(200) NOT NULL,
    student_email VARCHAR(255) NOT NULL,
    student_name  VARCHAR(120) NOT NULL,
    roll_no       VARCHAR(20),
    status        VARCHAR(10)  NOT NULL DEFAULT 'ABSENT' CHECK (status IN ('PRESENT', 'LATE', 'ABSENT', 'EXCUSED')),
    method        VARCHAR(10)  NOT NULL DEFAULT 'AUTO',
    marked_at     TIMESTAMPTZ,
    marked_by     VARCHAR(255),
    UNIQUE (session_id, student_email)
  );
  CREATE INDEX IF NOT EXISTS idx_records_student ON attendance_records (student_email, course_id);
  CREATE INDEX IF NOT EXISTS idx_records_course ON attendance_records (course_id, student_email);
  CREATE TABLE IF NOT EXISTS app_meta (
    key        VARCHAR(50) PRIMARY KEY,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
  );
END
$$;`;

const TALLY = `count(*)::int AS total,
  count(*) FILTER (WHERE status = 'PRESENT')::int AS present,
  count(*) FILTER (WHERE status = 'LATE')::int AS late,
  count(*) FILTER (WHERE status = 'ABSENT')::int AS absent,
  count(*) FILTER (WHERE status = 'EXCUSED')::int AS excused`;

const num = (v) => Number(v || 0);
const mapTally = (r) => ({ total: num(r.total), present: num(r.present), late: num(r.late), absent: num(r.absent), excused: num(r.excused) });

const mapSession = (r) =>
  r && {
    id: Number(r.id),
    courseId: Number(r.course_id),
    courseCode: r.course_code,
    courseName: r.course_name,
    facultyEmail: r.faculty_email,
    topic: r.topic,
    startsAt: toIso(r.starts_at),
    code: r.code,
    codeExpiresAt: toIso(r.code_expires_at),
    status: r.status,
    createdBy: r.created_by,
    createdAt: toIso(r.created_at),
    ...mapTally(r),
  };

const mapRecord = (r) =>
  r && {
    id: Number(r.id),
    sessionId: Number(r.session_id),
    courseId: Number(r.course_id),
    courseCode: r.course_code,
    courseName: r.course_name,
    studentEmail: r.student_email,
    studentName: r.student_name,
    rollNo: r.roll_no,
    status: r.status,
    method: r.method,
    markedAt: toIso(r.marked_at),
    markedBy: r.marked_by,
    ...(r.starts_at !== undefined ? { startsAt: toIso(r.starts_at), topic: r.topic } : {}),
  };

const SESSION_SELECT = `SELECT s.*, t.* FROM class_sessions s
  LEFT JOIN LATERAL (SELECT ${TALLY} FROM attendance_records a WHERE a.session_id = s.id) t ON true`;

class PostgresAttendanceRepository {
  constructor(pool) {
    this.pool = pool;
  }

  async init() {
    await this.pool.query(SCHEMA);
  }

  async ping() {
    await this.pool.query('SELECT 1');
    return true;
  }

  /** Exactly one replica wins the right to seed demo data. */
  async claimSeed() {
    const { rows: existing } = await this.pool.query('SELECT count(*)::int AS n FROM class_sessions');
    if (num(existing[0].n) > 0) return false;
    const { rows } = await this.pool.query("INSERT INTO app_meta (key) VALUES ('demo-seed') ON CONFLICT DO NOTHING RETURNING key");
    return rows.length === 1;
  }

  async createSession({ course, topic, startsAt, code, validityMinutes, createdBy, students, status = 'OPEN' }) {
    try {
      const { rows } = await this.pool.query(
        `WITH s AS (
           INSERT INTO class_sessions (course_id, course_code, course_name, faculty_email, topic, starts_at, code, code_expires_at, status, created_by)
           VALUES ($1::int, $2, $3, $4, $5, COALESCE($6::timestamptz, now()), $7,
                   COALESCE($6::timestamptz, now()) + make_interval(mins => $8::int), $9, $10)
           RETURNING *
         ), r AS (
           INSERT INTO attendance_records (session_id, course_id, course_code, course_name, student_email, student_name, roll_no)
           SELECT s.id, s.course_id, s.course_code, s.course_name, x.email, x.name, x."rollNo"
           FROM s, json_to_recordset($11::json) AS x(email text, name text, "rollNo" text)
           RETURNING 1
         )
         SELECT s.*, (SELECT count(*) FROM r)::int AS total, 0 AS present, 0 AS late,
                (SELECT count(*) FROM r)::int AS absent, 0 AS excused
         FROM s`,
        [course.id, course.code, course.name, course.facultyEmail, topic, startsAt || null, code, validityMinutes, status, createdBy,
          JSON.stringify(students.map((st) => ({ email: st.email, name: st.name, rollNo: st.rollNo || null })))],
      );
      return mapSession(rows[0]);
    } catch (err) {
      if (err.code === '23505' || /duplicate key/i.test(err.message)) throw Object.assign(new Error('code clash'), { code: 'DUPLICATE' });
      throw err;
    }
  }

  async listSessions({ courseId, facultyEmail } = {}) {
    const { rows } = await this.pool.query(
      `${SESSION_SELECT}
       WHERE ($1::int IS NULL OR s.course_id = $1::int) AND ($2::text IS NULL OR s.faculty_email = $2::text)
       ORDER BY s.starts_at DESC, s.id DESC LIMIT 200`,
      [courseId ? Number(courseId) : null, facultyEmail || null],
    );
    return rows.map(mapSession);
  }

  async getSession(id) {
    const { rows } = await this.pool.query(`${SESSION_SELECT} WHERE s.id = $1::int`, [Number(id)]);
    return mapSession(rows[0]) || null;
  }

  async sessionRecords(sessionId) {
    const { rows } = await this.pool.query(
      'SELECT * FROM attendance_records WHERE session_id = $1::int ORDER BY roll_no NULLS LAST, student_name',
      [Number(sessionId)],
    );
    return rows.map(mapRecord);
  }

  async getRecord(id) {
    const { rows } = await this.pool.query('SELECT * FROM attendance_records WHERE id = $1::int', [Number(id)]);
    return mapRecord(rows[0]) || null;
  }

  async markRecord(id, { status, by, method = 'MANUAL' }) {
    const { rows } = await this.pool.query(
      'UPDATE attendance_records SET status = $2, method = $3, marked_by = $4, marked_at = now() WHERE id = $1::int RETURNING *',
      [Number(id), status, method, by],
    );
    return mapRecord(rows[0]) || null;
  }

  async checkIn({ code, email, lateAfterMinutes }) {
    const { rows } = await this.pool.query(
      `UPDATE attendance_records a
       SET status = CASE WHEN now() > s.starts_at + make_interval(mins => $3::int) THEN 'LATE' ELSE 'PRESENT' END,
           method = 'CODE', marked_by = $2, marked_at = now()
       FROM class_sessions s
       WHERE a.session_id = s.id AND s.code = $1 AND s.status = 'OPEN' AND s.code_expires_at > now()
         AND a.student_email = $2 AND a.status = 'ABSENT'
       RETURNING a.*`,
      [code, email, lateAfterMinutes],
    );
    return mapRecord(rows[0]) || null;
  }

  async diagnoseCheckIn({ code, email }) {
    const { rows } = await this.pool.query(
      `SELECT s.id, (s.status = 'OPEN' AND s.code_expires_at > now()) AS valid,
              EXISTS (SELECT 1 FROM attendance_records a WHERE a.session_id = s.id AND a.student_email = $2) AS enrolled
       FROM class_sessions s WHERE s.code = $1 ORDER BY (s.status = 'OPEN') DESC, s.id DESC LIMIT 1`,
      [code, email],
    );
    if (!rows[0]) return 'INVALID_CODE';
    if (!rows[0].valid) return 'CODE_EXPIRED';
    if (!rows[0].enrolled) return 'NOT_ENROLLED';
    return 'ALREADY_MARKED';
  }

  async closeSession(id) {
    const { rows } = await this.pool.query(
      "UPDATE class_sessions SET status = 'CLOSED' WHERE id = $1::int AND status = 'OPEN' RETURNING id",
      [Number(id)],
    );
    return rows[0] ? this.getSession(id) : null;
  }

  async closeExpired() {
    const { rowCount } = await this.pool.query(
      "UPDATE class_sessions SET status = 'CLOSED' WHERE status = 'OPEN' AND code_expires_at <= now()",
    );
    return rowCount;
  }

  async studentCourseTallies(email) {
    const { rows } = await this.pool.query(
      `SELECT course_id, course_code, course_name, ${TALLY}
       FROM attendance_records WHERE student_email = $1
       GROUP BY course_id, course_code, course_name ORDER BY course_code`,
      [email],
    );
    return rows.map((r) => ({ courseId: Number(r.course_id), courseCode: r.course_code, courseName: r.course_name, ...mapTally(r) }));
  }

  async studentRecent(email, limit = 10) {
    const { rows } = await this.pool.query(
      `SELECT a.*, s.starts_at, s.topic FROM attendance_records a JOIN class_sessions s ON s.id = a.session_id
       WHERE a.student_email = $1 ORDER BY s.starts_at DESC, a.id DESC LIMIT $2::int`,
      [email, limit],
    );
    return rows.map(mapRecord);
  }

  async courseStudentTallies(courseId) {
    const { rows } = await this.pool.query(
      `SELECT student_email, student_name, roll_no, ${TALLY}
       FROM attendance_records WHERE course_id = $1::int
       GROUP BY student_email, student_name, roll_no ORDER BY roll_no NULLS LAST, student_name`,
      [Number(courseId)],
    );
    return rows.map((r) => ({ studentEmail: r.student_email, studentName: r.student_name, rollNo: r.roll_no, ...mapTally(r) }));
  }

  async totals({ facultyEmail } = {}) {
    const { rows } = await this.pool.query(
      `SELECT (SELECT count(*) FROM class_sessions s WHERE $1::text IS NULL OR s.faculty_email = $1::text)::int AS sessions,
              (SELECT count(*) FROM class_sessions s WHERE s.status = 'OPEN' AND ($1::text IS NULL OR s.faculty_email = $1::text))::int AS open_sessions,
              (SELECT count(*) FROM class_sessions s WHERE s.starts_at::date = (now() AT TIME ZONE 'UTC')::date
                 AND ($1::text IS NULL OR s.faculty_email = $1::text))::int AS sessions_today,
              ${TALLY.replace(/status/g, 'a.status')}
       FROM attendance_records a JOIN class_sessions s ON s.id = a.session_id
       WHERE $1::text IS NULL OR s.faculty_email = $1::text`,
      [facultyEmail || null],
    );
    const r = rows[0];
    return { sessions: num(r.sessions), openSessions: num(r.open_sessions), sessionsToday: num(r.sessions_today), ...mapTally(r) };
  }

  async close() {
    await this.pool.end();
  }
}

module.exports = { PostgresAttendanceRepository };
