'use strict';
/** In-memory attendance store - used for local development and unit tests. */
const MIN = 60 * 1000;

function tally(records) {
  const t = { total: 0, present: 0, late: 0, absent: 0, excused: 0 };
  for (const r of records) {
    t.total += 1;
    t[r.status.toLowerCase()] += 1;
  }
  return t;
}

class MemoryAttendanceRepository {
  constructor({ now = () => Date.now() } = {}) {
    this.sessions = new Map();
    this.records = new Map();
    this.nextSession = 1;
    this.nextRecord = 1;
    this.seedClaimed = false;
    this.now = now;
  }

  async init() {}

  async ping() {
    return true;
  }

  async claimSeed() {
    if (this.seedClaimed || this.sessions.size > 0) return false;
    this.seedClaimed = true;
    return true;
  }

  withCounts(s) {
    return { ...s, ...tally([...this.records.values()].filter((r) => r.sessionId === s.id)) };
  }

  async createSession({ course, topic, startsAt, code, validityMinutes, createdBy, students, status = 'OPEN' }) {
    if (status === 'OPEN' && [...this.sessions.values()].some((s) => s.status === 'OPEN' && s.code === code)) {
      throw Object.assign(new Error('code clash'), { code: 'DUPLICATE' });
    }
    const start = startsAt ? Date.parse(startsAt) : this.now();
    const s = {
      id: this.nextSession++,
      courseId: course.id,
      courseCode: course.code,
      courseName: course.name,
      facultyEmail: course.facultyEmail,
      topic,
      startsAt: new Date(start).toISOString(),
      code,
      codeExpiresAt: new Date((startsAt ? start : this.now()) + validityMinutes * MIN).toISOString(),
      status,
      createdBy,
      createdAt: new Date(this.now()).toISOString(),
    };
    this.sessions.set(s.id, s);
    for (const st of students) {
      const r = {
        id: this.nextRecord++,
        sessionId: s.id,
        courseId: course.id,
        courseCode: course.code,
        courseName: course.name,
        studentEmail: st.email,
        studentName: st.name,
        rollNo: st.rollNo || null,
        status: 'ABSENT',
        method: 'AUTO',
        markedAt: null,
        markedBy: null,
      };
      this.records.set(r.id, r);
    }
    return this.withCounts(s);
  }

  async listSessions({ courseId, facultyEmail } = {}) {
    return [...this.sessions.values()]
      .filter((s) => !courseId || s.courseId === Number(courseId))
      .filter((s) => !facultyEmail || s.facultyEmail === facultyEmail)
      .sort((a, b) => Date.parse(b.startsAt) - Date.parse(a.startsAt) || b.id - a.id)
      .map((s) => this.withCounts(s));
  }

  async getSession(id) {
    const s = this.sessions.get(Number(id));
    return s ? this.withCounts(s) : null;
  }

  async sessionRecords(sessionId) {
    return [...this.records.values()]
      .filter((r) => r.sessionId === Number(sessionId))
      .sort((a, b) => String(a.rollNo).localeCompare(String(b.rollNo)))
      .map((r) => ({ ...r }));
  }

  async getRecord(id) {
    const r = this.records.get(Number(id));
    return r ? { ...r } : null;
  }

  async markRecord(id, { status, by, method = 'MANUAL' }) {
    const r = this.records.get(Number(id));
    if (!r) return null;
    Object.assign(r, { status, method, markedBy: by, markedAt: new Date(this.now()).toISOString() });
    return { ...r };
  }

  /** Student self check-in: only an ABSENT record of an OPEN session with a valid code. */
  async checkIn({ code, email, lateAfterMinutes }) {
    const now = this.now();
    const s = [...this.sessions.values()].find((x) => x.code === code && x.status === 'OPEN' && Date.parse(x.codeExpiresAt) > now);
    if (!s) return null;
    const r = [...this.records.values()].find((x) => x.sessionId === s.id && x.studentEmail === email && x.status === 'ABSENT');
    if (!r) return null;
    const late = now > Date.parse(s.startsAt) + lateAfterMinutes * MIN;
    Object.assign(r, { status: late ? 'LATE' : 'PRESENT', method: 'CODE', markedBy: email, markedAt: new Date(now).toISOString() });
    return { ...r };
  }

  /** Explains why a check-in failed. */
  async diagnoseCheckIn({ code, email }) {
    const matches = [...this.sessions.values()].filter((x) => x.code === code);
    if (!matches.length) return 'INVALID_CODE';
    const s = matches.find((x) => x.status === 'OPEN' && Date.parse(x.codeExpiresAt) > this.now());
    if (!s) return 'CODE_EXPIRED';
    const r = [...this.records.values()].find((x) => x.sessionId === s.id && x.studentEmail === email);
    if (!r) return 'NOT_ENROLLED';
    return 'ALREADY_MARKED';
  }

  async closeSession(id) {
    const s = this.sessions.get(Number(id));
    if (!s || s.status !== 'OPEN') return null;
    s.status = 'CLOSED';
    return this.withCounts(s);
  }

  async closeExpired() {
    let n = 0;
    for (const s of this.sessions.values()) {
      if (s.status === 'OPEN' && Date.parse(s.codeExpiresAt) <= this.now()) {
        s.status = 'CLOSED';
        n += 1;
      }
    }
    return n;
  }

  async studentCourseTallies(email) {
    const groups = new Map();
    for (const r of this.records.values()) {
      if (r.studentEmail !== email) continue;
      const g = groups.get(r.courseId) || { courseId: r.courseId, courseCode: r.courseCode, courseName: r.courseName, records: [] };
      g.records.push(r);
      groups.set(r.courseId, g);
    }
    return [...groups.values()]
      .sort((a, b) => a.courseCode.localeCompare(b.courseCode))
      .map(({ records, ...g }) => ({ ...g, ...tally(records) }));
  }

  async studentRecent(email, limit = 10) {
    return [...this.records.values()]
      .filter((r) => r.studentEmail === email)
      .map((r) => ({ ...r, startsAt: this.sessions.get(r.sessionId).startsAt, topic: this.sessions.get(r.sessionId).topic }))
      .sort((a, b) => Date.parse(b.startsAt) - Date.parse(a.startsAt))
      .slice(0, limit);
  }

  async courseStudentTallies(courseId) {
    const groups = new Map();
    for (const r of this.records.values()) {
      if (r.courseId !== Number(courseId)) continue;
      const g = groups.get(r.studentEmail) || { studentEmail: r.studentEmail, studentName: r.studentName, rollNo: r.rollNo, records: [] };
      g.records.push(r);
      groups.set(r.studentEmail, g);
    }
    return [...groups.values()]
      .sort((a, b) => String(a.rollNo).localeCompare(String(b.rollNo)))
      .map(({ records, ...g }) => ({ ...g, ...tally(records) }));
  }

  async totals({ facultyEmail } = {}) {
    const sessions = [...this.sessions.values()].filter((s) => !facultyEmail || s.facultyEmail === facultyEmail);
    const ids = new Set(sessions.map((s) => s.id));
    const t = tally([...this.records.values()].filter((r) => ids.has(r.sessionId)));
    const today = new Date(this.now()).toISOString().slice(0, 10);
    return {
      sessions: sessions.length,
      openSessions: sessions.filter((s) => s.status === 'OPEN').length,
      sessionsToday: sessions.filter((s) => s.startsAt.slice(0, 10) === today).length,
      ...t,
    };
  }

  async close() {}
}

module.exports = { MemoryAttendanceRepository, tally };
