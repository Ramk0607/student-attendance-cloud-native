'use strict';
/**
 * HTTP client for course-service (synchronous service-to-service call).
 * Discovery is DNS based: COURSE_URL points at the Kubernetes Service name.
 */
const { HttpError } = require('./kit/http');

function createCourseClient({ baseUrl, internalToken, timeoutMs = 3000, logger }) {
  async function getRoster(courseId, requestId) {
    let res;
    try {
      res = await fetch(`${baseUrl}/internal/courses/${Number(courseId)}/roster`, {
        headers: { 'x-internal-token': internalToken, ...(requestId ? { 'x-request-id': requestId } : {}) },
        signal: AbortSignal.timeout(timeoutMs),
      });
    } catch (err) {
      logger.error('course-service unreachable', { error: err.message });
      throw new HttpError(503, 'Course service is unavailable, please retry', 'COURSE_SERVICE_UNAVAILABLE');
    }
    if (res.status === 404) throw new HttpError(404, 'Course not found', 'COURSE_NOT_FOUND');
    if (!res.ok) throw new HttpError(502, 'Course service returned an error', 'COURSE_SERVICE_ERROR');
    return res.json(); // { course, students }
  }
  return { getRoster };
}

module.exports = { createCourseClient };
