'use strict';
const { Router, createServer } = require('./kit/http');
const { createMetrics } = require('./kit/metrics');
const { createLifecycle } = require('./kit/lifecycle');
const { authenticate, requireRole, requireInternalToken } = require('./kit/auth');

function createApp({ config, repo, service, logger }) {
  const router = new Router();
  const metrics = createMetrics('attendance-service', { track: config.info.track });
  const lifecycle = createLifecycle({
    logger,
    checks: { database: () => repo.ping() },
    simulateFailure: config.simulateReadinessFailure,
    shutdownDelayMs: config.shutdownDelayMs,
  });
  const requireAuth = authenticate({ secret: config.jwtSecret, issuer: config.jwtIssuer });
  const staffOnly = requireRole('faculty', 'admin');
  const internalOnly = requireInternalToken(config.internalToken);

  metrics.gauge('smartattend_open_sessions', 'Class sessions currently accepting check-ins', async () => (await repo.totals()).openSessions);
  lifecycle.register(router);
  router.get('/metrics', async (req, res) => res.text(await metrics.render(), 200, 'text/plain; version=0.0.4'));

  // ---- Public API (Ingress path /api/attendance - JWT validated at the gateway AND here) ----
  router.get('/api/attendance/_info', (req, res) => res.json(config.info));

  router.get('/api/attendance/policy', (req, res) =>
    res.json({
      minAttendancePercent: config.minAttendancePercent,
      criticalAttendancePercent: config.criticalAttendancePercent,
      codeValidityMinutes: config.codeValidityMinutes,
      lateAfterMinutes: config.lateAfterMinutes,
    }),
  );

  // student
  router.post('/api/attendance/check-in', requireAuth, async (req, res) => {
    res.json({ record: await service.checkIn(req.user, req.body.code) });
  });
  router.get('/api/attendance/me', requireAuth, requireRole('student'), async (req, res) => {
    res.json(await service.mySummary(req.user));
  });

  // faculty / admin
  router.get('/api/attendance/stats', requireAuth, staffOnly, async (req, res) => res.json(await service.stats(req.user)));

  router.get('/api/attendance/sessions', requireAuth, staffOnly, async (req, res) => {
    const sessions = await service.listSessions(req.user, { courseId: req.query.courseId });
    res.json({ sessions, total: sessions.length });
  });
  router.post('/api/attendance/sessions', requireAuth, staffOnly, async (req, res) => {
    res.json({ session: await service.startSession(req.user, req.body, req.requestId) }, 201);
  });
  router.get('/api/attendance/sessions/:id', requireAuth, staffOnly, async (req, res) => {
    res.json({ session: await service.getSession(req.user, req.params.id) });
  });
  router.post('/api/attendance/sessions/:id/close', requireAuth, staffOnly, async (req, res) => {
    res.json({ session: await service.closeSession(req.user, req.params.id) });
  });
  router.put('/api/attendance/records/:id', requireAuth, staffOnly, async (req, res) => {
    res.json({ record: await service.markRecord(req.user, req.params.id, req.body.status) });
  });
  router.get('/api/attendance/courses/:courseId/report', requireAuth, staffOnly, async (req, res) => {
    res.json(await service.courseReport(req.user, req.params.courseId, req.requestId));
  });

  // ---- Internal API (CronJob; not exposed by the Ingress) ----
  router.post('/internal/attendance/close-expired', internalOnly, async (req, res) => {
    res.json({ closed: await service.closeExpired() });
  });

  const server = createServer({
    router,
    logger,
    metrics,
    info: config.info,
    chaosErrorRate: config.chaosErrorRate,
    chaosLatencyMs: config.chaosLatencyMs,
  });
  return { server, lifecycle, router };
}

module.exports = { createApp };
