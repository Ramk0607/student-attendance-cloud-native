'use strict';
const { str, int, num, bool, secret, runtimeInfo } = require('./kit/config');
const pkg = require('../package.json');

function loadConfig() {
  return {
    port: int('PORT', 4001),
    dbDriver: str('DB_DRIVER', 'memory'), // memory | postgres
    jwtSecret: secret('JWT_SECRET', 'dev-only-insecure-jwt-secret-change-me'),
    jwtIssuer: str('JWT_ISSUER', 'smartattend-auth'),
    jwtTtlSec: int('JWT_TTL_SEC', 8 * 3600),
    admin: {
      name: str('ADMIN_NAME', 'System Administrator'),
      email: str('ADMIN_EMAIL', 'admin@smartattend.local').toLowerCase(),
      password: secret('ADMIN_PASSWORD', 'Admin@12345'),
    },
    seedDemoUsers: bool('SEED_DEMO_USERS', true),
    chaosErrorRate: num('CHAOS_ERROR_RATE', 0),
    chaosLatencyMs: int('CHAOS_LATENCY_MS', 0),
    simulateReadinessFailure: bool('SIMULATE_READINESS_FAILURE', false),
    shutdownDelayMs: int('SHUTDOWN_DELAY_MS', 5000),
    info: runtimeInfo('auth-service', pkg.version),
  };
}

module.exports = { loadConfig };
