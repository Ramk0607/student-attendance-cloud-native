'use strict';
/** In-memory user store - used for local development and unit tests. */
class MemoryUserRepository {
  constructor() {
    this.users = new Map();
    this.nextId = 1;
  }

  async init() {}

  async ping() {
    return true;
  }

  async findByEmail(email) {
    for (const u of this.users.values()) if (u.email === email) return { ...u };
    return null;
  }

  async findById(id) {
    const u = this.users.get(Number(id));
    return u ? { ...u } : null;
  }

  async create({ name, email, passwordHash, role = 'student', rollNo = null }) {
    const clash = [...this.users.values()].find((u) => u.email === email || (rollNo && u.rollNo === rollNo));
    if (clash) {
      const err = new Error(clash.email === email ? 'duplicate email' : 'duplicate roll number');
      err.code = 'DUPLICATE';
      err.field = clash.email === email ? 'email' : 'rollNo';
      throw err;
    }
    const user = { id: this.nextId++, name, email, passwordHash, role, rollNo, createdAt: new Date().toISOString() };
    this.users.set(user.id, user);
    return { ...user };
  }

  async createIfMissing(user) {
    const existing = await this.findByEmail(user.email);
    return existing || this.create(user);
  }

  async list() {
    return [...this.users.values()].map((u) => ({ ...u }));
  }

  async count() {
    return this.users.size;
  }

  async close() {}
}

module.exports = { MemoryUserRepository };
