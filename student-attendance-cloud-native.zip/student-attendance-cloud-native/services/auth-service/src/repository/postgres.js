'use strict';
/** PostgreSQL user store. Schema is created idempotently at start-up (guarded by an advisory lock
 *  so several replicas starting at the same time do not race each other). */
const { toIso } = require('../kit/db');

const SCHEMA = `
DO $$
BEGIN
  PERFORM pg_advisory_xact_lock(4201);
  CREATE TABLE IF NOT EXISTS users (
    id            SERIAL PRIMARY KEY,
    name          VARCHAR(120) NOT NULL,
    email         VARCHAR(255) NOT NULL UNIQUE,
    password_hash TEXT         NOT NULL,
    role          VARCHAR(20)  NOT NULL DEFAULT 'student' CHECK (role IN ('student', 'faculty', 'admin')),
    roll_no       VARCHAR(20)  UNIQUE,
    created_at    TIMESTAMPTZ  NOT NULL DEFAULT now()
  );
END
$$;`;

const mapUser = (row) =>
  row && {
    id: Number(row.id),
    name: row.name,
    email: row.email,
    passwordHash: row.password_hash,
    role: row.role,
    rollNo: row.roll_no || null,
    createdAt: toIso(row.created_at),
  };

const isUniqueViolation = (err) => err.code === '23505' || /duplicate key/i.test(err.message);

class PostgresUserRepository {
  constructor(pool) {
    this.pool = pool;
  }

  async init() {
    await this.pool.query(SCHEMA);
  }

  async ping() {
    await this.pool.query('SELECT 1');
    return true;
  }

  async findByEmail(email) {
    const { rows } = await this.pool.query('SELECT * FROM users WHERE email = $1', [email]);
    return mapUser(rows[0]) || null;
  }

  async findById(id) {
    const { rows } = await this.pool.query('SELECT * FROM users WHERE id = $1', [Number(id)]);
    return mapUser(rows[0]) || null;
  }

  async create({ name, email, passwordHash, role = 'student', rollNo = null }) {
    try {
      const { rows } = await this.pool.query(
        'INSERT INTO users (name, email, password_hash, role, roll_no) VALUES ($1, $2, $3, $4, $5) RETURNING *',
        [name, email, passwordHash, role, rollNo],
      );
      return mapUser(rows[0]);
    } catch (err) {
      if (isUniqueViolation(err)) {
        const dup = new Error(/roll_no/.test(err.message + (err.constraint || '')) ? 'duplicate roll number' : 'duplicate email');
        dup.field = /roll_no/.test(err.message + (err.constraint || '')) ? 'rollNo' : 'email';
        dup.code = 'DUPLICATE';
        throw dup;
      }
      throw err;
    }
  }

  async createIfMissing({ name, email, passwordHash, role = 'student', rollNo = null }) {
    await this.pool.query(
      'INSERT INTO users (name, email, password_hash, role, roll_no) VALUES ($1, $2, $3, $4, $5) ON CONFLICT DO NOTHING',
      [name, email, passwordHash, role, rollNo],
    );
    return this.findByEmail(email);
  }

  async list() {
    const { rows } = await this.pool.query('SELECT * FROM users ORDER BY id');
    return rows.map(mapUser);
  }

  async count() {
    const { rows } = await this.pool.query('SELECT count(*)::int AS n FROM users');
    return Number(rows[0].n);
  }

  async close() {
    await this.pool.end();
  }
}

module.exports = { PostgresUserRepository };
