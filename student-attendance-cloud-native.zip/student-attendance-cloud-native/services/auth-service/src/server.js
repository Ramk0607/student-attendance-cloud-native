'use strict';
const { createLogger } = require('./kit/logger');
const { createPool, waitForDatabase } = require('./kit/db');
const { loadConfig } = require('./config');
const { createApp, seedUsers } = require('./app');
const { MemoryUserRepository } = require('./repository/memory');
const { PostgresUserRepository } = require('./repository/postgres');

async function main() {
  const logger = createLogger('auth-service');
  const config = loadConfig();

  let repo;
  if (config.dbDriver === 'postgres') {
    const pool = createPool({ logger });
    await waitForDatabase(pool, logger);
    repo = new PostgresUserRepository(pool);
  } else {
    logger.warn('using in-memory storage (DB_DRIVER=memory) - data is lost on restart');
    repo = new MemoryUserRepository();
  }
  await repo.init();
  await seedUsers(repo, config, logger);

  const { server, lifecycle } = createApp({ config, repo, logger });
  server.listen(config.port, () => {
    lifecycle.markStarted();
    logger.info('auth-service listening', { port: config.port, db: config.dbDriver, ...config.info });
  });
  lifecycle.handleSignals(server, () => repo.close());
}

main().catch((err) => {
  // eslint-disable-next-line no-console
  console.error(JSON.stringify({ level: 'fatal', service: 'auth-service', msg: err.message, stack: err.stack }));
  process.exit(1);
});
