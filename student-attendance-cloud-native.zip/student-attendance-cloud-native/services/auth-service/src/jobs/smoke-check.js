'use strict';
/**
 * Smoke test used by `helm test` and by the CD pipeline before promoting a release.
 * Usage: SMOKE_URLS="http://svc-a/readyz,http://svc-b/api/courses" node src/jobs/smoke-check.js
 * Exits non-zero if any URL does not answer 2xx within the retry budget.
 */
const urls = String(process.env.SMOKE_URLS || '')
  .split(',')
  .map((u) => u.trim())
  .filter(Boolean);
const attempts = Number(process.env.SMOKE_ATTEMPTS || 10);
const delayMs = Number(process.env.SMOKE_DELAY_MS || 3000);

async function check(url) {
  for (let i = 1; i <= attempts; i += 1) {
    try {
      const res = await fetch(url, { signal: AbortSignal.timeout(5000) });
      if (res.ok) {
        console.log(`PASS ${url} -> ${res.status} (served by ${res.headers.get('x-served-by') || 'n/a'})`);
        return true;
      }
      console.log(`retry ${i}/${attempts} ${url} -> HTTP ${res.status}`);
    } catch (err) {
      console.log(`retry ${i}/${attempts} ${url} -> ${err.message}`);
    }
    await new Promise((r) => setTimeout(r, delayMs));
  }
  console.log(`FAIL ${url}`);
  return false;
}

(async () => {
  if (!urls.length) {
    console.error('SMOKE_URLS is empty');
    process.exit(2);
  }
  const results = await Promise.all(urls.map(check));
  const failed = results.filter((ok) => !ok).length;
  console.log(`${urls.length - failed}/${urls.length} checks passed`);
  process.exit(failed ? 1 : 0);
})();
