'use strict';
const { Router, HttpError, createServer } = require('./kit/http');
const { createMetrics } = require('./kit/metrics');
const { createLifecycle } = require('./kit/lifecycle');
const { authenticate, requireRole } = require('./kit/auth');
const jwt = require('./kit/jwt');
const { hashPassword, verifyPassword } = require('./passwords');

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const ROLL_RE = /^[A-Z0-9-]{4,20}$/;
const ROLES = ['student', 'faculty', 'admin'];

const publicUser = (u) => ({ id: u.id, name: u.name, email: u.email, role: u.role, rollNo: u.rollNo || null, createdAt: u.createdAt });

function validateUser(body, { requireRoll }) {
  const errors = {};
  const name = String(body.name || '').trim();
  const email = String(body.email || '').trim().toLowerCase();
  const password = String(body.password || '');
  const rollNo = body.rollNo ? String(body.rollNo).trim().toUpperCase() : null;
  if (name.length < 2 || name.length > 80) errors.name = 'Name must be 2-80 characters';
  if (!EMAIL_RE.test(email)) errors.email = 'A valid email is required';
  if (password.length < 8) errors.password = 'Password must be at least 8 characters';
  else if (!/[A-Za-z]/.test(password) || !/\d/.test(password)) errors.password = 'Password needs letters and numbers';
  if (requireRoll && !rollNo) errors.rollNo = 'Roll number is required for students';
  if (rollNo && !ROLL_RE.test(rollNo)) errors.rollNo = 'Roll number: 4-20 letters/digits (e.g. 22CS001)';
  if (Object.keys(errors).length) throw new HttpError(422, 'Validation failed', 'VALIDATION_FAILED', errors);
  return { name, email, password, rollNo };
}

/** Demo users. Faculty / students are only seeded when SEED_DEMO_USERS=true (local, dev, staging). */
const DEMO_USERS = [
  { name: 'Dr. Meera Iyer', email: 'faculty@smartattend.local', password: 'Faculty@123', role: 'faculty' },
  { name: 'Prof. Arjun Rao', email: 'faculty2@smartattend.local', password: 'Faculty@123', role: 'faculty' },
  { name: 'Aarav Sharma', email: 'student@smartattend.local', password: 'Student@123', role: 'student', rollNo: '22CS001' },
  { name: 'Priya Nair', email: 'priya@smartattend.local', password: 'Student@123', role: 'student', rollNo: '22CS002' },
  { name: 'Rahul Verma', email: 'rahul@smartattend.local', password: 'Student@123', role: 'student', rollNo: '22CS003' },
  { name: 'Sneha Reddy', email: 'sneha@smartattend.local', password: 'Student@123', role: 'student', rollNo: '22CS004' },
  { name: 'Karthik Rao', email: 'karthik@smartattend.local', password: 'Student@123', role: 'student', rollNo: '22CS005' },
];

async function seedUsers(repo, config, logger) {
  await repo.createIfMissing({
    name: config.admin.name,
    email: config.admin.email,
    passwordHash: await hashPassword(config.admin.password),
    role: 'admin',
  });
  if (config.seedDemoUsers) {
    for (const u of DEMO_USERS) {
      await repo.createIfMissing({ ...u, passwordHash: await hashPassword(u.password), rollNo: u.rollNo || null });
    }
  }
  logger.info('users seeded', { admin: config.admin.email, demoUsers: config.seedDemoUsers });
}

function createApp({ config, repo, logger }) {
  const router = new Router();
  const metrics = createMetrics('auth-service', { track: config.info.track });
  const lifecycle = createLifecycle({
    logger,
    checks: { database: () => repo.ping() },
    simulateFailure: config.simulateReadinessFailure,
    shutdownDelayMs: config.shutdownDelayMs,
  });
  const requireAuth = authenticate({ secret: config.jwtSecret, issuer: config.jwtIssuer });

  metrics.gauge('smartattend_registered_users', 'Number of registered users', () => repo.count());
  lifecycle.register(router);
  router.get('/metrics', async (req, res) => res.text(await metrics.render(), 200, 'text/plain; version=0.0.4'));

  const issueToken = (user) =>
    jwt.sign(
      { sub: String(user.id), email: user.email, name: user.name, role: user.role, rollNo: user.rollNo || undefined },
      config.jwtSecret,
      { expiresInSec: config.jwtTtlSec, issuer: config.jwtIssuer },
    );

  const createUser = async (data, role) => {
    try {
      return await repo.create({ ...data, passwordHash: await hashPassword(data.password), role });
    } catch (err) {
      if (err.code === 'DUPLICATE') {
        const field = err.field || 'email';
        throw new HttpError(409, field === 'rollNo' ? 'This roll number is already registered' : 'An account with this email already exists', field === 'rollNo' ? 'ROLL_TAKEN' : 'EMAIL_TAKEN');
      }
      throw err;
    }
  };

  router.get('/api/auth/_info', (req, res) => res.json(config.info));

  /** Self-registration is for students only (faculty accounts are created by an admin). */
  router.post('/api/auth/register', async (req, res) => {
    const data = validateUser(req.body, { requireRoll: true });
    const user = await createUser(data, 'student');
    logger.info('student registered', { userId: user.id });
    res.json({ token: issueToken(user), expiresInSec: config.jwtTtlSec, user: publicUser(user) }, 201);
  });

  router.post('/api/auth/login', async (req, res) => {
    const email = String(req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');
    if (!email || !password) throw new HttpError(400, 'Email and password are required');
    const user = await repo.findByEmail(email);
    if (!user || !(await verifyPassword(password, user.passwordHash))) {
      throw new HttpError(401, 'Invalid email or password', 'INVALID_CREDENTIALS');
    }
    res.json({ token: issueToken(user), expiresInSec: config.jwtTtlSec, user: publicUser(user) });
  });

  router.get('/api/auth/me', requireAuth, async (req, res) => {
    const user = await repo.findById(req.user.id);
    if (!user) throw new HttpError(404, 'User not found');
    res.json({ user: publicUser(user) });
  });

  /**
   * Gateway token introspection (NGINX auth-url / Traefik ForwardAuth).
   * 2xx = allow, 401 = reject; identity is returned as headers for the upstream service.
   */
  router.get('/api/auth/verify', requireAuth, (req, res) => {
    res.json({ valid: true, user: req.user }, 200, {
      'X-User-Id': String(req.user.id),
      'X-User-Role': req.user.role,
      'X-User-Email': req.user.email,
    });
  });

  router.get('/api/auth/users', requireAuth, requireRole('admin', 'faculty'), async (req, res) => {
    let users = await repo.list();
    if (req.query.role) users = users.filter((u) => u.role === req.query.role);
    res.json({ users: users.map(publicUser), total: users.length });
  });

  /** Admin creates faculty (or admin / student) accounts. */
  router.post('/api/auth/users', requireAuth, requireRole('admin'), async (req, res) => {
    const role = ROLES.includes(req.body.role) ? req.body.role : 'faculty';
    const data = validateUser(req.body, { requireRoll: role === 'student' });
    const user = await createUser(data, role);
    logger.info('user created by admin', { userId: user.id, role, by: req.user.email });
    res.json({ user: publicUser(user) }, 201);
  });

  const server = createServer({
    router,
    logger,
    metrics,
    info: config.info,
    chaosErrorRate: config.chaosErrorRate,
    chaosLatencyMs: config.chaosLatencyMs,
  });

  return { server, lifecycle, router };
}

module.exports = { createApp, seedUsers, DEMO_USERS };
