'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const jwt = require('../src/kit/jwt');
const { hashPassword, verifyPassword } = require('../src/passwords');

test('jwt sign/verify round trip', () => {
  const token = jwt.sign({ sub: '42', role: 'student' }, 's3cret', { expiresInSec: 60, issuer: 'smartattend-auth' });
  const claims = jwt.verify(token, 's3cret', { issuer: 'smartattend-auth' });
  assert.equal(claims.sub, '42');
  assert.equal(claims.iss, 'smartattend-auth');
});

test('jwt rejects tampering, expiry and wrong issuer', () => {
  const token = jwt.sign({ sub: '1', role: 'student' }, 'k', { issuer: 'a' });
  const [h, , s] = token.split('.');
  const evil = `${h}.${Buffer.from(JSON.stringify({ sub: '1', role: 'admin', iss: 'a' })).toString('base64url')}.${s}`;
  assert.throws(() => jwt.verify(evil, 'k'), /Invalid signature/);
  assert.throws(() => jwt.verify(token, 'k', { issuer: 'b' }), /issuer/);
  const expired = jwt.sign({ sub: '1' }, 'k', { expiresInSec: -120 });
  assert.throws(() => jwt.verify(expired, 'k'), /expired/);
  assert.throws(() => jwt.verify('a.b', 'k'), /Malformed/);
});

test('password hashing', async () => {
  const hash = await hashPassword('Attend@2026');
  assert.match(hash, /^scrypt:/);
  assert.equal(await verifyPassword('Attend@2026', hash), true);
  assert.equal(await verifyPassword('attend@2026', hash), false);
});
