'use strict';
const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { createApp, seedUsers } = require('../src/app');
const { MemoryUserRepository } = require('../src/repository/memory');
const { PostgresUserRepository } = require('../src/repository/postgres');
const { createLogger } = require('../src/kit/logger');
const jwt = require('../src/kit/jwt');

process.env.LOG_SILENT = 'true';

const config = {
  port: 0,
  jwtSecret: 'test-secret',
  jwtIssuer: 'smartattend-auth',
  jwtTtlSec: 3600,
  admin: { name: 'Admin', email: 'admin@test.local', password: 'Admin@12345' },
  seedDemoUsers: true,
  chaosErrorRate: 0,
  chaosLatencyMs: 0,
  simulateReadinessFailure: false,
  shutdownDelayMs: 0,
  info: { service: 'auth-service', version: 'test', track: 'stable', pod: 'test-pod' },
};

let server;
let base;
let repo;

async function makeRepo() {
  if (process.env.TEST_DB_DRIVER !== 'postgres') return new MemoryUserRepository();
  const { createPool } = require('../src/kit/db');
  const pool = createPool({ logger: createLogger('test') });
  await pool.query('DROP TABLE IF EXISTS users CASCADE');
  return new PostgresUserRepository(pool);
}

const api = async (method, path, body, token) => {
  const res = await fetch(`${base}${path}`, {
    method,
    headers: { 'content-type': 'application/json', ...(token ? { authorization: `Bearer ${token}` } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  return { status: res.status, headers: res.headers, body: text ? JSON.parse(text) : null };
};

before(async () => {
  const logger = createLogger('test');
  repo = await makeRepo();
  await repo.init();
  await seedUsers(repo, config, logger);
  const app = createApp({ config, repo, logger });
  server = app.server;
  app.lifecycle.markStarted();
  await new Promise((r) => server.listen(0, r));
  base = `http://127.0.0.1:${server.address().port}`;
});

after(async () => {
  server.close();
  await repo.close();
});

test('health endpoints', async () => {
  assert.equal((await api('GET', '/healthz')).status, 200);
  const ready = await api('GET', '/readyz');
  assert.equal(ready.status, 200);
  assert.equal(ready.body.checks.database, 'ok');
});

test('register -> login -> me', async () => {
  const reg = await api('POST', '/api/auth/register', { name: 'Priya', email: 'Priya@Example.com', password: 'secret123', rollNo: '23it042' });
  assert.equal(reg.status, 201);
  assert.equal(reg.body.user.email, 'priya@example.com');
  assert.equal(reg.body.user.role, 'student');
  assert.equal(reg.body.user.rollNo, '23IT042');
  const claims = JSON.parse(Buffer.from(reg.body.token.split('.')[1], 'base64url').toString());
  assert.equal(claims.rollNo, '23IT042');
  assert.equal(reg.body.user.passwordHash, undefined, 'hash must never be returned');

  const login = await api('POST', '/api/auth/login', { email: 'priya@example.com', password: 'secret123' });
  assert.equal(login.status, 200);
  const me = await api('GET', '/api/auth/me', null, login.body.token);
  assert.equal(me.status, 200);
  assert.equal(me.body.user.name, 'Priya');
});

test('duplicate registration is rejected', async () => {
  const body = { name: 'Dup', email: 'dup@example.com', password: 'secret123', rollNo: '23IT100' };
  assert.equal((await api('POST', '/api/auth/register', body)).status, 201);
  const again = await api('POST', '/api/auth/register', body);
  assert.equal(again.status, 409);
  assert.equal(again.body.error.code, 'EMAIL_TAKEN');
  const sameRoll = await api('POST', '/api/auth/register', { ...body, email: 'other@example.com' });
  assert.equal(sameRoll.status, 409);
  assert.equal(sameRoll.body.error.code, 'ROLL_TAKEN');
});

test('validation errors', async () => {
  const res = await api('POST', '/api/auth/register', { name: 'x', email: 'bad', password: 'short' });
  assert.equal(res.status, 422);
  assert.ok(res.body.error.details.email);
  assert.ok(res.body.error.details.password);
  assert.ok(res.body.error.details.rollNo, 'students need a roll number');
});

test('wrong password gives generic 401', async () => {
  const res = await api('POST', '/api/auth/login', { email: 'admin@test.local', password: 'nope-nope-1' });
  assert.equal(res.status, 401);
  assert.equal(res.body.error.code, 'INVALID_CREDENTIALS');
});

test('verify endpoint returns identity headers for the gateway', async () => {
  const login = await api('POST', '/api/auth/login', { email: 'admin@test.local', password: 'Admin@12345' });
  const ok = await api('GET', '/api/auth/verify', null, login.body.token);
  assert.equal(ok.status, 200);
  assert.equal(ok.headers.get('x-user-role'), 'admin');
  assert.equal(ok.headers.get('x-user-email'), 'admin@test.local');
  assert.equal((await api('GET', '/api/auth/verify')).status, 401);
  assert.equal((await api('GET', '/api/auth/verify', null, 'garbage.token.here')).status, 401);
});

test('tokens signed with another secret or algorithm are rejected', async () => {
  const forged = jwt.sign({ sub: '1', role: 'admin', email: 'x@y.z' }, 'other-secret', { issuer: 'smartattend-auth' });
  assert.equal((await api('GET', '/api/auth/verify', null, forged)).status, 401);
  const none = `${Buffer.from('{"alg":"none","typ":"JWT"}').toString('base64url')}.${Buffer.from('{"sub":"1","role":"admin"}').toString('base64url')}.`;
  assert.equal((await api('GET', '/api/auth/verify', null, none)).status, 401);
});

test('admin creates faculty accounts; students cannot list users', async () => {
  const student = await api('POST', '/api/auth/login', { email: 'student@smartattend.local', password: 'Student@123' });
  assert.equal(student.status, 200);
  assert.equal(student.body.user.rollNo, '22CS001');
  assert.equal((await api('GET', '/api/auth/users', null, student.body.token)).status, 403);
  const admin = await api('POST', '/api/auth/login', { email: 'admin@test.local', password: 'Admin@12345' });
  const created = await api('POST', '/api/auth/users', { name: 'Dr. New', email: 'new.faculty@test.local', password: 'Teach1234', role: 'faculty' }, admin.body.token);
  assert.equal(created.status, 201);
  assert.equal(created.body.user.role, 'faculty');
  const faculty = await api('POST', '/api/auth/login', { email: 'faculty@smartattend.local', password: 'Faculty@123' });
  assert.equal((await api('POST', '/api/auth/users', { name: 'X', email: 'x@test.local', password: 'Teach1234' }, faculty.body.token)).status, 403);
  const list = await api('GET', '/api/auth/users?role=student', null, faculty.body.token);
  assert.equal(list.status, 200);
  assert.ok(list.body.users.every((u) => u.role === 'student'));
  assert.ok(list.body.total >= 5);
});

test('info, metrics and 404', async () => {
  const info = await api('GET', '/api/auth/_info');
  assert.equal(info.body.service, 'auth-service');
  const metrics = await fetch(`${base}/metrics`).then((r) => r.text());
  assert.match(metrics, /http_requests_total/);
  assert.equal((await api('GET', '/nope')).status, 404);
  assert.equal((await api('DELETE', '/api/auth/login')).status, 405);
});
