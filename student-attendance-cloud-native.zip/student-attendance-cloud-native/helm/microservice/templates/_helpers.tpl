{{/*
Named templates for the reusable microservice chart.
Remember: named templates are GLOBAL across parent and subcharts, so every name here
is prefixed with "microservice." to avoid clashes with the umbrella chart's "smartattend." helpers.
*/}}

{{- define "microservice.name" -}}
{{- .Chart.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/* <release>-<alias>, e.g. smartattend-course */}}
{{- define "microservice.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name .Chart.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{- define "microservice.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/* Selector labels - NEVER change these on a live release (Deployment selectors are immutable) */}}
{{- define "microservice.selectorLabels" -}}
app.kubernetes.io/name: {{ include "microservice.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{- define "microservice.labels" -}}
helm.sh/chart: {{ include "microservice.chart" . }}
{{ include "microservice.selectorLabels" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: smartattend
app.kubernetes.io/component: {{ .Values.component | default (include "microservice.name" .) }}
smartattend.io/environment: {{ .Values.global.environment | quote }}
{{- end -}}

{{/* Image tag resolution: image.tag -> global.image.tag -> Chart.appVersion */}}
{{- define "microservice.imageTag" -}}
{{- .Values.image.tag | default .Values.global.image.tag | default .Chart.AppVersion | toString -}}
{{- end -}}

{{/* Full image reference. Call with (dict "ctx" $ "tag" "<optional tag>") */}}
{{- define "microservice.image" -}}
{{- $ctx := .ctx -}}
{{- $registry := $ctx.Values.image.registry | default $ctx.Values.global.image.registry -}}
{{- $repository := required "image.repository is required for every microservice" $ctx.Values.image.repository -}}
{{- $tag := .tag | default (include "microservice.imageTag" $ctx) | toString -}}
{{- if $registry -}}
{{- printf "%s/%s:%s" (trimSuffix "/" $registry) $repository $tag -}}
{{- else -}}
{{- printf "%s:%s" $repository $tag -}}
{{- end -}}
{{- end -}}

{{- define "microservice.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
{{- include "microservice.fullname" . -}}
{{- else -}}
default
{{- end -}}
{{- end -}}

{{/* Shared Secret created by the umbrella chart (JWT secret, internal token, DB password ...) */}}
{{- define "microservice.appSecretName" -}}
{{- .Values.global.appSecretName | default (printf "%s-app-secrets" .Release.Name) -}}
{{- end -}}

{{- define "microservice.dbHost" -}}
{{- .Values.global.database.host | default (printf "%s-postgresql" .Release.Name) -}}
{{- end -}}

{{- define "microservice.dbPasswordSecret" -}}
{{- .Values.global.database.passwordSecret | default (include "microservice.appSecretName" .) -}}
{{- end -}}

{{/* In-cluster URL of the token verification endpoint used by the gateway (auth-url / ForwardAuth) */}}
{{- define "microservice.authUrl" -}}
{{- printf "http://%s-auth.%s.svc.cluster.local/api/auth/verify" .Release.Name .Release.Namespace -}}
{{- end -}}

{{/* Traefik middlewares (namespace-name@kubernetescrd) attached to this service's routers */}}
{{- define "microservice.traefikMiddlewares" -}}
{{- $list := list -}}
{{- if .Values.ingress.rateLimit.enabled -}}
{{- $list = append $list (printf "%s-%s-ratelimit@kubernetescrd" .Release.Namespace .Release.Name) -}}
{{- end -}}
{{- if .Values.ingress.jwtAuth -}}
{{- $list = append $list (printf "%s-%s-jwt-auth@kubernetescrd" .Release.Namespace .Release.Name) -}}
{{- end -}}
{{- join "," $list -}}
{{- end -}}

{{/* Track the main Service sends traffic to */}}
{{- define "microservice.activeTrack" -}}
{{- if .Values.blueGreen.enabled -}}
{{- .Values.blueGreen.activeColor -}}
{{- else -}}
stable
{{- end -}}
{{- end -}}

{{/* Rollout strategy label value, for humans and dashboards */}}
{{- define "microservice.rolloutMode" -}}
{{- if .Values.blueGreen.enabled -}}
blue-green
{{- else if .Values.canary.enabled -}}
canary
{{- else -}}
{{- .Values.strategy.type | lower -}}
{{- end -}}
{{- end -}}

{{/*
One Deployment. Called with a dict:
  ctx      - root context
  suffix   - name suffix ("", "-canary", "-blue", "-green")
  track    - value of the smartattend.io/track label (stable | canary | blue | green)
  tag      - image tag override ("" = default)
  replicas - replica count
  hpa      - true when an HPA owns the replica count
  extraEnv - map of extra env vars for this track only
*/}}
{{- define "microservice.deployment" -}}
{{- $ctx := .ctx -}}
{{- $v := $ctx.Values -}}
{{- $fullname := include "microservice.fullname" $ctx -}}
{{- $tag := .tag | default (include "microservice.imageTag" $ctx) | toString -}}
{{- $track := .track -}}
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ printf "%s%s" $fullname .suffix }}
  labels:
    {{- include "microservice.labels" $ctx | nindent 4 }}
    app.kubernetes.io/version: {{ $tag | trunc 63 | quote }}
    smartattend.io/track: {{ $track }}
  annotations:
    smartattend.io/rollout-mode: {{ include "microservice.rolloutMode" $ctx }}
spec:
  {{- if not .hpa }}
  replicas: {{ .replicas }}
  {{- end }}
  revisionHistoryLimit: {{ $v.revisionHistoryLimit }}
  progressDeadlineSeconds: {{ $v.progressDeadlineSeconds }}
  minReadySeconds: {{ $v.minReadySeconds }}
  strategy:
    type: {{ $v.strategy.type }}
    {{- if eq $v.strategy.type "RollingUpdate" }}
    rollingUpdate:
      maxSurge: {{ $v.strategy.maxSurge }}
      maxUnavailable: {{ $v.strategy.maxUnavailable }}
    {{- end }}
  selector:
    matchLabels:
      {{- include "microservice.selectorLabels" $ctx | nindent 6 }}
      smartattend.io/track: {{ $track }}
  template:
    metadata:
      labels:
        {{- include "microservice.selectorLabels" $ctx | nindent 8 }}
        smartattend.io/track: {{ $track }}
        app.kubernetes.io/version: {{ $tag | trunc 63 | quote }}
        app.kubernetes.io/part-of: smartattend
        {{- if $v.expose }}
        smartattend.io/expose: "true"
        {{- end }}
        {{- with $v.podLabels }}
        {{- toYaml . | nindent 8 }}
        {{- end }}
      annotations:
        # Rolls the pods automatically when the ConfigMap content changes
        checksum/config: {{ include (print $ctx.Template.BasePath "/configmap.yaml") $ctx | sha256sum }}
        {{- if $v.metrics.enabled }}
        prometheus.io/scrape: "true"
        prometheus.io/port: {{ $v.containerPort | quote }}
        prometheus.io/path: {{ $v.metrics.path | quote }}
        {{- end }}
        {{- with $v.podAnnotations }}
        {{- toYaml . | nindent 8 }}
        {{- end }}
    spec:
      serviceAccountName: {{ include "microservice.serviceAccountName" $ctx }}
      automountServiceAccountToken: {{ $v.serviceAccount.automountToken }}
      terminationGracePeriodSeconds: {{ $v.terminationGracePeriodSeconds }}
      {{- with $v.imagePullSecrets }}
      imagePullSecrets:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      securityContext:
        {{- toYaml $v.podSecurityContext | nindent 8 }}
      containers:
        - name: {{ include "microservice.name" $ctx }}
          image: {{ include "microservice.image" (dict "ctx" $ctx "tag" $tag) | quote }}
          imagePullPolicy: {{ $v.image.pullPolicy | default $v.global.image.pullPolicy | default "IfNotPresent" }}
          {{- with $v.command }}
          command:
            {{- toYaml . | nindent 12 }}
          {{- end }}
          ports:
            - name: http
              containerPort: {{ $v.containerPort }}
              protocol: TCP
          envFrom:
            - configMapRef:
                name: {{ $fullname }}-config
          env:
            - name: DEPLOY_TRACK
              value: {{ $track | quote }}
            - name: APP_VERSION
              value: {{ $tag | quote }}
            - name: POD_NAME
              valueFrom:
                fieldRef:
                  fieldPath: metadata.name
            - name: POD_NAMESPACE
              valueFrom:
                fieldRef:
                  fieldPath: metadata.namespace
            - name: NODE_NAME
              valueFrom:
                fieldRef:
                  fieldPath: spec.nodeName
            {{- if $v.database.enabled }}
            - name: PGPASSWORD
              valueFrom:
                secretKeyRef:
                  name: {{ include "microservice.dbPasswordSecret" $ctx }}
                  key: {{ $v.global.database.passwordKey }}
            {{- end }}
            {{- range $v.secretEnv }}
            - name: {{ .name }}
              valueFrom:
                secretKeyRef:
                  name: {{ .secretName | default (include "microservice.appSecretName" $ctx) }}
                  key: {{ .key }}
                  {{- if .optional }}
                  optional: true
                  {{- end }}
            {{- end }}
            {{- range $name, $value := .extraEnv }}
            - name: {{ $name }}
              value: {{ $value | toString | quote }}
            {{- end }}
          {{- with $v.probes.startup }}
          {{- if .enabled }}
          startupProbe:
            httpGet:
              path: {{ .path }}
              port: http
            periodSeconds: {{ .periodSeconds }}
            timeoutSeconds: {{ .timeoutSeconds }}
            failureThreshold: {{ .failureThreshold }}
          {{- end }}
          {{- end }}
          {{- with $v.probes.liveness }}
          {{- if .enabled }}
          livenessProbe:
            httpGet:
              path: {{ .path }}
              port: http
            periodSeconds: {{ .periodSeconds }}
            timeoutSeconds: {{ .timeoutSeconds }}
            failureThreshold: {{ .failureThreshold }}
          {{- end }}
          {{- end }}
          {{- with $v.probes.readiness }}
          {{- if .enabled }}
          readinessProbe:
            httpGet:
              path: {{ .path }}
              port: http
            periodSeconds: {{ .periodSeconds }}
            timeoutSeconds: {{ .timeoutSeconds }}
            failureThreshold: {{ .failureThreshold }}
            successThreshold: {{ .successThreshold }}
          {{- end }}
          {{- end }}
          {{- if gt (int $v.preStopSleepSeconds) 0 }}
          lifecycle:
            preStop:
              exec:
                command: ["sh", "-c", "sleep {{ $v.preStopSleepSeconds }}"]
          {{- end }}
          resources:
            {{- toYaml $v.resources | nindent 12 }}
          securityContext:
            {{- toYaml $v.securityContext | nindent 12 }}
          {{- if $v.tmpVolume }}
          volumeMounts:
            - name: tmp
              mountPath: /tmp
          {{- end }}
      {{- if $v.tmpVolume }}
      volumes:
        - name: tmp
          emptyDir:
            sizeLimit: 64Mi
      {{- end }}
      {{- with $v.nodeSelector }}
      nodeSelector:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- with $v.tolerations }}
      tolerations:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- if $v.affinity }}
      affinity:
        {{- toYaml $v.affinity | nindent 8 }}
      {{- else if eq $v.podAntiAffinity "soft" }}
      affinity:
        podAntiAffinity:
          preferredDuringSchedulingIgnoredDuringExecution:
            - weight: 100
              podAffinityTerm:
                topologyKey: kubernetes.io/hostname
                labelSelector:
                  matchLabels:
                    {{- include "microservice.selectorLabels" $ctx | nindent 20 }}
      {{- else if eq $v.podAntiAffinity "hard" }}
      affinity:
        podAntiAffinity:
          requiredDuringSchedulingIgnoredDuringExecution:
            - topologyKey: kubernetes.io/hostname
              labelSelector:
                matchLabels:
                  {{- include "microservice.selectorLabels" $ctx | nindent 18 }}
      {{- end }}
      {{- if $v.topologySpread.enabled }}
      topologySpreadConstraints:
        - maxSkew: {{ $v.topologySpread.maxSkew }}
          topologyKey: {{ $v.topologySpread.topologyKey }}
          whenUnsatisfiable: {{ $v.topologySpread.whenUnsatisfiable }}
          labelSelector:
            matchLabels:
              {{- include "microservice.selectorLabels" $ctx | nindent 14 }}
              smartattend.io/track: {{ $track }}
      {{- end }}
{{- end -}}
