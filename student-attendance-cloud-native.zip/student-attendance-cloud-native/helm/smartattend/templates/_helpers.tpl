{{/* Umbrella-chart helpers (prefixed "smartattend." - named templates are global across charts) */}}

{{- define "smartattend.labels" -}}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: smartattend
smartattend.io/environment: {{ .Values.global.environment | quote }}
{{- end -}}

{{- define "smartattend.appSecretName" -}}
{{- .Values.global.appSecretName | default (printf "%s-app-secrets" .Release.Name) -}}
{{- end -}}

{{/* Image of one service, resolved exactly like the microservice chart does. (dict "ctx" $ "svc" "attendance") */}}
{{- define "smartattend.serviceImage" -}}
{{- $ctx := .ctx -}}
{{- $svc := index $ctx.Values .svc -}}
{{- $registry := dig "image" "registry" "" $svc | default $ctx.Values.global.image.registry -}}
{{- $repo := dig "image" "repository" "" $svc -}}
{{- $tag := dig "image" "tag" "" $svc | default $ctx.Values.global.image.tag | default $ctx.Chart.AppVersion | toString -}}
{{- if $registry -}}
{{- printf "%s/%s:%s" (trimSuffix "/" $registry) $repo $tag -}}
{{- else -}}
{{- printf "%s:%s" $repo $tag -}}
{{- end -}}
{{- end -}}

{{/* Names of enabled application services (aliases of the microservice chart) */}}
{{- define "smartattend.services" -}}
{{- $out := list -}}
{{- range $svc := list "frontend" "auth" "course" "attendance" -}}
{{- if dig "enabled" true (index $.Values $svc) -}}
{{- $out = append $out $svc -}}
{{- end -}}
{{- end -}}
{{- join "," $out -}}
{{- end -}}

{{/* Hardened container security context shared by jobs/tests */}}
{{- define "smartattend.jobSecurity" -}}
securityContext:
  allowPrivilegeEscalation: false
  readOnlyRootFilesystem: true
  capabilities:
    drop: ["ALL"]
{{- end -}}
