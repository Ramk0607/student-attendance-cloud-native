#!/usr/bin/env bash
# CO-3: HashiCorp Vault integration for GitHub Actions (no long-lived Vault token in GitHub).
# GitHub issues a short-lived OIDC JWT per workflow run; Vault verifies it and returns a token
# limited to one policy. Run once against your Vault (VAULT_ADDR + VAULT_TOKEN of an admin):
#   ./infra/vault/setup-github-oidc.sh <github-owner>/<repo>
set -euo pipefail
REPO="${1:?github owner/repo}"
vault secrets enable -path=secret kv-v2 2>/dev/null || true
vault auth enable jwt 2>/dev/null || true
vault write auth/jwt/config oidc_discovery_url="https://token.actions.githubusercontent.com" bound_issuer="https://token.actions.githubusercontent.com"

for ENV in dev staging prod; do
  # application secrets for this environment
  vault kv put "secret/smartattend/$ENV" \
    jwtSecret="$(openssl rand -hex 32)" internalToken="$(openssl rand -hex 24)" \
    dbPassword="$(openssl rand -hex 16)" adminPassword="Lib-$(openssl rand -hex 6)"
  sed "s#smartattend/dev#smartattend/$ENV#" "$(dirname "$0")/smartattend-policy.hcl" | vault policy write "smartattend-$ENV" -
  # only workflow runs of this repo deploying to this GitHub Environment may log in
  vault write "auth/jwt/role/smartattend-$ENV" - <<JSON
{
  "role_type": "jwt",
  "user_claim": "actor",
  "bound_audiences": ["vault"],
  "bound_claims": { "repository": "$REPO", "environment": "$ENV" },
  "token_policies": ["smartattend-$ENV"],
  "token_ttl": "10m"
}
JSON
done
echo "Done. In GitHub set the repository variable VAULT_ADDR=<your vault url>."
