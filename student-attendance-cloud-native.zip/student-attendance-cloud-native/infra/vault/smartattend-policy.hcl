# Vault policy: the CI/CD job for one environment may only READ that environment's secrets.
path "secret/data/smartattend/dev" {
  capabilities = ["read"]
}
