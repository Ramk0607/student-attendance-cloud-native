# CO-4 - Ingress, TLS and API gateway

## Ingress controllers

Each service owns an `Ingress` for its path (`/`, `/api/auth`, `/api/courses`, `/api/attendance`);
the controller merges them into one virtual host. `global.ingress.className` selects the controller:

| Feature | NGINX Ingress (`nginx`) | Traefik (`traefik`) |
|---|---|---|
| Rate limit | `limit-rps`, `limit-burst-multiplier`, `limit-connections` annotations | `Middleware rateLimit` |
| JWT validation | `auth-url` -> `auth-service /api/auth/verify`, `auth-response-headers` | `Middleware forwardAuth` |
| Canary | canary Ingress (`canary-weight`, `canary-by-header`) | TraefikService / Gateway API weights |
| TLS | `spec.tls` + cert-manager | `router.tls` + cert-manager |

> **Status note (2026):** the community **ingress-nginx** controller was retired in March 2026 - existing
> installs keep working but get no more fixes. The chart therefore also supports **Traefik** and the
> **Gateway API** (`gatewayApi.enabled=true`, `infra/gateway-api/gateway.yaml`), the official successor.

## TLS termination & certificate management

* TLS terminates at the ingress controller (`spec.tls.secretName`); traffic inside the cluster is plain HTTP (or mTLS with Istio).
* `templates/certificate.yaml` requests a cert-manager `Certificate` for the host (ECDSA P-256, 90 days, renewed 15 days before expiry, key rotation).
* Issuers: `infra/cert-manager/selfsigned-issuer.yaml` (local CA) and `cluster-issuers.yaml` (Let's Encrypt staging/prod, HTTP-01 through NGINX, DNS-01 example).
* HTTP -> HTTPS redirect: `ssl-redirect: "true"`; HSTS in `values-ha.yaml`.

## API gateway concepts

| Concept | Where |
|---|---|
| Path routing | Ingress rules per service |
| **Rate limiting** | per-IP limits; `/api/auth` is stricter (5 rps) against brute force -> HTTP 429 (`scripts/rate-limit-demo.sh`) |
| **Quotas** | business quota in course-service: max courses per student (`MAX_COURSES_PER_STUDENT`, HTTP 429 `QUOTA_EXCEEDED`); gateway quotas = `limit-rpm` / API keys |
| **JWT validation** | at the edge (auth-url / ForwardAuth) **and** in every service (defence in depth) |
| Header enrichment | gateway forwards `X-User-Id`, `X-User-Role` |
| Hidden internal APIs | `/internal/*` is never routed by the gateway; protected by an internal token + NetworkPolicy |

## External DNS

`infra/external-dns/values.yaml` + annotation `external-dns.alpha.kubernetes.io/hostname` on the
primary (frontend) Ingress in prod: ExternalDNS creates/updates the DNS record in Route53/Cloudflare
when the load balancer address changes (`policy: upsert-only`, TXT ownership records).

## Service discovery patterns

* **Server-side discovery via Kubernetes DNS**: attendance-service calls `http://smartattend-course.<ns>.svc.cluster.local`; kube-proxy load-balances across Ready pods only (readiness probe).
* **Headless Service** (`smartattend-postgresql-hl`) gives StatefulSet pods stable DNS names.
* Config via environment (`COURSE_URL`), injected by Helm - no hard-coded hosts.
* Service mesh: Istio sidecars add client-side load balancing, retries and outlier detection (`templates/istio.yaml`).

## mTLS overview

With `global.istio.enabled=true`: `PeerAuthentication` mode `STRICT` -> every pod-to-pod connection uses mutual TLS with certificates issued and rotated by Istio; `DestinationRule` `ISTIO_MUTUAL`. Benefits: encryption in transit, workload identity (SPIFFE), policy by identity instead of IP.

## High-availability gateway

`infra/ingress-nginx/values-ha.yaml`: 3+ replicas, HPA, PDB `minAvailable: 2`, required anti-affinity
across nodes, topology spread across zones, `externalTrafficPolicy: Local` (keeps client IP for rate
limiting), cloud L4 NLB in front with cross-zone load balancing.

## L4 vs L7 load balancing - cost/performance trade-offs

| | L4 (TCP/UDP: NLB, `Service type=LoadBalancer`) | L7 (HTTP: NGINX/Traefik/ALB, API gateway) |
|---|---|---|
| Sees | IP + port | URL, headers, cookies, JWT |
| Features | fast pass-through, TLS pass-through, any protocol | path routing, canary, rate limits, auth, TLS termination, retries |
| Latency/CPU | lowest | higher (parsing, TLS) |
| Cost | cheap per LB, but one LB per service gets expensive | one shared entry point for many services |
| Used here | NLB in front of the ingress controller | NGINX/Traefik for all HTTP routing |

Typical pattern (used here): **one L4 load balancer -> HA L7 ingress layer -> ClusterIP services**.

## Viva questions

1. *Why validate the JWT at the gateway and in the service?* - edge rejects junk early; service must not trust headers.
2. *Where is TLS terminated and why?* - at the ingress: certificates managed centrally, services stay simple.
3. *How does cert-manager renew certificates?* - watches `Certificate` resources, renews before `renewBefore`.
4. *What does `externalTrafficPolicy: Local` change?* - preserves client IP, avoids extra hop, needs pods on each node behind the LB.
