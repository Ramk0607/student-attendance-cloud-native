# CO-2 - Deployment strategies

Every service is deployed by the reusable `helm/microservice` chart. The pods carry a
`smartattend.io/track` label (`stable`, `canary`, `blue`, `green`) and the Service/Ingress decide
which track receives traffic. The web UI footer and the `X-Deploy-Track` response header show
which track answered each request.

## 1. Rolling update (default)

```yaml
strategy:
  type: RollingUpdate
  maxSurge: 1          # at most 1 extra pod during the update
  maxUnavailable: 0    # never go below the desired count -> zero downtime
minReadySeconds: 5     # a new pod must stay Ready 5 s before the next one is replaced
progressDeadlineSeconds: 180
```
Prod uses `maxSurge: 25%` for faster rollouts on many replicas.
Watch it: `kubectl -n smartattend-local rollout status deploy/smartattend-course` while running
`./scripts/deploy.sh local --set-string course.image.tag=<new-tag>`.

## 2. Canary release (NGINX Ingress traffic splitting)

`course.canary.enabled=true` renders a second Deployment (`smartattend-course-canary`, new image),
a canary Service and a **canary Ingress**:

```yaml
nginx.ingress.kubernetes.io/canary: "true"
nginx.ingress.kubernetes.io/canary-weight: "20"        # 20 % of requests
nginx.ingress.kubernetes.io/canary-by-header: X-Canary # "always" / "never" overrides the weight
```

```bash
./scripts/canary.sh local course start v2 20     # deploy canary, 20 % traffic
./scripts/canary.sh local course analyze         # 40 requests forced to the canary, error-rate gate (5 %)
./scripts/canary.sh local course weight 50       # progressive delivery
./scripts/canary.sh local course promote         # stable := v2 (rolling update), canary removed
./scripts/canary.sh local course abort           # rollback = delete the canary
```
Bad-canary demo: `./scripts/canary.sh local course start dev 30 --set-string course.canary.env.CHAOS_ERROR_RATE=0.5`
-> `analyze` fails -> `abort`.

Alternatives in the same chart: **Gateway API** `HTTPRoute` weighted `backendRefs` (`gatewayApi.enabled=true`)
and **Istio** `VirtualService` weights (`global.istio.enabled=true`), which also split *internal*
(east-west) traffic such as attendance -> course.

## 3. Blue-green release

`course.blueGreen.enabled=true` renders `smartattend-course-blue` and `smartattend-course-green`.
The main Service selects `smartattend.io/track: <activeColor>`; `smartattend-course-preview` always points
at the idle color so the new version can be tested **before** promotion.

```bash
./scripts/blue-green.sh local course init v1        # blue = v1 (live)
./scripts/blue-green.sh local course deploy v2      # green = v2 (idle, no users)
./scripts/blue-green.sh local course test           # smoke test via the preview Service
./scripts/blue-green.sh local course switch         # Service selector -> green (instant)
./scripts/blue-green.sh local course switch         # ...and instant rollback if needed
./scripts/blue-green.sh local course scale-idle 0   # save resources once confident
```
Trade-off: needs ~2x capacity during the release, but cut-over and rollback are instant.

## 4. Probes (advanced usage)

| Probe | Endpoint | Purpose |
|---|---|---|
| startupProbe | `/healthz` every 3 s, 30 failures allowed | protects slow starts; liveness/readiness wait for it |
| livenessProbe | `/healthz` | restart a wedged process; **never checks dependencies** (a DB outage must not restart every pod) |
| readinessProbe | `/readyz` | checks the DB; returns 503 while starting or shutting down -> pod leaves the Service endpoints |

Graceful shutdown: `preStop: sleep 5` + the app fails readiness on SIGTERM, waits, drains open
connections and exits within `terminationGracePeriodSeconds`. Result: no dropped requests during rollouts.

## 5. Automated rollbacks

* **Helm `--atomic`** (all deploy scripts and CI): if pods are not Ready before `--timeout`, Helm rolls back.
* **`kubectl rollout status` + `kubectl rollout undo`**: restores the previous ReplicaSet.
* `progressDeadlineSeconds` marks a stuck rollout as failed (`Progressing=False`).
* Proof: `./scripts/demo-auto-rollback.sh local` ships a release with `SIMULATE_READINESS_FAILURE=true`
  (readiness always 503). The CI job `e2e-kind` runs the same test on every push.

## 6. Testing deployment health pre-promotion

`helm test` (smoke-test Pod hitting every `/readyz` + a real API call), `canary.sh analyze`
(error-rate gate), `blue-green.sh test` (preview Service), and the CD pipeline runs `helm test` in
each environment before the next environment is allowed to start.

## 7. PodDisruptionBudgets

```yaml
pdb: { enabled: true, minAvailable: 2 }   # prod
```
`kubectl drain <node>` evicts pods one by one but never below `minAvailable`. Combined with pod
anti-affinity and zone topology spread, a node or zone failure does not take a service down.

## Viva questions

1. *maxSurge vs maxUnavailable?* - extra pods allowed above vs. pods allowed below the desired count.
2. *Canary vs blue-green?* - gradual % of users + metrics gate vs. full parallel stack with instant switch.
3. *Why must liveness not check the database?* - cascading restarts during a DB blip.
4. *What does a PDB protect against?* - voluntary disruptions (drain, upgrades), not node crashes.
5. *How does Helm know a release failed?* - `--wait` watches Deployment availability; timeout -> rollback.
