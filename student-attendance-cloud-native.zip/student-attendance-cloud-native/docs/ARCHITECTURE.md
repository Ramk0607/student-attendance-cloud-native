# Architecture & API

## Attendance workflow (tracking)

```mermaid
sequenceDiagram
  participant F as Faculty (browser)
  participant G as Gateway / Ingress
  participant A as attendance-service
  participant C as course-service
  participant S as Student (phone)
  F->>G: POST /api/attendance/sessions {courseId, topic}
  G->>A: (JWT validated via auth-url)
  A->>C: GET /internal/courses/:id/roster (internal token, K8s DNS)
  C-->>A: course + enrolled students
  A-->>F: session + 6-char code (valid 15 min), everyone ABSENT
  S->>G: POST /api/attendance/check-in {code}
  G->>A: (JWT validated)
  A-->>S: PRESENT (or LATE after 10 min)
  F->>A: PUT /api/attendance/records/:id {EXCUSED} (manual correction)
  Note over A: CronJob session-closer closes sessions whose code expired
```

```mermaid
stateDiagram-v2
  [*] --> ABSENT: session started (roster snapshot)
  ABSENT --> PRESENT: student enters code in time
  ABSENT --> LATE: code entered after LATE_AFTER_MINUTES
  ABSENT --> EXCUSED: faculty (medical leave, duty)
  PRESENT --> ABSENT: faculty correction
  LATE --> PRESENT: faculty correction
```

**Attendance %** = (PRESENT + LATE) / (sessions - EXCUSED).
Standing: `OK` (>= 75 %), `WARNING` (65-75 %), `SHORTAGE` (< 65 %). The service also tells the student how many
consecutive classes they must attend to get back to 75 % (`classesNeeded`).

## Consistency

* Starting a session inserts the session **and** the roster snapshot in one SQL statement (data-modifying CTE).
* Check-in is one conditional `UPDATE ... WHERE code = $1 AND status = 'OPEN' AND code_expires_at > now() AND record.status = 'ABSENT'` - a code works only while valid and only once per student, even with many replicas.
* Open session codes are unique (`UNIQUE INDEX ... WHERE status = 'OPEN'`); on a collision the service retries with a new code.
* Each service owns its tables (database-per-service style inside one PostgreSQL); attendance-service keeps a snapshot of course/student names so reports never need cross-service joins.

## API

All JSON. Protected endpoints need `Authorization: Bearer <JWT>`.

### auth-service (`/api/auth`)
| Method | Path | Auth | Description |
|---|---|---|---|
| POST | `/api/auth/register` | - | student sign-up `{name, email, password, rollNo}` -> `{token, user}` |
| POST | `/api/auth/login` | - | `{email, password}` -> `{token, user}` |
| GET | `/api/auth/me` | JWT | current user |
| GET | `/api/auth/verify` | JWT | gateway introspection: 200 + `X-User-*` headers or 401 |
| GET | `/api/auth/users?role=` | faculty/admin | list users |
| POST | `/api/auth/users` | admin | create faculty/admin/student accounts |

### course-service (`/api/courses`)
| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/api/courses?q=&department=` | - | course catalogue (+ departments) |
| GET | `/api/courses/mine` | JWT | student: enrolled · faculty: teaching · admin: all |
| GET | `/api/courses/:id` | - | one course |
| GET | `/api/courses/:id/roster` | course faculty / admin | enrolled students |
| POST / DELETE | `/api/courses[/:id]` | admin | manage courses |
| POST / DELETE | `/api/courses/:id/enroll` | student | enroll / drop (quota `MAX_COURSES_PER_STUDENT`) |
| GET | `/api/courses/stats` | - | counts |
| GET | `/internal/courses/:id/roster` | internal token | used by attendance-service (not exposed by the gateway) |

### attendance-service (`/api/attendance`)
| Method | Path | Auth | Description |
|---|---|---|---|
| POST | `/api/attendance/check-in` | student | `{code}` -> record PRESENT / LATE |
| GET | `/api/attendance/me` | student | overall + per-course %, standing, recent classes |
| POST | `/api/attendance/sessions` | course faculty / admin | `{courseId, topic}` -> session + code |
| GET | `/api/attendance/sessions?courseId=` | faculty/admin | sessions with counts |
| GET | `/api/attendance/sessions/:id` | course faculty / admin | session + roster records |
| POST | `/api/attendance/sessions/:id/close` | course faculty / admin | stop check-ins |
| PUT | `/api/attendance/records/:id` | course faculty / admin | `{status}` manual marking |
| GET | `/api/attendance/courses/:courseId/report` | course faculty / admin | per-student %, defaulters, class average |
| GET | `/api/attendance/stats` \| `/policy` | faculty/admin \| JWT | dashboard numbers / rules |
| POST | `/internal/attendance/close-expired` | internal token | CronJob sweep |

Common: `/healthz`, `/readyz`, `/metrics`, `/api/<service>/_info`. Errors: `{ "error": { "code", "message", "details?", "requestId" } }`.
Check-in error codes: `INVALID_CODE` (404), `CODE_EXPIRED` (410), `NOT_ENROLLED` (403), `ALREADY_MARKED` (409).

## Configuration (environment variables)

| Variable | Service | Default (dev) |
|---|---|---|
| `PORT` | all | 4001 / 4002 / 4003 (8080 in containers) |
| `DB_DRIVER` | all | `memory` (`postgres` in Docker/K8s) |
| `DATABASE_URL` or `PGHOST/PGPORT/PGDATABASE/PGUSER/PGPASSWORD` | all | - |
| `JWT_SECRET`, `JWT_ISSUER`, `JWT_TTL_SEC` | all / auth | dev secret, `smartattend-auth`, 8 h |
| `INTERNAL_TOKEN` | course, attendance | dev token |
| `ADMIN_EMAIL`, `ADMIN_PASSWORD`, `SEED_DEMO_USERS` | auth | admin@smartattend.local, Admin@12345, true |
| `SEED_COURSES`, `MAX_COURSES_PER_STUDENT` | course | true, 8 |
| `COURSE_URL` | attendance | http://localhost:4002 |
| `MIN_ATTENDANCE_PERCENT`, `CRITICAL_ATTENDANCE_PERCENT` | attendance | 75, 65 |
| `CODE_VALIDITY_MINUTES`, `LATE_AFTER_MINUTES` | attendance | 15, 10 |
| `SESSION_SWEEP_INTERVAL_SEC`, `SEED_DEMO_DATA` | attendance | 60, true |
| `CHAOS_ERROR_RATE`, `CHAOS_LATENCY_MS`, `SIMULATE_READINESS_FAILURE` | all | 0, 0, false (deployment demos) |

In production (`NODE_ENV=production`, set in the images) missing secrets stop the service at start-up.
