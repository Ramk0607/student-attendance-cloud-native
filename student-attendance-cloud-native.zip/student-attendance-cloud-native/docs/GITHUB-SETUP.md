# GitHub setup

## 1. Create the repository and push

```bash
git init
git add .
git commit -m "Initial commit: Cloud-Native Smart Attendance"
git branch -M main
git remote add origin https://github.com/<your-username>/student-attendance-cloud-native.git
git push -u origin main
```
(VS Code: Source Control panel -> *Publish to GitHub* does the same.)

Before or after pushing, replace the placeholders (lowercase username):
* `helm/smartattend/values.yaml` -> `global.image.registry: ghcr.io/<your-username>`
* `helm/smartattend/Chart.yaml` -> `home:`
* `gitops/**` -> `CHANGE-ME` / `change-me`
* `ci/jenkins/Jenkinsfile` -> `REGISTRY`

Optional but recommended: run `npm run install:all` once and commit the generated
`services/*/package-lock.json` files (reproducible `npm ci` builds).

## 2. What runs automatically

| Trigger | Workflow | Result |
|---|---|---|
| Pull request | CI | tests (changed services), Helm lint, config scan, image build + Trivy, kind deployment |
| Push to `main` | CI | same + images pushed to `ghcr.io/<you>/smartattend-*:sha-xxxxxxx` and `:main` |
| Tag `v1.2.3` | CI | images tagged `1.2.3` |
| Tag `chart-v1.2.3` | Release Helm chart | chart pushed to `oci://ghcr.io/<you>/charts/smartattend` |
| CI success on `main` | CD | dev -> staging -> prod (only if enabled, see below) |

Images appear under your profile -> *Packages*. Make them public (Package settings -> Change visibility)
or create an `imagePullSecret` in the cluster.

Security results (Trivy SARIF) appear under *Security -> Code scanning*.

## 3. Enable deployments to real clusters (CD)

1. *Settings -> Environments*: create `dev`, `staging`, `prod`.
   * staging & prod: tick **Required reviewers** (manual approval gate).
2. In each environment add:
   * secret `KUBECONFIG_B64` = `base64 -w0 ~/.kube/config` (a kubeconfig for that cluster/namespace)
   * variable `APP_HOST` = public host name (optional, enables the external smoke test)
3. *Settings -> Secrets and variables -> Actions -> Variables*: `K8S_DEPLOY_ENABLED = true`.
4. Optional Vault: run `infra/vault/setup-github-oidc.sh <owner>/<repo>` and set variable `VAULT_ADDR`.

The cluster needs an ingress controller and cert-manager (+ the issuers in `infra/cert-manager/`).

## 4. GitOps instead of push-based CD

```bash
./gitops/argocd/install.sh        # Argo CD + application smartattend-dev
```
Promote with *Actions -> GitOps promote -> Run workflow* (dev -> staging, staging -> prod); it opens a PR.
Allow it under *Settings -> Actions -> General -> Allow GitHub Actions to create pull requests*.

## Troubleshooting

* `denied: permission_denied` on push to GHCR -> *Settings -> Actions -> General -> Workflow permissions -> Read and write*.
* Image name errors -> registry names must be lowercase (the workflows lowercase the owner automatically).
* `ImagePullBackOff` -> the package is private; make it public or add an `imagePullSecret`.
* Windows: if scripts fail with `$'\r': command not found`, run `git config core.autocrlf false` and re-checkout (`.gitattributes` forces LF).
