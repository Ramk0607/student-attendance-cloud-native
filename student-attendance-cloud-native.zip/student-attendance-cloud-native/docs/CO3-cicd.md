# CO-3 - CI/CD pipelines for microservices on Kubernetes

## Pipeline (GitHub Actions)

```mermaid
flowchart LR
  A[push / PR] --> B[changes<br/>paths-filter]
  B --> C[test matrix<br/>unit + PostgreSQL integration]
  A --> D[helm-lint<br/>lint + template + kubeconform]
  A --> E[config-scan<br/>Trivy IaC]
  C & D --> F[image matrix<br/>build -> Trivy scan -> push GHCR]
  C & D --> G[e2e-kind<br/>helm install --atomic + helm test + rollback proof]
  F --> H[CD: dev] --> I{approval} --> J[staging] --> K{approval} --> L[prod]
```

| File | Purpose |
|---|---|
| `.github/workflows/ci.yml` | build -> test -> scan -> push, Helm lint, ephemeral kind deployment |
| `.github/workflows/cd.yml` | promotion dev -> staging -> prod (runs after CI on `main`) |
| `.github/workflows/deploy-env.yml` | reusable deploy job: kubeconfig, Vault, `helm upgrade --atomic`, `helm test`, smoke test |
| `.github/workflows/release-chart.yml` | chart versioning + OCI Helm repository |
| `.github/workflows/gitops-promote.yml` | GitOps promotion via pull request |
| `ci/jenkins/Jenkinsfile`, `ci/gitlab/.gitlab-ci.yml` | same pipeline on Jenkins / GitLab CI |

## Design principles applied

* **Independent services, one pipeline**: a matrix job per service; pull requests only test the services whose folders changed (`dorny/paths-filter`).
* **Fail fast**: lint + unit tests (seconds) gate the image builds and the cluster test (minutes).
* **Build once, deploy many**: image tag `sha-<commit>` is built once and promoted unchanged through every environment.
* **Immutable, traceable artifacts**: OCI labels with version + git SHA, SBOM-friendly Trivy reports.
* **Security gates**: Trivy blocks images with fixable HIGH/CRITICAL vulnerabilities before they are pushed; IaC scan of Helm/Dockerfiles reports misconfigurations to the GitHub Security tab.
* **Supply chain**: third-party actions pinned to commit SHAs (the March 2026 Trivy incident, CVE-2026-33634, rewrote trivy-action tags), Dependabot keeps them updated.
* **Least privilege**: `permissions:` per job; packages:write only where images are pushed.

## Trivy

```yaml
- uses: aquasecurity/trivy-action@ed142fd0673e97e23eac54620cfb913e5ce36c25 # v0.36.0
  with:
    image-ref: ghcr.io/<owner>/smartattend-course-service:main
    severity: HIGH,CRITICAL
    ignore-unfixed: true
    exit-code: "1"           # fail the pipeline
```
Images are small (Alpine, npm/yarn removed, `apk upgrade`, only the `pg` dependency), so scans stay clean.
Local scan: `trivy image smartattend-course-service:dev`.

## Environment promotion

GitHub **Environments** `dev`, `staging`, `prod`: add *Required reviewers* to staging and prod ->
the pipeline pauses until someone approves. Each environment has its own `KUBECONFIG_B64` secret and
optional `APP_HOST` variable. Deployments use `values-<env>.yaml` overlays.

## Secrets management

1. GitHub Environment secrets (kubeconfig).
2. **HashiCorp Vault** (`deploy-env.yml`): the job logs in with its short-lived GitHub OIDC token
   (`method: jwt`) - no Vault token is stored in GitHub. Vault role `smartattend-<env>` only allows
   reading `secret/data/smartattend/<env>` and only for runs targeting that environment
   (`infra/vault/setup-github-oidc.sh`). The values become the Kubernetes Secret.
3. In-cluster alternative: External Secrets Operator (`externalSecrets.enabled=true`).

## GitOps preview (Argo CD / Flux)

* Desired state per environment: `gitops/environments/<env>/values.yaml` (image tag).
* `gitops/argocd/smartattend-<env>.yaml`: Argo CD Application (dev auto-sync + self-heal, staging/prod manual).
* `gitops-promote.yml`: copies the tag from one environment file to the next and opens a pull request;
  merging the PR is the deployment (audit trail = git history).
* `gitops/flux/smartattend-dev.yaml`: the same with Flux `GitRepository` + `HelmRelease` (auto remediation).

```bash
./gitops/argocd/install.sh     # installs Argo CD v3.5 and the dev application
```

## Viva questions

1. *Why scan before push?* - a vulnerable image never reaches the registry/cluster.
2. *Push-based CD vs GitOps?* - pipeline has cluster credentials vs. cluster pulls desired state from git.
3. *Why OIDC to Vault?* - no long-lived secret in CI; tokens expire in minutes and are scoped.
4. *How is a failed prod deploy handled?* - `--atomic` rollback + the pipeline stops before the next stage.
