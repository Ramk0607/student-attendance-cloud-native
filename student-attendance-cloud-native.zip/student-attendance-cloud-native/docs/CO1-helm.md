# CO-1 - Helm fundamentals

## Chart layout

```
helm/
├── smartattend/                     # UMBRELLA chart (what you install)
│   ├── Chart.yaml                # metadata + dependencies (aliases, conditions, versions)
│   ├── values.yaml               # base values shared by every environment
│   ├── values-local.yaml         # kind / minikube overlay
│   ├── values-dev.yaml           # dev overlay
│   ├── values-staging.yaml       # staging overlay
│   ├── values-prod.yaml          # production overlay
│   └── templates/
│       ├── _helpers.tpl          # named templates ("smartattend.*")
│       ├── secret.yaml           # secret templating (lookup + randAlphaNum + resource-policy keep)
│       ├── externalsecret.yaml   # Vault -> Secret (External Secrets Operator)
│       ├── certificate.yaml      # cert-manager Certificate (conditional on CRDs)
│       ├── traefik-middlewares.yaml, httproute.yaml, istio.yaml, networkpolicy.yaml
│       ├── cronjob-session-closer.yaml  # CronJob re-using the attendance image
│       ├── tests/test-smoke.yaml # `helm test` hook
│       └── NOTES.txt             # printed after install/upgrade
├── microservice/                 # REUSABLE application chart (used 4x through aliases)
│   ├── Chart.yaml, values.yaml, values.schema.json
│   └── templates/ deployment.yaml service.yaml configmap.yaml ingress.yaml hpa.yaml pdb.yaml serviceaccount.yaml _helpers.tpl
└── postgresql/                   # database chart (StatefulSet + headless Service)
```

`Chart.yaml` -> `version` is the **chart** version (SemVer, bumped when templates change); `appVersion` is the **application** version (default image tag). CI overrides the image tag with the git SHA (`--set-string global.image.tag=sha-abc1234`).

## Techniques used

| Concept | Implementation |
|---|---|
| Variable injection | `.Values`, `.Release.Name`, `.Release.Namespace`, `.Chart.AppVersion`, `global.*` shared with subcharts |
| `tpl` | ConfigMap values may contain templates: `COURSE_URL: "http://{{ .Release.Name }}-course..."` |
| Named templates | `microservice.fullname`, `microservice.labels`, `microservice.image`, `microservice.deployment` (one template renders stable, canary, blue and green Deployments) |
| Conditionals | `{{- if .Values.canary.enabled }}`, `{{- if .Capabilities.APIVersions.Has "cert-manager.io/v1" }}`, `with`, `range`, `ternary`, `dig` |
| Dependencies | `microservice` chart listed 4 times with `alias: frontend/auth/course/attendance` and `condition: <alias>.enabled`; `postgresql` with `condition: postgresql.enabled` |
| Env overlays | `-f values.yaml -f values-<env>.yaml` - later files win, maps deep-merge, lists replace |
| Config templating | ConfigMap per service + `checksum/config` pod annotation -> config change triggers a rolling restart |
| Secret templating | explicit value -> existing value (`lookup`) -> random value; `helm.sh/resource-policy: keep` |
| Schema validation | `values.schema.json` rejects bad values (e.g. canary weight 150, unknown strategy) at lint/install time |
| Hooks | `helm.sh/hook: test` smoke-test Pod |

## Commands

```bash
helm dependency update helm/smartattend          # packages ../microservice and ../postgresql into charts/
helm lint helm/smartattend -f helm/smartattend/values.yaml -f helm/smartattend/values-prod.yaml --strict
helm template smartattend helm/smartattend -f helm/smartattend/values-dev.yaml > dev.yaml     # client-side render
helm upgrade --install smartattend helm/smartattend -n smartattend-dev -f ... --dry-run=server --debug  # server dry-run
helm upgrade --install smartattend helm/smartattend -n smartattend-local --create-namespace \
  -f helm/smartattend/values.yaml -f helm/smartattend/values-local.yaml --atomic --wait --timeout 10m
helm get values smartattend -n smartattend-local --all
helm history smartattend -n smartattend-local
helm rollback smartattend 1 -n smartattend-local
helm test smartattend -n smartattend-local --logs
```

All of it is wrapped in `scripts/helm-lint.sh`, `scripts/deploy.sh` and `scripts/rollback.sh`.

> **Helm 4 note:** Helm 4 (Nov 2025) renamed `--atomic` to `--rollback-on-failure` (and `--force` to `--force-replace`). The old flags still work with a deprecation warning. CI pins Helm v3.22 so the syllabus flag names are used unchanged.

## Helm repository & versioning

* Tag `chart-v1.2.0` -> `.github/workflows/release-chart.yml` packages the chart as `1.2.0` and pushes it to the OCI registry `oci://ghcr.io/<owner>/charts`.
* Install a published version: `helm install smartattend oci://ghcr.io/<owner>/charts/smartattend --version 1.2.0 -f my-values.yaml`.
* Classic HTTP repos (`helm repo add`, `index.yaml`) work the same way, e.g. via GitHub Pages + chart-releaser.

## Viva questions

1. *Difference between `version` and `appVersion`?* - chart packaging version vs. version of the software inside.
2. *Why aliases?* - one well-tested chart, four services: no copy-paste templates.
3. *How do secrets survive `helm upgrade` if they are random?* - `lookup` reads the existing Secret and reuses its data.
4. *Why does `lookup` not work with Argo CD?* - Argo renders with `helm template` (no cluster access); use External Secrets / Vault instead.
5. *What does `--atomic` do?* - waits for readiness; on failure/timeout it rolls the release back automatically.
