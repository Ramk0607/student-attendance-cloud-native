'use strict';
/**
 * Health endpoints + graceful shutdown.
 *
 *  /healthz  -> LIVENESS : "is the process alive?" Never checks dependencies,
 *               otherwise a DB outage would make Kubernetes restart every pod.
 *  /readyz   -> READINESS: "can this pod take traffic right now?" Checks the DB
 *               and returns 503 while starting up or shutting down, so the pod
 *               is removed from Service endpoints before it stops.
 *
 * SIMULATE_READINESS_FAILURE=true makes /readyz always fail. It is used to demo
 * automated rollbacks (helm upgrade --atomic / kubectl rollout undo) - see
 * scripts/demo-auto-rollback.sh.
 */
function createLifecycle({ logger, checks = {}, simulateFailure = false, shutdownDelayMs = 5000 }) {
  const state = { started: false, shuttingDown: false, startedAt: Date.now() };

  async function runChecks() {
    const results = {};
    let ok = true;
    for (const [name, fn] of Object.entries(checks)) {
      try {
        await Promise.race([fn(), new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), 2000))]);
        results[name] = 'ok';
      } catch (err) {
        ok = false;
        results[name] = `fail: ${err.message}`;
      }
    }
    return { ok, results };
  }

  function register(router) {
    router.get('/healthz', (req, res) => {
      res.json({ status: 'alive', uptimeSec: Math.round(process.uptime()) });
    });

    router.get('/readyz', async (req, res) => {
      if (simulateFailure) return res.json({ status: 'not-ready', reason: 'SIMULATE_READINESS_FAILURE=true' }, 503);
      if (!state.started) return res.json({ status: 'not-ready', reason: 'starting' }, 503);
      if (state.shuttingDown) return res.json({ status: 'not-ready', reason: 'shutting-down' }, 503);
      const { ok, results } = await runChecks();
      return res.json({ status: ok ? 'ready' : 'not-ready', checks: results }, ok ? 200 : 503);
    });
  }

  function markStarted() {
    state.started = true;
  }

  /** On SIGTERM: fail readiness -> wait for endpoints to update -> drain -> exit. */
  function handleSignals(server, onClose = async () => {}) {
    let closing = false;
    const shutdown = (signal) => {
      if (closing) return;
      closing = true;
      state.shuttingDown = true;
      logger.info('shutdown started', { signal, drainDelayMs: shutdownDelayMs });
      setTimeout(() => {
        server.close(async () => {
          try {
            await onClose();
          } finally {
            logger.info('shutdown complete');
            process.exit(0);
          }
        });
        server.closeIdleConnections?.();
        setTimeout(() => process.exit(1), 10000).unref();
      }, shutdownDelayMs);
    };
    process.on('SIGTERM', () => shutdown('SIGTERM'));
    process.on('SIGINT', () => shutdown('SIGINT'));
  }

  return { register, markStarted, handleSignals, state };
}

module.exports = { createLifecycle };
