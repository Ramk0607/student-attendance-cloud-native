'use strict';
/**
 * Minimal, dependency-free HTTP toolkit (router + JSON helpers + middleware chain).
 *
 * Why not Express? Fewer dependencies = smaller image, faster cold start and far
 * fewer CVEs reported by Trivy in the CI "scan" stage (see docs/CO3-cicd.md).
 */
const http = require('node:http');
const crypto = require('node:crypto');

class HttpError extends Error {
  constructor(status, message, code, details) {
    super(message);
    this.status = status;
    this.code = code || httpCode(status);
    this.details = details;
  }
}

function httpCode(status) {
  return (
    {
      400: 'BAD_REQUEST',
      401: 'UNAUTHORIZED',
      403: 'FORBIDDEN',
      404: 'NOT_FOUND',
      405: 'METHOD_NOT_ALLOWED',
      409: 'CONFLICT',
      413: 'PAYLOAD_TOO_LARGE',
      422: 'VALIDATION_FAILED',
      429: 'TOO_MANY_REQUESTS',
      502: 'BAD_GATEWAY',
      503: 'SERVICE_UNAVAILABLE',
    }[status] || 'INTERNAL_ERROR'
  );
}

function compilePath(path) {
  const keys = [];
  const source = path
    .split('/')
    .map((segment) => {
      if (segment.startsWith(':')) {
        keys.push(segment.slice(1));
        return '([^/]+)';
      }
      return segment.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    })
    .join('/');
  return { regex: new RegExp(`^${source}/?$`), keys };
}

class Router {
  constructor() {
    this.routes = [];
  }

  add(method, path, ...handlers) {
    const { regex, keys } = compilePath(path);
    this.routes.push({ method, path, regex, keys, handlers });
    return this;
  }

  get(path, ...h) { return this.add('GET', path, ...h); }
  post(path, ...h) { return this.add('POST', path, ...h); }
  put(path, ...h) { return this.add('PUT', path, ...h); }
  patch(path, ...h) { return this.add('PATCH', path, ...h); }
  delete(path, ...h) { return this.add('DELETE', path, ...h); }

  match(method, pathname) {
    let pathMatched = false;
    for (const route of this.routes) {
      const m = route.regex.exec(pathname);
      if (!m) continue;
      pathMatched = true;
      if (route.method !== method && !(method === 'HEAD' && route.method === 'GET')) continue;
      const params = {};
      route.keys.forEach((key, i) => {
        params[key] = decodeURIComponent(m[i + 1]);
      });
      return { route, params };
    }
    return { route: null, pathMatched };
  }
}

function sendJson(res, status, body, headers = {}) {
  if (res.writableEnded) return;
  const payload = body === undefined ? '' : JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(payload),
    ...headers,
  });
  res.end(payload);
}

function sendText(res, status, text, contentType = 'text/plain; charset=utf-8') {
  if (res.writableEnded) return;
  res.writeHead(status, { 'Content-Type': contentType, 'Content-Length': Buffer.byteLength(text) });
  res.end(text);
}

function readBody(req, limitBytes) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > limitBytes) {
        reject(new HttpError(413, 'Request body too large'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

/**
 * Creates an HTTP server.
 * @param {object} opts
 * @param {Router} opts.router
 * @param {object} opts.logger
 * @param {object} [opts.metrics]  metrics registry from ./metrics
 * @param {object} [opts.info]     { service, version, track, pod } added as response headers
 * @param {number} [opts.chaosErrorRate] 0..1 - inject HTTP 500s on /api routes (canary demo)
 * @param {number} [opts.chaosLatencyMs] - inject latency on /api routes
 */
function createServer({ router, logger, metrics, info = {}, chaosErrorRate = 0, chaosLatencyMs = 0, bodyLimit = 1024 * 1024 }) {
  const quietPaths = new Set(['/healthz', '/readyz', '/metrics']);

  return http.createServer(async (req, res) => {
    const started = process.hrtime.bigint();
    const url = new URL(req.url, 'http://localhost');
    const requestId = req.headers['x-request-id'] || crypto.randomUUID();
    let routeLabel = 'unmatched';

    res.setHeader('X-Request-Id', requestId);
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Cache-Control', 'no-store');
    if (info.service) res.setHeader('X-Service', info.service);
    if (info.version) res.setHeader('X-App-Version', info.version);
    if (info.track) res.setHeader('X-Deploy-Track', info.track);
    if (info.pod) res.setHeader('X-Served-By', info.pod);

    res.on('finish', () => {
      const seconds = Number(process.hrtime.bigint() - started) / 1e9;
      if (metrics) metrics.observeRequest(req.method, routeLabel, res.statusCode, seconds);
      if (!quietPaths.has(url.pathname)) {
        logger.info('request', {
          requestId,
          method: req.method,
          path: url.pathname,
          route: routeLabel,
          status: res.statusCode,
          durationMs: Math.round(seconds * 1000),
        });
      }
    });

    try {
      const { route, params, pathMatched } = router.match(req.method, url.pathname);
      if (!route) {
        throw pathMatched ? new HttpError(405, 'Method not allowed') : new HttpError(404, `Route ${url.pathname} not found`);
      }
      routeLabel = route.path;

      if (url.pathname.startsWith('/api/') && !url.pathname.endsWith('/_info')) {
        if (chaosLatencyMs > 0) await new Promise((r) => setTimeout(r, chaosLatencyMs));
        if (chaosErrorRate > 0 && Math.random() < chaosErrorRate) {
          throw new HttpError(500, 'Chaos: injected failure (CHAOS_ERROR_RATE)', 'CHAOS_INJECTED');
        }
      }

      req.params = params;
      req.query = Object.fromEntries(url.searchParams.entries());
      req.path = url.pathname;
      req.requestId = requestId;
      req.body = {};

      if (['POST', 'PUT', 'PATCH'].includes(req.method)) {
        const raw = await readBody(req, bodyLimit);
        if (raw.trim()) {
          try {
            req.body = JSON.parse(raw);
          } catch {
            throw new HttpError(400, 'Request body must be valid JSON');
          }
        }
      }

      res.json = (body, status = 200, headers) => sendJson(res, status, body, headers);
      res.text = (text, status = 200, type) => sendText(res, status, text, type);

      for (const handler of route.handlers) {
        await handler(req, res);
        if (res.writableEnded) return;
      }
      if (!res.writableEnded) sendJson(res, 204);
    } catch (err) {
      const status = err instanceof HttpError ? err.status : 500;
      if (status >= 500) logger.error('request failed', { requestId, error: err.message, stack: err.stack });
      sendJson(res, status, {
        error: {
          code: err.code || httpCode(status),
          message: status >= 500 && !(err instanceof HttpError) ? 'Internal server error' : err.message,
          ...(err.details ? { details: err.details } : {}),
          requestId,
        },
      });
    }
  });
}

module.exports = { Router, HttpError, createServer, sendJson };
