'use strict';
/**
 * HS256 JSON Web Tokens using only node:crypto.
 * - Only the HS256 algorithm is accepted (prevents "alg: none" / algorithm confusion attacks)
 * - Signature compared with crypto.timingSafeEqual
 * - exp / nbf / iss are validated
 */
const crypto = require('node:crypto');

const HEADER = { alg: 'HS256', typ: 'JWT' };

const b64url = (input) => Buffer.from(input).toString('base64url');

function hmac(data, secret) {
  return crypto.createHmac('sha256', secret).update(data).digest('base64url');
}

function sign(payload, secret, { expiresInSec = 3600, issuer } = {}) {
  if (!secret) throw new Error('JWT secret is required');
  const now = Math.floor(Date.now() / 1000);
  const body = { ...payload, iat: now, exp: now + expiresInSec };
  if (issuer) body.iss = issuer;
  const unsigned = `${b64url(JSON.stringify(HEADER))}.${b64url(JSON.stringify(body))}`;
  return `${unsigned}.${hmac(unsigned, secret)}`;
}

class TokenError extends Error {}

function verify(token, secret, { issuer, clockToleranceSec = 30 } = {}) {
  if (typeof token !== 'string') throw new TokenError('Token missing');
  const parts = token.split('.');
  if (parts.length !== 3) throw new TokenError('Malformed token');
  const [h, p, s] = parts;

  let header;
  let payload;
  try {
    header = JSON.parse(Buffer.from(h, 'base64url').toString('utf8'));
    payload = JSON.parse(Buffer.from(p, 'base64url').toString('utf8'));
  } catch {
    throw new TokenError('Malformed token');
  }
  if (header.alg !== 'HS256') throw new TokenError('Unsupported algorithm');

  const expected = Buffer.from(hmac(`${h}.${p}`, secret));
  const actual = Buffer.from(s);
  if (expected.length !== actual.length || !crypto.timingSafeEqual(expected, actual)) {
    throw new TokenError('Invalid signature');
  }

  const now = Math.floor(Date.now() / 1000);
  if (typeof payload.exp === 'number' && now > payload.exp + clockToleranceSec) throw new TokenError('Token expired');
  if (typeof payload.nbf === 'number' && now + clockToleranceSec < payload.nbf) throw new TokenError('Token not yet valid');
  if (issuer && payload.iss !== issuer) throw new TokenError('Invalid issuer');
  return payload;
}

module.exports = { sign, verify, TokenError };
