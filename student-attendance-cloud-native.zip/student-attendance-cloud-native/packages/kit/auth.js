'use strict';
/** Authentication / authorization guards shared by the services. */
const crypto = require('node:crypto');
const { HttpError } = require('./http');
const jwt = require('./jwt');

/**
 * Validates the Bearer JWT on every request (defence in depth: the API gateway
 * validates it too, but services never blindly trust X-User-* headers).
 */
function authenticate({ secret, issuer }) {
  return (req) => {
    const header = req.headers.authorization || '';
    const [scheme, token] = header.split(' ');
    if (scheme !== 'Bearer' || !token) throw new HttpError(401, 'Missing bearer token');
    try {
      const claims = jwt.verify(token, secret, { issuer });
      req.user = { id: Number(claims.sub), email: claims.email, name: claims.name, role: claims.role, rollNo: claims.rollNo || null };
    } catch (err) {
      throw new HttpError(401, `Invalid token: ${err.message}`);
    }
  };
}

function requireRole(...roles) {
  return (req) => {
    if (!req.user || !roles.includes(req.user.role)) {
      throw new HttpError(403, `Requires role: ${roles.join(' or ')}`);
    }
  };
}

/** Service-to-service calls carry a shared internal token (injected from a Kubernetes Secret). */
function requireInternalToken(expected) {
  const expectedBuf = Buffer.from(String(expected));
  return (req) => {
    const got = Buffer.from(String(req.headers['x-internal-token'] || ''));
    if (got.length !== expectedBuf.length || !crypto.timingSafeEqual(got, expectedBuf)) {
      throw new HttpError(403, 'Internal endpoint');
    }
  };
}

module.exports = { authenticate, requireRole, requireInternalToken };
