'use strict';
/** Structured JSON logger (one JSON object per line -> easy to ship to Loki/ELK). */
const LEVELS = { debug: 10, info: 20, warn: 30, error: 40 };

function createLogger(service, level = process.env.LOG_LEVEL || 'info') {
  const threshold = LEVELS[level] ?? LEVELS.info;
  const pretty = process.env.LOG_FORMAT === 'pretty';

  const write = (lvl, msg, fields = {}) => {
    if (LEVELS[lvl] < threshold || process.env.LOG_SILENT === 'true') return;
    if (pretty) {
      const extra = Object.keys(fields).length ? ` ${JSON.stringify(fields)}` : '';
      process.stdout.write(`[${service}] ${lvl.toUpperCase()} ${msg}${extra}\n`);
      return;
    }
    process.stdout.write(`${JSON.stringify({ ts: new Date().toISOString(), level: lvl, service, msg, ...fields })}\n`);
  };

  return {
    debug: (m, f) => write('debug', m, f),
    info: (m, f) => write('info', m, f),
    warn: (m, f) => write('warn', m, f),
    error: (m, f) => write('error', m, f),
  };
}

module.exports = { createLogger };
