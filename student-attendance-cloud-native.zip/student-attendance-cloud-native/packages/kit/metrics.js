'use strict';
/**
 * Tiny Prometheus exposition (text format 0.0.4) - no prom-client dependency.
 * Exposes: http_requests_total, http_request_duration_seconds (histogram),
 * process uptime / memory and any custom gauges registered by the service.
 */
const BUCKETS = [0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5];

function labelString(labels) {
  const parts = Object.entries(labels).map(([k, v]) => `${k}="${String(v).replace(/\\/g, '\\\\').replace(/"/g, '\\"')}"`);
  return parts.length ? `{${parts.join(',')}}` : '';
}

function createMetrics(service, staticLabels = {}) {
  const requests = new Map(); // key -> { labels, count }
  const durations = new Map(); // key -> { labels, buckets[], sum, count }
  const gauges = new Map(); // name -> { help, fn }

  function observeRequest(method, route, status, seconds) {
    const labels = { service, ...staticLabels, method, route, status: String(status) };
    const key = JSON.stringify(labels);
    const r = requests.get(key) || { labels, count: 0 };
    r.count += 1;
    requests.set(key, r);

    const dLabels = { service, ...staticLabels, method, route };
    const dKey = JSON.stringify(dLabels);
    const d = durations.get(dKey) || { labels: dLabels, buckets: BUCKETS.map(() => 0), sum: 0, count: 0 };
    BUCKETS.forEach((b, i) => {
      if (seconds <= b) d.buckets[i] += 1;
    });
    d.sum += seconds;
    d.count += 1;
    durations.set(dKey, d);
  }

  function gauge(name, help, fn) {
    gauges.set(name, { help, fn });
  }

  async function render() {
    const lines = [];
    lines.push('# HELP http_requests_total Total HTTP requests handled.');
    lines.push('# TYPE http_requests_total counter');
    for (const r of requests.values()) lines.push(`http_requests_total${labelString(r.labels)} ${r.count}`);

    lines.push('# HELP http_request_duration_seconds HTTP request latency.');
    lines.push('# TYPE http_request_duration_seconds histogram');
    for (const d of durations.values()) {
      BUCKETS.forEach((b, i) => {
        lines.push(`http_request_duration_seconds_bucket${labelString({ ...d.labels, le: String(b) })} ${d.buckets[i]}`);
      });
      lines.push(`http_request_duration_seconds_bucket${labelString({ ...d.labels, le: '+Inf' })} ${d.count}`);
      lines.push(`http_request_duration_seconds_sum${labelString(d.labels)} ${d.sum.toFixed(6)}`);
      lines.push(`http_request_duration_seconds_count${labelString(d.labels)} ${d.count}`);
    }

    const mem = process.memoryUsage();
    const base = { service, ...staticLabels };
    lines.push('# TYPE process_uptime_seconds gauge');
    lines.push(`process_uptime_seconds${labelString(base)} ${process.uptime().toFixed(0)}`);
    lines.push('# TYPE process_resident_memory_bytes gauge');
    lines.push(`process_resident_memory_bytes${labelString(base)} ${mem.rss}`);
    lines.push('# TYPE nodejs_heap_used_bytes gauge');
    lines.push(`nodejs_heap_used_bytes${labelString(base)} ${mem.heapUsed}`);

    for (const [name, g] of gauges) {
      let value = 0;
      try {
        value = Number(await g.fn()) || 0;
      } catch {
        value = -1;
      }
      lines.push(`# HELP ${name} ${g.help}`);
      lines.push(`# TYPE ${name} gauge`);
      lines.push(`${name}${labelString(base)} ${value}`);
    }
    return `${lines.join('\n')}\n`;
  }

  return { observeRequest, gauge, render };
}

module.exports = { createMetrics };
