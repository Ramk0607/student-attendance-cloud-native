'use strict';
/** 12-factor configuration helpers: everything comes from environment variables. */
const os = require('node:os');

const str = (name, fallback) => {
  const v = process.env[name];
  return v === undefined || v === '' ? fallback : v;
};
const int = (name, fallback) => {
  const v = Number.parseInt(process.env[name], 10);
  return Number.isNaN(v) ? fallback : v;
};
const num = (name, fallback) => {
  const v = Number.parseFloat(process.env[name]);
  return Number.isNaN(v) ? fallback : v;
};
const bool = (name, fallback) => {
  const v = process.env[name];
  if (v === undefined || v === '') return fallback;
  return ['1', 'true', 'yes', 'on'].includes(String(v).toLowerCase());
};

const isProduction = () => str('NODE_ENV', 'development') === 'production';

/** Returns a secret; in production a missing secret is a fatal startup error. */
function secret(name, devFallback) {
  const v = str(name);
  if (v) return v;
  if (isProduction()) {
    throw new Error(`Missing required secret ${name} (NODE_ENV=production)`);
  }
  return devFallback;
}

/** Runtime identity: shown in /_info and response headers (great for canary/blue-green demos). */
function runtimeInfo(service, version) {
  return {
    service,
    version: str('APP_VERSION', version),
    track: str('DEPLOY_TRACK', 'stable'),
    pod: str('POD_NAME', os.hostname()),
    namespace: str('POD_NAMESPACE', 'local'),
    node: str('NODE_NAME', os.hostname()),
    environment: str('APP_ENV', 'local'),
  };
}

module.exports = { str, int, num, bool, secret, isProduction, runtimeInfo };
