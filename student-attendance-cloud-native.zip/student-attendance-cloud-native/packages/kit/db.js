'use strict';
/**
 * PostgreSQL connection helper. The `pg` driver is only loaded when
 * DB_DRIVER=postgres, so local development and unit tests need no database.
 *
 * Connection settings come from DATABASE_URL or the standard libpq variables
 * PGHOST / PGPORT / PGDATABASE / PGUSER / PGPASSWORD (injected by Helm).
 */
function createPool({ logger, max = 10 }) {
  // eslint-disable-next-line global-require
  const { Pool } = require('pg');
  const options = { max, idleTimeoutMillis: 30000, connectionTimeoutMillis: 5000 };
  if (process.env.DATABASE_URL) options.connectionString = process.env.DATABASE_URL;
  if (process.env.PGSSLMODE === 'require') options.ssl = { rejectUnauthorized: false };
  const pool = new Pool(options);
  pool.on('error', (err) => logger.error('postgres pool error', { error: err.message }));
  return pool;
}

/** Retries the first connection so pods survive the DB starting a few seconds later. */
async function waitForDatabase(pool, logger, attempts = 30, delayMs = 2000) {
  for (let i = 1; i <= attempts; i += 1) {
    try {
      await pool.query('SELECT 1');
      return;
    } catch (err) {
      logger.warn('database not reachable yet', { attempt: i, error: err.message });
      if (i === attempts) throw err;
      await new Promise((r) => setTimeout(r, delayMs));
    }
  }
}

const toIso = (v) => (v === null || v === undefined ? null : new Date(v).toISOString());

module.exports = { createPool, waitForDatabase, toIso };
