#!/usr/bin/env bash
# CO-1: Helm linting + dry-run for every environment overlay.
#   ./scripts/helm-lint.sh                 lint + render to .out/rendered/<env>.yaml
#   ./scripts/helm-lint.sh --kubeconform   also validate rendered YAML against Kubernetes schemas
#   ./scripts/helm-lint.sh --server <env>  also run a server-side dry-run against the current cluster
source "$(dirname "$0")/common.sh"
need helm
KUBECONFORM=false; SERVER_ENV=""
while [ $# -gt 0 ]; do
  case "$1" in
    --kubeconform) KUBECONFORM=true; shift ;;
    --server) SERVER_ENV="$2"; shift 2 ;;
    *) shift ;;
  esac
done
OUT="$ROOT/.out/rendered"; mkdir -p "$OUT"
API_VERSIONS="--api-versions cert-manager.io/v1"

c_info "helm dependency update"
helm dependency update "$CHART" >/dev/null

for chart in "$ROOT/helm/microservice" "$ROOT/helm/postgresql"; do
  c_info "helm lint $(basename "$chart")"
  helm lint "$chart" --set image.repository=lint-check --strict
done

for env in local dev staging prod; do
  c_info "helm lint smartattend ($env)"
  # shellcheck disable=SC2046
  helm lint "$CHART" $(values_args "$env") --strict
  c_info "helm template smartattend ($env) -> .out/rendered/$env.yaml"
  # shellcheck disable=SC2046,SC2086
  helm template "$RELEASE" "$CHART" -n "$(ns_for "$env")" $(values_args "$env") $API_VERSIONS \
    --set-string global.image.tag=lint > "$OUT/$env.yaml"
done

c_info "Rendering strategy variants (canary / blue-green / traefik)"
helm template "$RELEASE" "$CHART" $(values_args staging) $API_VERSIONS \
  --set course.canary.enabled=true --set-string course.canary.image.tag=v2 > "$OUT/canary.yaml"
helm template "$RELEASE" "$CHART" $(values_args local) \
  --set course.blueGreen.enabled=true --set-string course.blueGreen.blue.tag=v1 --set-string course.blueGreen.green.tag=v2 > "$OUT/blue-green.yaml"
helm template "$RELEASE" "$CHART" $(values_args local) --api-versions traefik.io/v1alpha1 \
  --set global.ingress.className=traefik > "$OUT/traefik.yaml"

if $KUBECONFORM; then
  need kubeconform
  c_info "kubeconform (Kubernetes schema validation, CRDs skipped)"
  kubeconform -strict -summary -ignore-missing-schemas -kubernetes-version 1.31.0 "$OUT"/*.yaml
fi

if [ -n "$SERVER_ENV" ]; then
  c_info "Server-side dry-run against the current cluster ($SERVER_ENV)"
  # shellcheck disable=SC2046
  helm upgrade --install "$RELEASE" "$CHART" -n "$(ns_for "$SERVER_ENV")" --create-namespace \
    $(values_args "$SERVER_ENV") --dry-run=server --debug >/dev/null
fi
c_ok "Helm charts are valid"
