#!/usr/bin/env bash
# External smoke test through the ingress/gateway.  Usage: ./scripts/smoke-test.sh [base-url]
source "$(dirname "$0")/common.sh"
need curl
BASE="${1:-http://smartattend.localtest.me}"
fail=0
check() {
  local path="$1" expect="$2"
  code=$(curl -ks -o /dev/null -w '%{http_code}' "$BASE$path")
  if [ "$code" = "$expect" ]; then c_ok "$path -> $code"; else c_err "$path -> $code (expected $expect)"; fail=1; fi
}
check /                        200
check /api/courses?limit=1       200
check /api/auth/_info          200
check /api/attendance/me      401   # JWT required at the gateway
check /internal/courses/1/roster 404  # internal API is not exposed
TOKEN=$(curl -ks -X POST "$BASE/api/auth/login" -H 'content-type: application/json' \
  -d '{"email":"student@smartattend.local","password":"Student@123"}' | sed -n 's/.*"token":"\([^"]*\)".*/\1/p')
if [ -n "$TOKEN" ]; then
  code=$(curl -ks -o /dev/null -w '%{http_code}' -H "Authorization: Bearer $TOKEN" "$BASE/api/attendance/me")
  [ "$code" = 200 ] && c_ok "/api/attendance/me with JWT -> 200" || { c_err "/api/attendance/me with JWT -> $code"; fail=1; }
else
  c_warn "demo user login not available (SEED_DEMO_USERS=false) - skipped authenticated check"
fi
exit $fail
