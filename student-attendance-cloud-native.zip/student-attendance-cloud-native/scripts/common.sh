#!/usr/bin/env bash
# Shared helpers for the scripts in this folder (sourced, not executed).
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CHART="$ROOT/helm/smartattend"
RELEASE="${RELEASE:-smartattend}"
c_info()  { printf '\033[1;34m==>\033[0m %s\n' "$*"; }
c_ok()    { printf '\033[1;32m OK\033[0m %s\n' "$*"; }
c_warn()  { printf '\033[1;33m !!\033[0m %s\n' "$*"; }
c_err()   { printf '\033[1;31mERR\033[0m %s\n' "$*" >&2; }
need()    { command -v "$1" >/dev/null 2>&1 || { c_err "'$1' is required but not installed"; exit 1; }; }
ns_for()  { echo "smartattend-$1"; }
values_args() {
  local env="$1"
  echo "-f $CHART/values.yaml -f $CHART/values-$env.yaml"
}
