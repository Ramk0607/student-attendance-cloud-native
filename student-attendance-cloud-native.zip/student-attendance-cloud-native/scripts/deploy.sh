#!/usr/bin/env bash
# CO-1 / CO-2: install or upgrade the whole system with Helm.
#   ./scripts/deploy.sh <local|dev|staging|prod> [extra helm args, e.g. --set-string global.image.tag=sha-abc1234]
# --atomic: if the rollout does not become healthy within --timeout, Helm rolls back automatically.
source "$(dirname "$0")/common.sh"
need helm; need kubectl
ENV="${1:?usage: deploy.sh <local|dev|staging|prod> [helm args]}"; shift || true
NS="$(ns_for "$ENV")"

c_info "Updating chart dependencies"
helm dependency update "$CHART" >/dev/null
c_info "Linting"
# shellcheck disable=SC2046
helm lint "$CHART" $(values_args "$ENV") >/dev/null

c_info "Deploying release '$RELEASE' to namespace '$NS' ($ENV)"
# shellcheck disable=SC2046
helm upgrade --install "$RELEASE" "$CHART" \
  --namespace "$NS" --create-namespace \
  $(values_args "$ENV") \
  --atomic --wait --timeout 10m --history-max 10 \
  "$@"

c_info "Running helm test (smoke test of every service)"
helm test "$RELEASE" -n "$NS" --logs || { c_err "helm test failed"; exit 1; }
kubectl -n "$NS" get deploy,svc,ing,hpa,pdb
c_ok "Deployed. History: helm history $RELEASE -n $NS"
