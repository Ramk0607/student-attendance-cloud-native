#!/usr/bin/env bash
# Creates a local Kubernetes cluster with kind + NGINX Ingress Controller + cert-manager.
# Usage: ./scripts/kind-up.sh [cluster-name]
source "$(dirname "$0")/common.sh"
need kind; need kubectl; need helm
NAME="${1:-smartattend}"
INGRESS_NGINX_CHART_VERSION="4.15.1"   # final ingress-nginx release (project retired March 2026)
CERT_MANAGER_VERSION="v1.21.3"

if kind get clusters | grep -qx "$NAME"; then
  c_warn "kind cluster '$NAME' already exists"
else
  c_info "Creating kind cluster '$NAME' (3 nodes, ports 80/443 mapped to localhost)"
  kind create cluster --name "$NAME" --config "$ROOT/infra/kind/kind-config.yaml"
fi

c_info "Installing NGINX Ingress Controller"
helm upgrade --install ingress-nginx ingress-nginx \
  --repo https://kubernetes.github.io/ingress-nginx --version "$INGRESS_NGINX_CHART_VERSION" \
  --namespace ingress-nginx --create-namespace \
  -f "$ROOT/infra/ingress-nginx/values-kind.yaml" --wait --timeout 5m

c_info "Installing cert-manager $CERT_MANAGER_VERSION"
helm upgrade --install cert-manager cert-manager \
  --repo https://charts.jetstack.io --version "$CERT_MANAGER_VERSION" \
  --namespace cert-manager --create-namespace \
  --set crds.enabled=true --wait --timeout 5m

c_info "Creating ClusterIssuers (self-signed CA for local TLS)"
kubectl apply -f "$ROOT/infra/cert-manager/selfsigned-issuer.yaml"

c_info "Installing metrics-server (needed by the HPA)"
helm upgrade --install metrics-server metrics-server \
  --repo https://kubernetes-sigs.github.io/metrics-server/ \
  --namespace kube-system --set args="{--kubelet-insecure-tls}" --wait --timeout 5m || c_warn "metrics-server install failed (HPA will show <unknown>)"

c_ok "Cluster ready. Next: ./scripts/build-images.sh --kind $NAME && ./scripts/deploy.sh local"
