#!/usr/bin/env bash
# Deletes the local kind cluster.  Usage: ./scripts/kind-down.sh [cluster-name]
source "$(dirname "$0")/common.sh"
need kind
kind delete cluster --name "${1:-smartattend}"
