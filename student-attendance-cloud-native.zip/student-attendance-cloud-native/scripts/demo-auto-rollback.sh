#!/usr/bin/env bash
# CO-2: demonstrates AUTOMATED rollbacks.
#  Part 1 - helm upgrade --atomic: we ship a release whose pods never become Ready
#           (SIMULATE_READINESS_FAILURE=true -> /readyz returns 503). Helm waits, times out
#           and rolls back by itself; users never see the broken version (maxUnavailable=0).
#  Part 2 - kubectl rollout status + kubectl rollout undo: the same idea without Helm.
# Usage: ./scripts/demo-auto-rollback.sh [env]
source "$(dirname "$0")/common.sh"
need helm; need kubectl
ENV="${1:-local}"; NS="$(ns_for "$ENV")"; DEPLOY="$RELEASE-course"

c_info "Part 1: helm upgrade --atomic with a broken readiness probe"
helm history "$RELEASE" -n "$NS" --max 3
set +e
helm upgrade "$RELEASE" "$CHART" -n "$NS" --reuse-values \
  --set-string course.env.SIMULATE_READINESS_FAILURE=true \
  --atomic --wait --timeout 90s
rc=$?
set -e
[ $rc -ne 0 ] && c_ok "Helm detected the failed rollout and rolled back automatically" || c_warn "upgrade unexpectedly succeeded"
helm history "$RELEASE" -n "$NS" --max 4
kubectl -n "$NS" get pods -l app.kubernetes.io/name=course

c_info "Part 2: kubectl rollout status + rollout undo"
kubectl -n "$NS" set env "deploy/$DEPLOY" SIMULATE_READINESS_FAILURE=true
if ! kubectl -n "$NS" rollout status "deploy/$DEPLOY" --timeout=60s; then
  c_warn "Rollout not healthy within 60s -> kubectl rollout undo"
  kubectl -n "$NS" rollout undo "deploy/$DEPLOY"
  kubectl -n "$NS" rollout status "deploy/$DEPLOY" --timeout=180s
  c_ok "Previous ReplicaSet restored"
fi
kubectl -n "$NS" rollout history "deploy/$DEPLOY"
