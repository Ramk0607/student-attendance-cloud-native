#!/usr/bin/env bash
# CO-2: canary release through the NGINX Ingress (weight + header based traffic split).
#   ./scripts/canary.sh <env> <service> start <tag> [weight]   deploy canary pods with <tag> and send <weight>% traffic
#   ./scripts/canary.sh <env> <service> weight <n>             shift more/less traffic
#   ./scripts/canary.sh <env> <service> analyze [base-url]     test health of the canary BEFORE promotion
#   ./scripts/canary.sh <env> <service> promote                stable := canary tag, remove canary (rolling update)
#   ./scripts/canary.sh <env> <service> abort                  remove canary, keep stable
# Demo of a bad canary: ./scripts/canary.sh local course start dev 30 --set-string course.canary.env.CHAOS_ERROR_RATE=0.5
source "$(dirname "$0")/common.sh"
need helm; need kubectl
ENV="${1:?env}"; SVC="${2:?service (course|auth|attendance|frontend)}"; ACTION="${3:?action}"; shift 3
NS="$(ns_for "$ENV")"
API_PATH="$(case "$SVC" in auth) echo /api/auth/_info;; course) echo /api/courses/_info;; attendance) echo /api/attendance/policy;; *) echo /;; esac)"

upgrade() {
  helm upgrade "$RELEASE" "$CHART" -n "$NS" --reuse-values --atomic --wait --timeout 5m "$@"
}

case "$ACTION" in
  start)
    TAG="${1:?canary image tag}"; WEIGHT="${2:-10}"; shift 2 || shift $#
    c_info "Starting canary for $SVC: tag=$TAG weight=$WEIGHT%"
    upgrade --set "$SVC.canary.enabled=true" --set-string "$SVC.canary.image.tag=$TAG" --set "$SVC.canary.weight=$WEIGHT" "$@"
    kubectl -n "$NS" get pods -l "app.kubernetes.io/name=$SVC" -L smartattend.io/track,app.kubernetes.io/version
    ;;
  weight)
    WEIGHT="${1:?weight 0-100}"
    c_info "Shifting $WEIGHT% of traffic to the canary"
    upgrade --set "$SVC.canary.weight=$WEIGHT"
    ;;
  analyze)
    BASE="${1:-http://smartattend.localtest.me}"; N="${N:-40}"; MAX_ERROR_PCT="${MAX_ERROR_PCT:-5}"
    c_info "Sending $N requests FORCED to the canary (header X-Canary: always) -> $BASE$API_PATH"
    errors=0
    for _ in $(seq 1 "$N"); do
      code=$(curl -ks -o /dev/null -w '%{http_code}' -H 'X-Canary: always' "$BASE$API_PATH" || echo 000)
      [[ "$code" =~ ^(5..|000)$ ]] && errors=$((errors + 1))
    done
    pct=$((errors * 100 / N))
    c_info "Canary error rate: $errors/$N = $pct% (threshold $MAX_ERROR_PCT%)"
    c_info "Traffic split without header (which track answered):"
    for _ in $(seq 1 20); do curl -ks -D - -o /dev/null "$BASE$API_PATH" | grep -i '^x-deploy-track' | tr -d '\r'; done | sort | uniq -c
    if [ "$pct" -gt "$MAX_ERROR_PCT" ]; then c_err "Canary is unhealthy -> run: $0 $ENV $SVC abort"; exit 1; fi
    c_ok "Canary healthy -> safe to promote: $0 $ENV $SVC promote"
    ;;
  promote)
    TAG=$(helm get values "$RELEASE" -n "$NS" -o yaml | awk "/^$SVC:/{f=1} f&&/canary:/{c=1} c&&/tag:/{print \$2; exit}" | tr -d '"')
    [ -n "$TAG" ] || { c_err "could not read $SVC.canary.image.tag from the release"; exit 1; }
    c_info "Promoting $TAG to stable (rolling update) and removing the canary"
    upgrade --set-string "$SVC.image.tag=$TAG" --set "$SVC.canary.enabled=false"
    ;;
  abort)
    c_warn "Aborting canary for $SVC (stable keeps 100% of traffic)"
    upgrade --set "$SVC.canary.enabled=false"
    ;;
  *) c_err "unknown action $ACTION"; exit 1 ;;
esac
