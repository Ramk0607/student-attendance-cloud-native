#!/usr/bin/env bash
# CO-4: shows API-gateway rate limiting. Fires a burst of requests at the login endpoint
# (limit-rps=5 on /api/auth) and counts how many were throttled with HTTP 429.
# Usage: ./scripts/rate-limit-demo.sh [base-url] [requests]
source "$(dirname "$0")/common.sh"
need curl
BASE="${1:-http://smartattend.localtest.me}"; N="${2:-60}"
c_info "Sending $N parallel requests to $BASE/api/auth/_info"
seq 1 "$N" | xargs -P 20 -I{} curl -ks -o /dev/null -w '%{http_code}\n' "$BASE/api/auth/_info" | sort | uniq -c
c_info "200 = allowed, 429 = rejected by the gateway (Too Many Requests), 503 = limit-connections"
