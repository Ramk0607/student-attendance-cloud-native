#!/usr/bin/env bash
# CO-2: blue-green release. Two full Deployments (blue, green); the Service selector decides
# which one is live, so the switch (and the rollback) is instant.
#   ./scripts/blue-green.sh <env> <service> init <tag>     enable blue-green, blue=<tag> is live
#   ./scripts/blue-green.sh <env> <service> deploy <tag>   put <tag> on the IDLE color (no user traffic yet)
#   ./scripts/blue-green.sh <env> <service> test           smoke-test the idle color through <svc>-preview
#   ./scripts/blue-green.sh <env> <service> switch         make the idle color live (cut-over)
#   ./scripts/blue-green.sh <env> <service> scale-idle <n> scale the idle color (0 after you are confident)
#   ./scripts/blue-green.sh <env> <service> status
source "$(dirname "$0")/common.sh"
need helm; need kubectl
ENV="${1:?env}"; SVC="${2:?service}"; ACTION="${3:?action}"; shift 3
NS="$(ns_for "$ENV")"
SVC_NAME="$RELEASE-$SVC"

active() { kubectl -n "$NS" get svc "$SVC_NAME" -o jsonpath='{.spec.selector.smartattend\.io/track}' 2>/dev/null || true; }
idle()   { if [ "$(active)" = "green" ]; then echo blue; else echo green; fi; }
upgrade(){ helm upgrade "$RELEASE" "$CHART" -n "$NS" --reuse-values --atomic --wait --timeout 5m "$@"; }

case "$ACTION" in
  init)
    TAG="${1:?tag}"
    upgrade --set "$SVC.blueGreen.enabled=true" --set "$SVC.blueGreen.activeColor=blue" \
            --set-string "$SVC.blueGreen.blue.tag=$TAG" --set-string "$SVC.blueGreen.green.tag=$TAG"
    ;;
  deploy)
    TAG="${1:?tag}"; COLOR="$(idle)"
    c_info "Deploying $TAG to the idle color '$COLOR' (live stays '$(active)')"
    upgrade --set-string "$SVC.blueGreen.$COLOR.tag=$TAG" --set-string "$SVC.blueGreen.inactiveReplicas="
    ;;
  test)
    c_info "Testing idle color '$(idle)' via svc/$SVC_NAME-preview"
    kubectl -n "$NS" run "bg-test-$RANDOM" --rm -i --restart=Never --image=curlimages/curl:8.11.1 -- \
      sh -c "curl -fsS http://$SVC_NAME-preview/readyz && echo && curl -fsS -D - -o /dev/null http://$SVC_NAME-preview/healthz | grep -i x-deploy-track"
    c_ok "Idle color is healthy"
    ;;
  switch)
    NEW="$(idle)"
    c_info "Switching live traffic: $(active) -> $NEW"
    upgrade --set "$SVC.blueGreen.activeColor=$NEW"
    c_ok "Live color is now $(active). Roll back instantly with: $0 $ENV $SVC switch"
    ;;
  scale-idle)
    upgrade --set "$SVC.blueGreen.inactiveReplicas=${1:?replicas}"
    ;;
  status)
    echo "live color: $(active)   idle color: $(idle)"
    kubectl -n "$NS" get deploy -l "app.kubernetes.io/name=$SVC" -L smartattend.io/track,app.kubernetes.io/version
    ;;
  *) c_err "unknown action $ACTION"; exit 1 ;;
esac
