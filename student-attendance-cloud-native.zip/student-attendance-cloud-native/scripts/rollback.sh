#!/usr/bin/env bash
# CO-1 / CO-2: manual rollback.
#   ./scripts/rollback.sh <env>                    helm rollback to the previous revision
#   ./scripts/rollback.sh <env> <revision>         helm rollback to a given revision
#   ./scripts/rollback.sh <env> --kubectl <svc>    kubectl rollout undo for one Deployment (e.g. course)
source "$(dirname "$0")/common.sh"
need kubectl
ENV="${1:?usage: rollback.sh <env> [revision | --kubectl <service>]}"
NS="$(ns_for "$ENV")"

if [ "${2:-}" = "--kubectl" ]; then
  DEPLOY="$RELEASE-${3:?service name required, e.g. course}"
  c_info "Rollout history of deploy/$DEPLOY"
  kubectl -n "$NS" rollout history "deploy/$DEPLOY"
  c_info "kubectl rollout undo deploy/$DEPLOY"
  kubectl -n "$NS" rollout undo "deploy/$DEPLOY"
  kubectl -n "$NS" rollout status "deploy/$DEPLOY" --timeout=180s
  c_warn "kubectl undo changes the cluster only - the Helm release still records the old values. Prefer helm rollback."
  exit 0
fi

need helm
helm history "$RELEASE" -n "$NS"
if [ -n "${2:-}" ]; then
  c_info "Rolling back to revision $2"
  helm rollback "$RELEASE" "$2" -n "$NS" --wait --timeout 5m
else
  c_info "Rolling back to the previous revision"
  helm rollback "$RELEASE" -n "$NS" --wait --timeout 5m
fi
helm history "$RELEASE" -n "$NS" --max 5
c_ok "Rollback finished"
