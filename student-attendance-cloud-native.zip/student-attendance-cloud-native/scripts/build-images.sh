#!/usr/bin/env bash
# Builds all container images.
# Usage: ./scripts/build-images.sh [--tag dev] [--kind <cluster>] [--registry ghcr.io/user] [--push]
source "$(dirname "$0")/common.sh"
need docker
TAG="dev"; KIND_CLUSTER=""; REGISTRY=""; PUSH=false
while [ $# -gt 0 ]; do
  case "$1" in
    --tag) TAG="$2"; shift 2 ;;
    --kind) KIND_CLUSTER="${2:-smartattend}"; shift 2 ;;
    --registry) REGISTRY="$2/"; shift 2 ;;
    --push) PUSH=true; shift ;;
    *) c_err "unknown option $1"; exit 1 ;;
  esac
done

declare -A CONTEXTS=(
  [auth-service]="services/auth-service"
  [course-service]="services/course-service"
  [attendance-service]="services/attendance-service"
  [frontend]="frontend"
)
for name in auth-service course-service attendance-service frontend; do
  image="${REGISTRY}smartattend-${name}:${TAG}"
  c_info "Building $image"
  docker build -t "$image" --build-arg APP_VERSION="$TAG" \
    --build-arg GIT_SHA="$(git -C "$ROOT" rev-parse --short HEAD 2>/dev/null || echo local)" \
    "$ROOT/${CONTEXTS[$name]}"
  if [ -n "$KIND_CLUSTER" ]; then kind load docker-image "$image" --name "$KIND_CLUSTER"; fi
  if $PUSH; then docker push "$image"; fi
done
c_ok "Images built with tag '$TAG'"
