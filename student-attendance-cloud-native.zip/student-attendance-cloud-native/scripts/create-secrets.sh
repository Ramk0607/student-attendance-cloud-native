#!/usr/bin/env bash
# Creates the application Secret by hand (GitOps / Argo CD mode, where Helm `lookup` is not available).
# Usage: ./scripts/create-secrets.sh <namespace>
source "$(dirname "$0")/common.sh"
need kubectl; need openssl
NS="${1:?namespace, e.g. smartattend-dev}"
kubectl create namespace "$NS" --dry-run=client -o yaml | kubectl apply -f -
kubectl -n "$NS" create secret generic "$RELEASE-app-secrets" \
  --from-literal=jwt-secret="$(openssl rand -hex 32)" \
  --from-literal=internal-token="$(openssl rand -hex 24)" \
  --from-literal=db-password="$(openssl rand -hex 16)" \
  --from-literal=admin-password="${ADMIN_PASSWORD:-Admin@12345}" \
  --dry-run=client -o yaml | kubectl apply -f -
c_ok "Secret $RELEASE-app-secrets ready in $NS"
